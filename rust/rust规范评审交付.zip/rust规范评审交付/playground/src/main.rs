

fn main() {
    let a = Some(1);
    let _v = a.unwrap_or_else(|| {
            panic!("de");
    });
    
}


