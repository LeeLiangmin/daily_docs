﻿# Rust 规范学习 Playground

这里把《规范-修订稿》中的 15 个条目拆成 63 个独立的最小用例。它们不是“看起来合理”的示例，而是会真正执行 `cargo clippy`、编译失败断言或运行时行为断言的 fixture。

## 本仓库的定位

本仓库是规范评审的**学习库**：每条规范的正反例、lint 实测、编译器真实输出、运行时语义验证、示例能否编译、1.89 与新版本的行为差异，都可以在本地逐条复现、修改、对比。

门禁用的 lint PoC 放在 bot-gate-lab（`cases/<rustc|clippy>/<lint>/`），遵循该仓库「一个 case 一个 lint ID」的契约，用于证明门禁中的每个 lint 能命中、以及在哪些场景下漏报（`pass/` 场景）。两者分工：

| | 本仓库（playground） | bot-gate-lab |
| --- | --- | --- |
| 组织方式 | 按规范条款 | 按 lint ID |
| 内容 | lint 实测 + 语义验证 + 示例校验 + 版本差异 | 只有 lint 诊断断言 |
| 用途 | 理解规范、学习、看差异 | 门禁回归 |
| 入口 | `python scripts/validate-guideline.py` | `./scripts/validate-guideline.sh` |

规范原文与修订稿的差异见 `docs/规范/`：

- `规范评审处理记录.md`：每条的修改（diff）、理由、定级、lint 调整、漏报误报，按条款与本仓库的用例编号对应；
- `规范-整理版.md`：原文，只修格式；
- `规范-修订稿.md`：修订后的规范。

## 按条款索引

| 条款 | 标题 | 学习用例 | 门禁 PoC（bot-gate-lab） |
| --- | --- | --- | --- |
| G.CTF.01 | 宜优先使用模式匹配而非判断后再取值 | `cases/guideline/g-ctf-01/`（5 个） | `cases/clippy/unnecessary-unwrap` |
| G.CTF.02 | 在 Match 分支的 Guard 语句中不宜使用带有副作用的条件表达式 | `cases/guideline/g-ctf-02/`（2 个） | —（无对应 lint） |
| G.CTF.03 | 宜确保循环或递归能够安全退出 | `cases/guideline/g-ctf-03/`（7 个） | `cases/clippy/infinite-loop`（+2 pass）<br>`cases/clippy/while-immutable-condition`<br>`cases/rustc/unconditional-recursion`（+1 pass） |
| G.EXP.01 | 避免条件表达式永远为 true 或 false | `cases/guideline/g-exp-01/`（4 个） | `cases/clippy/absurd-extreme-comparisons`<br>`cases/clippy/bad-bit-mask`<br>`cases/clippy/eq-op`<br>`cases/clippy/impossible-comparisons`<br>`cases/clippy/overly-complex-bool-expr`<br>`cases/rustc/unused-comparisons` |
| G.EXP.02 | 用括号明确表达式的操作顺序，避免过分依赖默认优先级 | `cases/guideline/g-exp-02/`（4 个） | `cases/clippy/precedence`（+2 pass）<br>`cases/clippy/precedence-bits`<br>`cases/rustc/ambiguous-negative-literals` |
| G.FUD.01 | 内存拷贝代价大的参数应按地址传递 | `cases/guideline/g-fud-01/`（4 个） | `cases/clippy/large-types-passed-by-value`（+2 pass）<br>`cases/clippy/needless-pass-by-value` |
| G.FUD.02 | 宜合理使用 Result 类型或 must_use 修饰，保证用户有效处理返回值 | `cases/guideline/g-fud-02/`（4 个） | `cases/rustc/unused-must-use`（+3 pass） |
| G.TRA.01 | 在实现相等性、排序和散列类 trait 时，应保证一致性 | `cases/guideline/g-tra-01/`（5 个） | `cases/clippy/derive-ord-xor-partial-ord`（+1 pass）<br>`cases/clippy/derived-hash-with-manual-eq`（+1 pass）<br>`cases/clippy/non-canonical-partial-ord-impl` |
| G.TRA.02 | 宜实现 From 而不是 Into | `cases/guideline/g-tra-02/`（2 个） | `cases/clippy/from-over-into` |
| G.ERR.01 | 应正确处理返回类型 Option 和 Result | `cases/guideline/g-err-01/`（6 个） | `cases/clippy/expect-used`<br>`cases/clippy/unwrap-used`（+2 pass） |
| G.MOD.01 | 导入模块中的类型或函数时，应避免直接使用通配符 | `cases/guideline/g-mod-01/`（4 个） | `cases/clippy/wildcard-imports`（+3 pass） |
| G.MAC.01 | 不应通过宏将 unsafe 代码伪装为 safe 代码 | `cases/guideline/g-mac-01/`（6 个） | `cases/clippy/macro-metavars-in-unsafe`（+2 pass） |
| P.MAC.DCL.01 | 定义和使用声明宏时，应保证卫生性 | `cases/guideline/p-mac-dcl-01/`（6 个） | `cases/clippy/crate-in-macro-def`（+1 pass） |
| G.MAC.DCL.01 | 编写宏匹配规则时，宜遵从匹配范围从小至大的顺序 | `cases/guideline/g-mac-dcl-01/`（2 个） | —（无对应 lint） |
| P.MAC.PRO.01 | 定义和使用过程宏时，应保证卫生性 | `cases/guideline/p-mac-pro-01/`（2 个） | —（无对应 lint） |

## 当前基线

- Rust：1.89.0
- Clippy：0.1.89
- Python：3.12+
- 当前实测：63/63 与声明的预期一致
- 外部依赖：无；过程宏用例也只使用标准库，runner 强制 `--offline` 复现

`PASS` 的含义是“实测与 `case.toml` 契约一致”，不等于“Clippy 能检出问题”。预期零告警的漏报用例、预期编译失败的反例也会显示为 PASS。

## 如何运行

在本目录执行：

```powershell
python scripts/validate-guideline.py                    # 全部 case，紧凑输出
python scripts/validate-guideline.py g-err-01           # 按条目过滤，也可写 G.ERR.01
python scripts/validate-guideline.py -v G.ERR.01-03     # 打印单个 case 的完整证据
python scripts/validate-guideline.py --category 漏报    # 只跑某类 case
python scripts/validate-guideline.py --list             # 只列出 case，不运行
```

默认每个 case 先给一行判定，紧接着**原样回显编译器的真实输出**（`cargo clippy` 渲染好的诊断原文，与直接在终端运行看到的一致，未经改写），按规范条目分组：

```text
G.ERR.01  应正确处理返回类型 Option 和 Result
  ✓ 01  命中      clippy::unwrap_used ×1 L2
       cargo clippy 实际输出：
       │     Checking poc-g-err-01-01 v0.1.0 (...)
       │ warning: used `unwrap()` on a `Result` value
       │  --> src/lib.rs:2:5
       │   |
       │ 2 |     s.parse().unwrap()
       │   |     ^^^^^^^^^^^^^^^^^^
       │   |
       │   = note: if this value is an `Err`, it will panic
       │   = help: consider using `expect()` to provide a better panic message
       │   = note: requested on the command line with `-W clippy::unwrap-used`
       │
       │     Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.21s
  ✓ 02  漏报      clippy::unwrap_used ×0 · clippy::expect_used ×1 L2
       ...
────────────────────────────────────────────────────────────────────────
✓ 63/63 符合预期  ·  用时 7.7s
  类别  命中 21 · 漏报 18 · 误报 2 · 误报风险 1 · 边界 2 · 语义验证 6 · 示例校验 12 · 版本差异 2
```

- 回显内容：计入断言的每条 lint 诊断、编译失败时 rustc 的完整错误，以及 cargo 自己的状态行（Checking / Finished / could not compile）。漏报类 case 没有目标诊断，只回显状态行，证明 clippy 确实跑过且没有报。被 `ignore` 排除的噪声诊断也会原样列出，并标明不计入断言。
- 终端支持颜色时保留编译器原本的着色；`-b` 关闭回显，只保留每个 case 一行。
- 再次运行时 cargo 会回放缓存的诊断，内容与首次运行相同，只是可能没有 `Checking` 行。

- `✓ / ✗`：实测是否与 `case.toml` 一致。漏报、误报类 case 显示 ✓，表示该缺陷确实复现。
- `×N L行号`：该诊断的实际条数和所在行；`全部诊断` 指 `*` 断言（已排除 `ignore` 中的噪声 lint）。
- 编译失败类显示错误码和位置，语义验证类显示运行输出的前几行。
- 不一致的 case 会自动展开完整证据：实际执行的命令、显式 lint 等级、读取到的 `clippy.toml`、每条断言的期望与实际、诊断消息、被排除的诊断、运行输出、结论和原始日志路径。`-v` 为所有 case 展开同样的内容。

其他选项：`-b` 不回显编译器原文；`-q` 只看不一致的 case；`-j N` 并行数（默认 min(4, CPU 数)）；`--fail-fast`；`--timeout` 单个 cargo 命令超时；`--color auto|always|never`（遵守 `NO_COLOR`）；`--junit PATH` 输出 JUnit XML 供 CI 展示。退出码：0 全部一致，1 有不一致，2 环境或参数问题。

工具链版本：脚本会对比本机版本与评审基线 1.89.0，不同则在页眉提示。版本差异 case 在 `[[expect]]` 中用 `since = { "1.97.0" = N }` 声明新版本的期望，本机版本达到时自动按新期望判定，并在该行标出「按 1.97.0+ 判定」。只有不带过滤条件的全量运行才会覆盖 `results.json`。

重新生成实测清单：

```powershell
python scripts/render-guideline-poc-list.py
```

输出位置：

- `docs/guideline-poc-list.md`：逐条的场景、预期、实测和结论
- `docs/lint-catalog.md`：本 Playground 实际涉及的每条 lint/编译诊断及其作用
- `docs/guideline-poc-list-1.97-reference.md`：旧交付在 1.97 上的对照结果
- `artifacts/guideline/results.json`：机器可读汇总
- `artifacts/guideline/logs/*.jsonl`：Cargo 原始结构化诊断

## 目录约定

```text
cases/guideline/<条目>/<场景>/
├── Cargo.toml       独立 Cargo package
├── case.toml        lint 参数、预期次数、编译/运行断言、问题结论
├── clippy.toml      仅在场景依赖 Clippy 行为参数时出现
├── README.md        自动生成：所需 lint、对应源码位置、实际诊断与复现命令
└── src/             最小复现代码
```

`cases/guideline/rules.toml` 记录各条目的标题，只用于终端输出的分组标题。

条目目录包括：G.CTF.01～03、G.EXP.01～02、G.FUD.01～02、G.TRA.01～02、G.ERR.01、G.MOD.01、G.MAC.01、P.MAC.DCL.01、G.MAC.DCL.01、P.MAC.PRO.01。

项目级建议配置见 `config/`。用例本身不会继承这份建议配置，避免项目策略改变实验结果；每个实验实际开启的 lint 以自己的 `case.toml` 中 `args` 为准。

## 如何读结果

- **命中**：指定 lint 确实产生诊断。
- **漏报**：规范禁止，但目标 lint 或全量常用 lint 没有诊断。
- **误报 / 误报风险**：代码意图被规范允许或尚未执行，lint 仍报警。
- **边界**：验证 lint 的豁免边界。
- **语义验证**：用运行输出证明语言行为，不能仅靠 lint 判断。
- **示例校验**：确认规范中的正反例能否编译、是否真的表达预期。
- **版本差异**：同一 fixture 在 1.89 与新工具链行为不同。

详细的实际结论不要从 Cargo 退出码猜测，直接看生成的 `docs/guideline-poc-list.md`。
