#!/usr/bin/env python3
"""运行 cases/guideline 下的规范 POC，并按 case.toml 中的契约判定。

case.toml 支持的契约：

  [[expect]]   code = "<lint id>" | "*", count = N（N 可为 0）
               "*" 统计 fixture 中除 `ignore` 外的全部 lint 诊断。
               since = { "1.97.0" = M } 可选：工具链 >= 1.97.0 时期望改为 M（版本差异 case 用）。
  [build]      success = true|false, error_codes = [...], message_contains = [...]
  [run]        stdout_contains = [...], stdout_count = [["text", N], ...]

诊断来自 `cargo clippy --offline --all-targets --message-format=json-diagnostic-rendered-ansi -- <args>`，
每条诊断都保留编译器渲染好的原文（rendered），终端直接回显 Clippy / rustc 的真实输出；
只统计主 span（或宏调用点）落在本 case `fixtures` 内的诊断。

常用：
  python scripts/validate-guideline.py                 运行全部，紧凑输出
  python scripts/validate-guideline.py g-err-01        只跑某条规范（也可写 G.ERR.01）
  python scripts/validate-guideline.py -v G.ERR.01-03  打印单个 case 的完整证据
  python scripts/validate-guideline.py --list          只列出 case，不运行
"""

import argparse
import concurrent.futures
import json
import os
import pathlib
import re
import shlex
import subprocess
import sys
import time
import tomllib
import unicodedata
from xml.sax.saxutils import escape as xml_escape

ROOT = pathlib.Path(__file__).resolve().parent.parent
CASES = ROOT / "cases" / "guideline"
ART = ROOT / "artifacts" / "guideline"
BASELINE = "1.89.0"  # 规范评审基线；本机工具链不同时会在页眉提示
LINT_LEVELS = {"-W": "WARN", "-D": "DENY", "-A": "ALLOW", "-F": "FORBID"}
CLIPPY_GROUPS = {"clippy::all", "clippy::pedantic", "clippy::nursery", "clippy::restriction", "clippy::cargo"}
ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
CATEGORY_ORDER = ["命中", "漏报", "误报", "误报风险", "边界", "语义验证", "示例校验", "版本差异"]


# ------------------------------------------------------------------ 终端输出
class Style:
    """ANSI 颜色与符号；不支持时自动退化为纯文本。"""

    def __init__(self, mode, stream):
        self.color = self._want_color(mode, stream)
        encoding = getattr(stream, "encoding", None) or "ascii"
        # 依次尝试：UTF-8 符号 → GBK 控制台可显示的符号 → 纯 ASCII
        for marks in (("✓", "✗", "─", "·", "×", "→"), ("√", "×", "─", "·", "×", "->"),
                      ("ok", "!!", "-", "|", "x", "->")):
            try:
                "".join(marks).encode(encoding)
            except (UnicodeEncodeError, LookupError):
                continue
            self.ok, self.bad, self.rule, self.dot, self.times, self.arrow = marks
            break

    @staticmethod
    def _want_color(mode, stream):
        if mode == "never" or (mode == "auto" and (os.environ.get("NO_COLOR") or os.environ.get("TERM") == "dumb")):
            return False
        if mode == "auto" and not (hasattr(stream, "isatty") and stream.isatty()):
            return False
        if os.name == "nt":  # 打开 Windows 控制台的 ANSI 支持
            try:
                import ctypes
                kernel32 = ctypes.windll.kernel32
                handle = kernel32.GetStdHandle(-11)
                mode_val = ctypes.c_uint32()
                if kernel32.GetConsoleMode(handle, ctypes.byref(mode_val)):
                    kernel32.SetConsoleMode(handle, mode_val.value | 0x0004)
            except Exception:  # noqa: BLE001 - 失败时退化为无色
                return mode == "always"
        return True

    def _wrap(self, code, text):
        return f"\033[{code}m{text}\033[0m" if self.color else text

    def green(self, t): return self._wrap("32", t)
    def red(self, t): return self._wrap("31", t)
    def yellow(self, t): return self._wrap("33", t)
    def cyan(self, t): return self._wrap("36", t)
    def bold(self, t): return self._wrap("1", t)
    def dim(self, t): return self._wrap("2", t)


def width(text):
    """终端显示宽度：中日韩全角字符占 2 列。"""
    return sum(2 if unicodedata.east_asian_width(ch) in "WF" else 1 for ch in text)


def pad(text, cols):
    return text + " " * max(0, cols - width(text))


def posix(path):
    return str(path).replace("\\", "/")


def fmt_seconds(sec):
    return f"{sec:.1f}s" if sec < 60 else f"{int(sec // 60)}m{int(sec % 60):02d}s"


# ------------------------------------------------------------------ 环境
def toolchain():
    out = {}
    for key, cmd in (("rustc", ["rustc", "-V"]), ("clippy", ["cargo", "clippy", "-V"])):
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True)
        except FileNotFoundError:
            return None
        if proc.returncode != 0:
            return None
        out[key] = proc.stdout.strip()
    return out


def version_tuple(text):
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", text or "")
    return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)


def explicit_lint_rules(args):
    """解析 `--` 之后传给 rustc/Clippy 的 lint 等级参数。"""
    rules, index = [], 0
    while index < len(args):
        arg = args[index]
        if arg in LINT_LEVELS and index + 1 < len(args):
            flag, lint = arg, args[index + 1]
            index += 2
        elif len(arg) > 2 and arg[:2] in LINT_LEVELS:
            flag, lint = arg[:2], arg[2:]
            index += 1
        else:
            index += 1
            continue
        rules.append({"flag": flag, "level": LINT_LEVELS[flag], "lint": lint, "is_group": lint in CLIPPY_GROUPS})
    return rules


def discover_clippy_config(case_dir, env):
    """找出 Clippy 对该包实际会读取的 clippy.toml（CLIPPY_CONF_DIR 优先，否则向上查找）。"""
    config_dir = env.get("CLIPPY_CONF_DIR")
    search_dirs = [pathlib.Path(config_dir)] if config_dir else [case_dir, *case_dir.parents]
    for directory in search_dirs:
        for name in ("clippy.toml", ".clippy.toml"):
            candidate = directory / name
            if candidate.is_file():
                try:
                    settings = tomllib.loads(candidate.read_text(encoding="utf-8"))
                except (OSError, tomllib.TOMLDecodeError) as exc:
                    settings = {"<读取错误>": str(exc)}
                try:
                    path = posix(candidate.relative_to(ROOT))
                except ValueError:
                    path = posix(candidate)
                return {"path": path, "settings": settings,
                        "source": "CLIPPY_CONF_DIR" if config_dir else "目录向上查找"}
    return None


# ------------------------------------------------------------------ 诊断解析
def span_files(span):
    files = [span.get("file_name", "")]
    exp = span.get("expansion")
    while exp:
        files.append((exp.get("span") or {}).get("file_name", ""))
        exp = (exp.get("span") or {}).get("expansion")
    return files


def fixture_source_span(span, pkg_root, fixture_paths):
    """优先返回落在本 case fixture 中的宏调用点。"""
    current = span
    while current:
        file = current.get("file_name", "")
        if file and (pkg_root / file).resolve() in fixture_paths:
            return current
        expansion = current.get("expansion")
        current = (expansion.get("span") or {}) if expansion else None
    return span


def collect(lines, case_dir, fixtures):
    """返回 (诊断, 编译错误)，只保留落在本 case fixture 内的诊断。"""
    fixture_paths = {(case_dir / f).resolve() for f in fixtures}
    diags, errors, seen, error_seen = [], [], set(), set()
    for line in lines:
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if rec.get("reason") != "compiler-message":
            continue
        msg = rec["message"]
        primary = next((s for s in msg.get("spans", []) if s.get("is_primary")), None)
        code = (msg.get("code") or {}).get("code")
        pkg_root = pathlib.Path(rec.get("manifest_path", "")).parent
        shown = fixture_source_span(primary, pkg_root, fixture_paths) if primary else None
        file = posix(shown.get("file_name")) if shown else None
        line_no = shown.get("line_start") if shown else None
        if msg.get("level") == "error":
            error = {"code": code, "file": file, "line": line_no, "message": msg.get("message", ""),
                     "rendered": msg.get("rendered") or ""}
            key = (code, file, line_no, error["message"])
            if key not in error_seen:
                error_seen.add(key)
                errors.append(error)
        if primary is None or code is None:
            continue
        if not any((pkg_root / f).resolve() in fixture_paths for f in span_files(primary) if f):
            continue
        key = (code, msg.get("level"), primary.get("file_name"), primary.get("line_start"),
               primary.get("column_start"), msg.get("message"))
        if key in seen:
            continue
        seen.add(key)
        diags.append({"code": code, "level": msg.get("level"), "file": file, "line": line_no,
                      "message": msg.get("message"), "rendered": msg.get("rendered") or ""})
    return diags, errors


def expected_count(exp, rustc_version):
    """支持 since = {"1.97.0" = 1}：取不高于当前版本的最新一档。"""
    count, source = exp["count"], None
    for ver, n in sorted((exp.get("since") or {}).items(), key=lambda kv: version_tuple(kv[0])):
        if rustc_version >= version_tuple(ver):
            count, source = n, ver
    return count, source


# ------------------------------------------------------------------ 执行
def run_case(case_dir, env, rustc_version, timeout):
    started = time.monotonic()
    spec = tomllib.loads((case_dir / "case.toml").read_text(encoding="utf-8"))
    fixtures = spec.get("fixtures", ["src/lib.rs", "src/main.rs"])
    rel_dir = posix(case_dir.relative_to(ROOT))
    manifest = f"{rel_dir}/Cargo.toml"
    args = spec.get("args", [])
    cmd = ["cargo", "clippy", "--offline", "--manifest-path", manifest, "--all-targets",
           "--message-format=json-diagnostic-rendered-ansi", "--", *args]
    env = dict(env, CARGO_TARGET_DIR=str(ART / "target" / spec["id"]))
    problems = []
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                              env=env, cwd=ROOT, timeout=timeout)
        stdout, stderr, returncode = proc.stdout, proc.stderr, proc.returncode
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout if isinstance(exc.stdout, str) else ""
        stderr, returncode = f"超时：{timeout}s 内未结束", -1
        problems.append(f"cargo clippy 超过 {timeout}s 未结束")
    log = ART / "logs" / f"{spec['id']}.jsonl"
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(stdout + "\n--- stderr ---\n" + stderr, encoding="utf-8")
    diags, errors = collect(stdout.splitlines(), case_dir, fixtures)
    build_ok = returncode == 0 and not errors

    observed = []
    ignore = set(spec.get("ignore", []))
    ignored = [d for d in diags if d["code"] in ignore]
    for exp in spec.get("expect", []):
        code = exp["code"]
        want, since = expected_count(exp, rustc_version)
        if code == "*":
            got = [d for d in diags if d["code"] not in ignore and not d["code"].startswith("E")]
        else:
            got = [d for d in diags if d["code"] == code]
        observed.append({"code": code, "expected": want, "expected_since": since, "actual": len(got),
                         "lines": sorted({d["line"] for d in got}), "diagnostics": got})
        if len(got) != want:
            problems.append(f"{code}: 期望 {want} 条，实际 {len(got)} 条")

    build = spec.get("build", {"success": True})
    if build.get("success", True) != build_ok:
        want = "编译成功" if build.get("success", True) else "编译失败"
        got = "编译成功" if build_ok else "编译失败"
        detail = "；".join(e["message"] for e in errors[:2])
        problems.append(f"期望{want}，实际{got}" + (f"：{detail}" if detail else ""))
    for ec in build.get("error_codes", []):
        if not any(e["code"] == ec for e in errors):
            problems.append(f"缺少错误码 {ec}")
    for text in build.get("message_contains", []):
        if not any(text in e["message"] for e in errors):
            problems.append(f"错误信息中没有 {text!r}")

    run_out = None
    if "run" in spec and build_ok:
        try:
            rp = subprocess.run(["cargo", "run", "--offline", "-q", "--manifest-path", manifest],
                                capture_output=True, text=True, encoding="utf-8", errors="replace",
                                env=env, cwd=ROOT, timeout=timeout)
            run_out = rp.stdout
            if rp.returncode != 0:
                problems.append(f"运行失败（退出码 {rp.returncode}）：{rp.stderr.strip()[-300:]}")
        except subprocess.TimeoutExpired:
            run_out = ""
            problems.append(f"cargo run 超过 {timeout}s 未结束")
        for text in spec["run"].get("stdout_contains", []):
            if text not in run_out:
                problems.append(f"运行输出中没有 {text!r}")
        for text, n in spec["run"].get("stdout_count", []):
            if run_out.count(text) != n:
                problems.append(f"运行输出中 {text!r} 期望 {n} 次，实际 {run_out.count(text)} 次")

    return {
        "id": spec["id"], "rule": spec["rule"], "category": spec["category"],
        "title": spec["title"], "conclusion": spec.get("conclusion", ""),
        "version_note": spec.get("version_note", ""), "path": rel_dir, "fixtures": fixtures,
        "args": args, "lint_rules": explicit_lint_rules(args),
        "clippy_config": discover_clippy_config(case_dir, env),
        "command": cmd, "observed": observed, "build_ok": build_ok,
        "expect_build_ok": build.get("success", True),
        "ignored_diagnostics": ignored, "errors": errors[:5], "stdout": run_out,
        "status": "PASS" if not problems else "FAIL", "problems": problems,
        "cargo_stderr": [ln.rstrip() for ln in stderr.splitlines() if ln.strip()],
        "log": posix(log.relative_to(ROOT)), "seconds": round(time.monotonic() - started, 2),
    }


# ------------------------------------------------------------------ 渲染
def loc(item):
    if item.get("file") and item.get("line"):
        return f"{item['file']}:{item['line']}"
    return item.get("file") or "无源码位置"


def lint_name(code, s):
    """紧凑行里把 clippy:: 前缀调暗，突出 lint 本名。"""
    if code == "*":
        return "全部诊断"
    if code.startswith("clippy::"):
        return s.dim("clippy::") + code[len("clippy::"):]
    return code


def clip(text, cols):
    if width(text) <= cols:
        return text
    out = ""
    for ch in text:
        if width(out + ch) > cols - 1:
            break
        out += ch
    return out + "…"


def summary_line(res, s):
    """一行说明这个 case 实际发生了什么（不是契约是否满足）。"""
    parts = []
    for o in res["observed"]:
        name = lint_name(o["code"], s)
        if o["actual"] != o["expected"]:
            text = s.red(f"{'全部诊断' if o['code'] == '*' else o['code']} 期望 {o['expected']} 实际 {o['actual']}")
        else:
            text = f"{name} {s.times}{o['actual']}"
            lines = [n for n in o["lines"] if n is not None]
            if lines and len(lines) <= 3:
                text += s.dim(" L" + ",".join(str(n) for n in lines))
        if o.get("expected_since"):
            text += s.yellow(f" [按 {o['expected_since']}+ 判定]")
        parts.append(text)
    if res["errors"] and not res["build_ok"]:
        first = res["errors"][0]
        codes = sorted({e["code"] for e in res["errors"] if e["code"]})
        what = ",".join(codes) if codes else clip(first["message"], 36)
        parts.append(f"编译失败 {what} " + s.dim(loc(first)))
    elif not res["observed"]:
        parts.append("编译通过")
    if res["stdout"] is not None:
        out = " / ".join(res["stdout"].strip().splitlines()[:3])
        parts.append(f"输出 {clip(out, 60)}" if out else "输出为空")
    return f" {s.dot} ".join(parts)


def print_case_line(res, s, cat_width):
    mark = s.green(s.ok) if res["status"] == "PASS" else s.red(s.bad)
    seq = res["id"].rsplit("-", 1)[-1]
    cat = pad(res["category"], cat_width)
    print(f"  {mark} {seq}  {s.cyan(cat)}  {summary_line(res, s)}")


def evidence_blocks(res):
    """本 case 计入断言的诊断与编译错误的渲染原文（去重，保持编译器输出顺序）。"""
    blocks, seen = [], set()
    for o in res["observed"]:
        for d in o["diagnostics"]:
            if d.get("rendered") and d["rendered"] not in seen:
                seen.add(d["rendered"])
                blocks.append(d["rendered"])
    for e in res["errors"]:
        # 跳过 "aborting due to …" 这类没有源码位置的收尾信息
        if e.get("rendered") and e.get("file") and e["rendered"] not in seen:
            seen.add(e["rendered"])
            blocks.append(e["rendered"])
    return blocks


def print_rendered(blocks, s, title, dim=False, status_lines=()):
    """原样回显编译器输出，左侧加竖线以便与脚本自身的文字区分。

    blocks 是诊断的 rendered 原文；status_lines 是 cargo 自身写到 stderr 的状态行
    （Checking / Finished / could not compile），按真实终端中的顺序放在前后。
    """
    if not blocks and not status_lines:
        return
    bar = s.dim("│") if s.rule == "─" else s.dim("|")
    show = lambda text: text if s.color else ANSI_RE.sub("", text)  # noqa: E731
    head = [ln for ln in status_lines if ln.lstrip().startswith(("Compiling", "Checking"))]
    tail = [ln for ln in status_lines if ln not in head]
    print(f"       {s.dim(title)}")
    for line in head:
        print(f"       {bar} {s.dim(show(line))}")
    for block in blocks:
        for line in show(block).rstrip("\n").splitlines():
            print(f"       {bar} {s.dim(line) if dim else line}")
        print(f"       {bar}")
    for line in tail:
        print(f"       {bar} {s.dim(show(line))}")


def print_details(res, s, toolchain_label):
    ind = "       "
    label = lambda t: s.dim(pad(t, 8))  # noqa: E731
    print(f"{ind}{label('场景')}{res['title']}")
    print(f"{ind}{label('命令')}{shlex.join(res['command'])}")
    if res["lint_rules"]:
        rules = ", ".join(f"{r['level']} {r['lint']}" + ("（组）" if r["is_group"] else "") for r in res["lint_rules"])
        print(f"{ind}{label('lint')}{rules}；其余为 {toolchain_label} 默认等级")
    else:
        print(f"{ind}{label('lint')}未显式传参，全部为 {toolchain_label} 默认等级")
    cfg = res["clippy_config"]
    if cfg:
        items = ", ".join(f"{k} = {json.dumps(v, ensure_ascii=False)}" for k, v in cfg["settings"].items())
        print(f"{ind}{label('配置')}{cfg['path']}：{items}")
    else:
        print(f"{ind}{label('配置')}无 clippy.toml，使用 Clippy 默认值")
    for i, o in enumerate(res["observed"]):
        name = "全部诊断" if o["code"] == "*" else o["code"]
        ok = o["actual"] == o["expected"]
        since = f"（{o['expected_since']}+）" if o.get("expected_since") else ""
        verdict = s.green(f"实际 {o['actual']}") if ok else s.red(f"实际 {o['actual']}")
        where = "，位置 " + "、".join(loc(d) for d in o["diagnostics"]) if o["diagnostics"] else ""
        print(f"{ind}{label('断言' if i == 0 else '')}{name}：期望 {o['expected']}{since}，{verdict}{where}")
    if not res["expect_build_ok"] or res["errors"]:
        want = "编译成功" if res["expect_build_ok"] else "编译失败"
        got = "编译成功" if res["build_ok"] else "编译失败"
        print(f"{ind}{label('编译')}期望{want}，实际{got}")
    for d in res["ignored_diagnostics"]:
        print(f"{ind}{label('已排除')}{loc(d)}  {d['code']}（case.toml ignore，不计入「全部诊断」）")
    if res["stdout"] is not None:
        lines = res["stdout"].rstrip("\n").splitlines() or ["<空输出>"]
        for i, line in enumerate(lines):
            print(f"{ind}{label('输出' if i == 0 else '')}| {line}")
    for p in res["problems"]:
        print(f"{ind}{label('不一致')}{s.red(p)}")
    print(f"{ind}{label('结论')}{res['conclusion']}")
    if res["version_note"]:
        print(f"{ind}{label('版本')}{res['version_note']}")
    print(f"{ind}{label('日志')}{res['log']}")


def write_junit(path, results, elapsed):
    def attr(text):
        return xml_escape(text, {'"': "&quot;"})

    failures = sum(r["status"] != "PASS" for r in results)
    cases = []
    for r in results:
        body = ""
        if r["status"] != "PASS":
            body = f'<failure message="{attr(r["problems"][0])}">{xml_escape(chr(10).join(r["problems"]))}</failure>'
        cases.append(f'  <testcase classname="{attr(r["rule"])}" name="{attr(r["id"] + " " + r["title"])}" '
                     f'time="{r["seconds"]}">{body}</testcase>')
    xml = (f'<?xml version="1.0" encoding="UTF-8"?>\n<testsuite name="guideline-poc" tests="{len(results)}" '
           f'failures="{failures}" time="{elapsed:.2f}">\n' + "\n".join(cases) + "\n</testsuite>\n")
    pathlib.Path(path).write_text(xml, encoding="utf-8")


# ------------------------------------------------------------------ 入口
def load_rule_titles():
    path = CASES / "rules.toml"
    return tomllib.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}


def discover(filters, categories):
    titles = load_rule_titles()
    order = {rule: i for i, rule in enumerate(titles)}
    found = []
    for path in CASES.rglob("case.toml"):
        if "target" in path.parts:
            continue
        spec = tomllib.loads(path.read_text(encoding="utf-8"))
        found.append((path.parent, spec))
    found.sort(key=lambda item: (order.get(item[1]["rule"], len(order)), item[1]["id"]))
    if filters:
        keys = [f.lower().replace(".", "-") for f in filters]
        found = [(d, sp) for d, sp in found
                 if any(k in posix(d).lower() or k in sp["id"].lower().replace(".", "-") for k in keys)]
    if categories:
        found = [(d, sp) for d, sp in found if sp["category"] in categories]
    return found, titles


def main():
    parser = argparse.ArgumentParser(description="运行规范 POC 并按 case.toml 契约判定。",
                                     formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    parser.add_argument("filters", nargs="*", help="按路径或 ID 过滤，如 g-err-01、G.ERR.01-03")
    parser.add_argument("-v", "--verbose", action="store_true", help="每个 case 都打印完整证据（默认只为失败的 case 打印）")
    parser.add_argument("-b", "--brief", action="store_true", help="不回显编译器原文，只保留每个 case 一行")
    parser.add_argument("-q", "--quiet", action="store_true", help="只打印失败的 case 和汇总")
    parser.add_argument("-j", "--jobs", type=int, default=min(4, os.cpu_count() or 1), help="并行运行的 case 数（默认 %(default)s）")
    parser.add_argument("--category", action="append", choices=CATEGORY_ORDER, help="只运行某类 case，可重复")
    parser.add_argument("--list", action="store_true", help="只列出将要运行的 case")
    parser.add_argument("--fail-fast", action="store_true", help="出现第一个不一致后停止提交新 case")
    parser.add_argument("--timeout", type=int, default=600, help="单个 cargo 命令超时秒数（默认 %(default)s）")
    parser.add_argument("--color", choices=["auto", "always", "never"], default="auto")
    parser.add_argument("--junit", metavar="PATH", help="另写一份 JUnit XML（供 CI 展示）")
    opts = parser.parse_args()

    for stream in (sys.stdout, sys.stderr):  # 控制台编码不支持中文时用 ? 代替，而不是崩溃
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    s = Style(opts.color, sys.stdout)
    cases, titles = discover(opts.filters, opts.category)
    if not cases:
        print(f"没有匹配的 case：{' '.join(opts.filters) or '（cases/guideline 为空）'}", file=sys.stderr)
        return 2
    cat_width = max(width(c) for c in CATEGORY_ORDER + [sp["category"] for _, sp in cases])

    if opts.list:
        current = None
        for d, sp in cases:
            if sp["rule"] != current:
                current = sp["rule"]
                print(s.bold(f"{current}  {titles.get(current, '')}"))
            print(f"  {sp['id'].rsplit('-', 1)[-1]}  {s.cyan(pad(sp['category'], cat_width))}  {sp['title']}  {s.dim(posix(d.relative_to(ROOT)))}")
        print(f"\n共 {len(cases)} 个 case")
        return 0

    tc = toolchain()
    if tc is None:
        print("找不到可用的 cargo clippy。请先安装：rustup component add clippy", file=sys.stderr)
        return 2
    rustc_version = version_tuple(tc["rustc"])
    version_label = ".".join(map(str, rustc_version))
    head = f"规范 POC {s.dot} {len(cases)} 个 case {s.dot} {tc['rustc']} {s.dot} 并行 {opts.jobs}"
    print(s.bold(head))
    if version_label != BASELINE:
        print(s.yellow(f"注意：评审基线为 {BASELINE}，本机为 {version_label}。"
                       f"版本差异 case 按 case.toml 中的 since 判定，其余结论以基线为准。"))
    print(s.dim(s.rule * min(72, max(40, width(head)))))

    env = dict(os.environ, CARGO_TERM_COLOR="never")
    started = time.monotonic()
    results = []
    progress = sys.stderr.isatty() and not opts.verbose
    stop = False
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, opts.jobs)) as pool:
        futures = {}
        pending = list(cases)
        current_rule = None
        printed_any = False

        def submit_more():
            while pending and len(futures) < opts.jobs * 2 and not stop:
                d, sp = pending.pop(0)
                futures[sp["id"]] = pool.submit(run_case, d, env, rustc_version, opts.timeout)

        submit_more()
        for d, sp in cases:
            if sp["id"] not in futures:
                break
            if progress:
                status = f"[{len(results) + 1}/{len(cases)}] 运行 {sp['id']} …"
                print(f"\r\033[K{s.dim(status)}", end="", file=sys.stderr, flush=True)
            res = futures.pop(sp["id"]).result()
            results.append(res)
            submit_more()
            if progress:
                print("\r\033[K", end="", file=sys.stderr, flush=True)
            failed = res["status"] != "PASS"
            if opts.quiet and not failed:
                continue
            if res["rule"] != current_rule:
                current_rule = res["rule"]
                print(("\n" if printed_any else "") + s.bold(f"{current_rule}  {titles.get(current_rule, '')}"))
                printed_any = True
            print_case_line(res, s, cat_width)
            if not opts.brief:
                blocks = evidence_blocks(res)
                title = "cargo clippy 实际输出：" if blocks else "cargo clippy 实际输出（目标 lint 无诊断）："
                print_rendered(blocks, s, title, status_lines=res["cargo_stderr"])
                noise = [d["rendered"] for d in res["ignored_diagnostics"] if d.get("rendered")]
                print_rendered(noise, s, "另有被 case.toml ignore 排除的诊断（与本条无关，不计入断言）：", dim=True)
            if opts.verbose or failed:
                print_details(res, s, f"rustc/Clippy {version_label}")
            if failed and opts.fail_fast:
                stop = True
                pending.clear()
        for fut in futures.values():
            fut.cancel()

    elapsed = time.monotonic() - started
    failed = [r for r in results if r["status"] != "PASS"]
    print("\n" + s.dim(s.rule * 72))
    verdict = f"{len(results) - len(failed)}/{len(results)} 符合预期"
    print((s.green(f"{s.ok} {verdict}") if not failed else s.red(f"{s.bad} {verdict}，{len(failed)} 个不一致"))
          + f"  {s.dot}  用时 {fmt_seconds(elapsed)}")
    counts = {}
    for r in results:
        counts[r["category"]] = counts.get(r["category"], 0) + 1
    ordered = [c for c in CATEGORY_ORDER if c in counts] + sorted(set(counts) - set(CATEGORY_ORDER))
    print("  类别  " + f" {s.dot} ".join(f"{c} {counts[c]}" for c in ordered))
    print(s.dim("  「符合预期」指实测与 case.toml 一致；漏报 / 误报类 case 符合预期，说明该缺陷确实存在。"))
    if failed:
        print("  不一致：" + "、".join(r["id"] for r in failed))
        print(f"  复查：python scripts/validate-guideline.py -v {failed[0]['id']}")

    ART.mkdir(parents=True, exist_ok=True)
    if not opts.filters and not opts.category and len(results) == len(cases):
        (ART / "results.json").write_text(json.dumps({"toolchain": tc, "cases": results},
                                                     ensure_ascii=False, indent=2), encoding="utf-8")
        print(s.dim(f"  结果  {posix((ART / 'results.json').relative_to(ROOT))}（运行 render-guideline-poc-list.py 刷新清单）"))
    else:
        print(s.dim("  结果  部分运行，未覆盖 results.json；原始诊断见 artifacts/guideline/logs/"))
    if opts.junit:
        write_junit(opts.junit, results, elapsed)
        print(s.dim(f"  JUnit {opts.junit}"))
    return 1 if failed else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n已中断", file=sys.stderr)
        raise SystemExit(130)
