#!/usr/bin/env python3
"""Render artifacts/guideline/results.json into docs/guideline-poc-list.md."""

import json
import re
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
RULE_ORDER = ["G.CTF.01", "G.CTF.02", "G.CTF.03", "G.EXP.01", "G.EXP.02", "G.FUD.01", "G.FUD.02",
              "G.TRA.01", "G.TRA.02", "G.ERR.01", "G.MOD.01", "G.MAC.01", "P.MAC.DCL.01",
              "G.MAC.DCL.01", "P.MAC.PRO.01"]

LINT_DESCRIPTIONS = {
    "clippy::all": "Clippy 默认主集合，覆盖 correctness、suspicious、style、complexity、perf 等常规 lint；不包含 pedantic、nursery、restriction、cargo。",
    "clippy::pedantic": "更严格、可能产生较多主观告警的可选 lint 组，适合提高代码一致性与可读性。",
    "clippy::nursery": "仍在培育、可能调整或迁移分组的新 lint 集合，用于扩大前瞻性检查范围。",
    "clippy::absurd_extreme_comparisons": "检查与类型最小值或最大值进行的不可能比较，例如无符号数小于 0。",
    "clippy::bad_bit_mask": "检查掩码和比较值不相容、导致条件恒真或恒假的位运算比较。",
    "clippy::cast_precision_loss": "检查整数转浮点数等可能丢失数值精度的类型转换。",
    "clippy::crate_in_macro_def": "检查导出宏定义中使用 `crate::`；通常应使用 `$crate::` 指向宏定义所在 crate。",
    "clippy::derive_ord_xor_partial_ord": "检查 `Ord` 与 `PartialOrd` 一边 derive、另一边手写的混合实现，避免排序语义不一致。",
    "clippy::derived_hash_with_manual_eq": "检查 derive(Hash) 与手写 PartialEq/Eq 的混合实现，避免相等值产生不同哈希。",
    "clippy::enum_glob_use": "检查 `use Enum::*` 形式的枚举变体通配导入。",
    "clippy::eq_op": "检查比较、运算两侧是同一表达式的情况，例如 `x == x`。",
    "clippy::expect_used": "检查对 Option/Result 调用 `expect()`，因为失败时会触发 panic。",
    "clippy::from_over_into": "检查直接实现 Into；通常应实现 From，由标准库自动提供对应的 Into。",
    "clippy::impossible_comparisons": "检查多个比较条件组合后不可能同时成立的范围判断。",
    "clippy::infinite_loop": "检查没有可见 `break`、`return` 等退出路径的 `loop`；有意不返回的 `-> !` 函数会被豁免。",
    "clippy::large_types_passed_by_value": "检查大型 Copy 类型按值传参造成的复制开销，建议按引用传递。",
    "clippy::let_underscore_must_use": "检查使用 `let _ =` 静默丢弃标有 must_use 的返回值。",
    "clippy::macro_metavars_in_unsafe": "检查宏元变量在宏生成的 unsafe 块中展开，避免调用者提供的表达式被隐式置于 unsafe 上下文。",
    "clippy::missing_const_for_fn": "检查函数是否可以声明为 `const fn`，属于 API/可用性建议。",
    "clippy::must_use_candidate": "检查返回值看起来不应被忽略、但函数或类型尚未标注 `#[must_use]` 的候选。",
    "clippy::needless_pass_by_value": "检查函数没有消费所有权却按值接收非 Copy 参数的情况，建议改为借用。",
    "clippy::non_canonical_partial_ord_impl": "检查实现了 Ord 的类型是否以规范方式实现 PartialOrd，通常应返回 `Some(self.cmp(other))`。",
    "clippy::overly_complex_bool_expr": "检查可以化简或包含恒真、恒假部分的复杂布尔表达式。",
    "clippy::panic": "检查生产代码中显式使用 `panic!` 等 panic 宏。",
    "clippy::precedence": "检查不同优先级运算符混用但缺少括号、容易被误读的表达式。",
    "clippy::precedence_bits": "检查位运算与移位运算混用时缺少括号导致的优先级歧义。",
    "clippy::undocumented_unsafe_blocks": "检查 unsafe 块或 unsafe impl 前是否缺少解释安全前提的 SAFETY 注释。",
    "clippy::unnecessary_unwrap": "检查已经用 is_some/is_ok 或相反条件确认变体后又调用 unwrap/unwrap_err 的写法，建议直接模式匹配。",
    "clippy::unnecessary_wraps": "检查函数始终只返回 Some/Ok 等单一包装形态、返回 Option/Result 可能没有必要的情况。",
    "clippy::unnested_or_patterns": "检查可以写成嵌套形式的 or-pattern；只关注模式写法，不检查 Guard 副作用。",
    "clippy::unused_result_ok": "检查把 Result 转成 Option 后立即丢弃的 `.ok()` 调用。",
    "clippy::unwrap_used": "检查对 Option/Result 调用 `unwrap()`，因为 None/Err 时会触发 panic。",
    "clippy::while_immutable_condition": "检查 while 条件依赖的变量在循环体中不发生变化，循环可能一次不进或永久不退出。",
    "clippy::wildcard_imports": "检查 `use module::*` 通配导入，避免命名来源不清或未来新增名称污染作用域。",
    "ambiguous_negative_literals": "rustc lint：检查负数字面量后直接调用方法等容易产生解析歧义的写法，建议加括号。",
    "unconditional_recursion": "rustc lint：检查函数所有可达执行路径都会递归调用自身、无法正常返回。",
    "unused_must_use": "rustc lint：检查忽略 Result 或其他标有 `#[must_use]` 的返回值。",
    "E0133": "rustc 诊断：在缺少所需 unsafe 块或 unsafe 上下文时执行不安全操作。",
    "E0261": "rustc 编译错误：使用了未声明的生命周期名称。",
    "E0308": "rustc 编译错误：表达式的实际类型与上下文期望类型不匹配。",
    "E0433": "rustc 编译错误：无法解析模块、类型、crate 或其他路径。",
}


def cell(text):
    return str(text).replace("|", "\\|").replace("\n", " ")


def lint_activation(code, rules):
    exact = [r for r in rules if r["lint"] == code]
    if exact:
        return ", ".join(f"`{r['flag']} {r['lint']}`" for r in exact)
    groups = [r for r in rules if r["is_group"]]
    if code == "*" and groups:
        return ", ".join(f"`{r['flag']} {r['lint']}`" for r in groups)
    if groups:
        names = ", ".join(f"`{r['lint']}`" for r in groups)
        return f"由已启用 lint 组覆盖或验证：{names}"
    return "未显式传递；使用工具链默认等级或验证零命中"


def lint_kind(name):
    if name.startswith("clippy::"):
        return "Clippy lint 组" if name in {"clippy::all", "clippy::pedantic", "clippy::nursery"} else "Clippy lint"
    if name.startswith("E") and name[1:].isdigit():
        return "rustc 诊断/错误码"
    return "rustc lint"


def case_lint_roles(case):
    roles = {}
    for rule in case.get("lint_rules", []):
        roles.setdefault(rule["lint"], []).append("显式启用的检查范围")
    for obs in case.get("observed", []):
        if obs["code"] != "*":
            roles.setdefault(obs["code"], []).append(f"目标诊断（期望 {obs['expected']}，实际 {obs['actual']}）")
    for diag in case.get("ignored_diagnostics", []):
        roles.setdefault(diag["code"], []).append("非目标诊断，已由 ignore 排除")
    for error in case.get("errors", []):
        if error.get("code"):
            roles.setdefault(error["code"], []).append("预期或实际编译诊断")
    return {name: "；".join(dict.fromkeys(items)) for name, items in roles.items()}


def render_case_readme(case, toolchain):
    lines = [
        f"# {case['id']} — {case['title']}",
        "",
        "> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。",
        "",
        f"- 规范条目：`{case['rule']}`",
        f"- 场景类别：{case['category']}",
        f"- 实测状态：**{case['status']}**",
        f"- 实跑工具链：`{toolchain['rustc']}`；`{toolchain['clippy']}`",
        "- 目标源码：" + "、".join(f"[`{f}`]({f.replace('\\', '/')})" for f in case.get("fixtures", [])),
        "",
        "## 实际检查配置",
        "",
        "在本 case 目录中可复现：",
        "",
        "```powershell",
        "cargo clippy --offline --all-targets --message-format=json -- " + " ".join(case["args"]),
        "```",
        "",
    ]
    if case["lint_rules"]:
        lines += ["实际显式传递的 lint 规则：", "", "| 等级 | 参数 | 规则 | 类型 |", "| --- | --- | --- | --- |"]
        for rule in case["lint_rules"]:
            kind = "lint 组（由当前工具链展开）" if rule["is_group"] else "单项 lint"
            lines.append(f"| {rule['level']} | `{rule['flag']}` | `{rule['lint']}` | {kind} |")
    else:
        lines += ["没有显式传递 `-W/-D/-A/-F`；rustc 和 Clippy 的默认 lint 等级仍然生效。"]

    roles = case_lint_roles(case)
    lines += ["", "## 本 case 涉及的 lint 及作用", ""]
    if roles:
        lines += ["| 规则 | 类型 | 作用 | 在本 case 中的角色 |", "| --- | --- | --- | --- |"]
        for name, role in roles.items():
            description = LINT_DESCRIPTIONS.get(name, "当前目录未登记说明；以工具链诊断消息为准。")
            lines.append(f"| `{name}` | {lint_kind(name)} | {description} | {role} |")
    else:
        lines.append("本 case 不依赖具体 lint；通过编译结果或运行时行为验证规范描述。")

    lines += ["", "Clippy 行为配置：", ""]
    config = case.get("clippy_config")
    if config:
        lines.append(f"- 配置文件：`{config['path']}`（{config['source']}）")
        for key, value in config["settings"].items():
            lines.append(f"- `{key} = {json.dumps(value, ensure_ascii=False)}`")
    else:
        lines.append("- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。")

    lines += [
        "",
        "## 对应位置需要什么 lint",
        "",
        "| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |",
        "| --- | --- | ---: | ---: | --- |",
    ]
    if case["observed"]:
        for obs in case["observed"]:
            locations = sorted({f"`{d['file']}:{d['line']}`" for d in obs.get("diagnostics", [])})
            where = "、".join(locations) if locations else "无命中；结合类别与结论判断为漏报、边界或合规"
            target = "所有相关 lint" if obs["code"] == "*" else f"`{obs['code']}`"
            lines.append(
                f"| {target} | {lint_activation(obs['code'], case['lint_rules'])} | "
                f"{obs['expected']} | {obs['actual']} | {where} |"
            )
    elif case["errors"]:
        error_codes = ", ".join(f"`{e['code'] or '无错误码'}`" for e in case["errors"])
        locations = "、".join(
            f"`{e['file']}:{e['line']}`" for e in case["errors"] if e.get("file") and e.get("line")
        ) or "无源码位置"
        lines.append(f"| rustc 编译错误 {error_codes} | 不需要 Clippy lint | 编译失败 | 编译失败 | {locations} |")
    else:
        lines.append("| 编译/运行语义 | 不需要特定 Clippy lint | 编译成功 | 编译成功 | 见目标源码与运行输出 |")

    lines += ["", "## 实际证据", ""]
    emitted = False
    ansi = re.compile(r"\x1b\[[0-9;]*m")
    rendered, summary, seen = [], [], set()
    items = [d for obs in case["observed"] for d in obs.get("diagnostics", [])]
    items += [e | {"level": "error"} for e in case["errors"] if e.get("file")]
    for item in items:
        code = item.get("code") or "无错误码"
        key = item.get("rendered") or f"{item['level']}[{code}] {item['file']}:{item['line']}: {item['message']}"
        if key in seen:
            continue
        seen.add(key)
        if item.get("rendered"):
            rendered.append(ansi.sub("", item["rendered"]).rstrip("\n"))
        else:
            summary.append(f"- `{item['level']}[{code}]` `{item['file']}:{item['line']}`：{item['message']}")
    if rendered:
        lines += ["编译器原始输出（`cargo clippy` 渲染结果，未经改写）：", "", "```text", "\n\n".join(rendered), "```"]
        emitted = True
    if summary:
        lines += summary
        emitted = True
    if not emitted:
        lines.append("- 没有目标 lint / 编译错误诊断；这本身是本 case 要验证的实际结果。")

    ignored = case.get("ignored_diagnostics", [])
    if ignored:
        lines += ["", "非目标诊断（由 `case.toml` 的 `ignore` 排除）：", ""]
        for diag in ignored:
            lines.append(f"- `{diag['level']}[{diag['code']}]` `{diag['file']}:{diag['line']}`：{diag['message']}")

    if case.get("stdout") is not None:
        lines += ["", "实际运行输出：", "", "```text", case["stdout"].rstrip("\n") or "<空输出>", "```"]

    lines += ["", "## 结论", "", case["conclusion"]]
    if case.get("version_note"):
        lines += ["", f"版本说明：{case['version_note']}"]
    lines.append("")
    return "\n".join(lines)


def main():
    data = json.loads((ROOT / "artifacts/guideline/results.json").read_text())
    cases = data["cases"]
    tc = data["toolchain"]
    passed = sum(c["status"] == "PASS" for c in cases)
    out = [
        "# 规范评审 POC 清单",
        "",
        f"- 实跑工具链：`{tc['rustc']}`，`{tc['clippy']}`",
        "- lint 存在性与分组基线：rustc / Clippy **1.89.0** 源码（rust-lang/rust@1.89.0、rust-clippy@rust-1.89.0）",
        f"- 结果：{passed}/{len(cases)} PASS（PASS 表示实测结果与 case.toml 中声明的预期完全一致，预期本身可以是 0 次命中或编译失败）",
        "- 运行：`python scripts/validate-guideline.py [过滤串]`，原始 Cargo JSON 在 `artifacts/guideline/logs/`",
        "",
        "类别说明：**命中**＝lint 能检出；**漏报**＝条款要求覆盖但 lint 不报；**误报 / 误报风险**＝条款允许或意图正常但 lint 报警；"
        "**边界**＝lint 的豁免与条款一致；**语义验证**＝验证条款描述的运行时行为；**示例校验**＝验证原文或修订稿示例能否编译、行为是否正确；"
        "**版本差异**＝1.89 与实跑版本行为不同，结论来自源码比对。",
        "",
        "「*」表示在 `clippy::all + pedantic + nursery` 下该 fixture 的全部 lint 告警数（已排除与本条无关的噪声 lint）。",
        "",
    ]
    for rule in RULE_ORDER:
        group = [c for c in cases if c["rule"] == rule]
        if not group:
            continue
        out += [f"## {rule}", "", "| ID | 类别 | 场景 | 预期 → 实测 | 结论 | 状态 |", "| --- | --- | --- | --- | --- | --- |"]
        for c in group:
            obs = []
            for o in c["observed"]:
                obs.append(f"`{o['code']}` {o['expected']}→{o['actual']}")
            if c["errors"]:
                obs.append("编译失败：" + cell(c["errors"][0]["message"]))
            elif not c["observed"]:
                obs.append("编译通过")
            if c["stdout"]:
                obs.append("输出：`" + cell(c["stdout"].strip().replace("\n", " / ")) + "`")
            concl = c["conclusion"]
            if c["version_note"]:
                concl += "<br>**版本说明**：" + c["version_note"]
            title = f"{cell(c['title'])}<br>`{c['path']}`"
            out.append(f"| {c['id']} | {c['category']} | {title} | {'<br>'.join(obs)} | {cell(concl)} | {c['status']} |")
        out.append("")
    (ROOT / "docs/guideline-poc-list.md").write_text("\n".join(out))
    print("wrote docs/guideline-poc-list.md")
    for case in cases:
        case_dir = ROOT / case["path"]
        (case_dir / "README.md").write_text(render_case_readme(case, tc))
    print(f"wrote {len(cases)} case README files")
    used_lints = {}
    for case in cases:
        for name, role in case_lint_roles(case).items():
            used_lints.setdefault(name, set()).add(case["id"])
    catalog = [
        "# Playground 实际涉及的 lint 说明",
        "",
        "> 本文件由 `scripts/render-guideline-poc-list.py` 根据最近一次实测结果生成。",
        "",
        "| 规则 | 类型 | 作用 | 涉及 case |",
        "| --- | --- | --- | --- |",
    ]
    for name in sorted(used_lints):
        description = LINT_DESCRIPTIONS.get(name, "当前目录未登记说明；以工具链诊断消息为准。")
        ids = "、".join(f"`{case_id}`" for case_id in sorted(used_lints[name]))
        catalog.append(f"| `{name}` | {lint_kind(name)} | {description} | {ids} |")
    (ROOT / "docs/lint-catalog.md").write_text("\n".join(catalog) + "\n")
    print(f"wrote docs/lint-catalog.md ({len(used_lints)} rules)")


if __name__ == "__main__":
    main()
