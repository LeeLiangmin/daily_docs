# Playground 实际涉及的 lint 说明

> 本文件由 `scripts/render-guideline-poc-list.py` 根据最近一次实测结果生成。

| 规则 | 类型 | 作用 | 涉及 case |
| --- | --- | --- | --- |
| `E0133` | rustc 诊断/错误码 | rustc 诊断：在缺少所需 unsafe 块或 unsafe 上下文时执行不安全操作。 | `G.MAC.01-05` |
| `E0261` | rustc 诊断/错误码 | rustc 编译错误：使用了未声明的生命周期名称。 | `P.MAC.DCL.01-01` |
| `E0308` | rustc 诊断/错误码 | rustc 编译错误：表达式的实际类型与上下文期望类型不匹配。 | `G.CTF.01-04` |
| `E0433` | rustc 诊断/错误码 | rustc 编译错误：无法解析模块、类型、crate 或其他路径。 | `P.MAC.DCL.01-05` |
| `ambiguous_negative_literals` | rustc lint | rustc lint：检查负数字面量后直接调用方法等容易产生解析歧义的写法，建议加括号。 | `G.EXP.02-02` |
| `clippy::absurd_extreme_comparisons` | Clippy lint | 检查与类型最小值或最大值进行的不可能比较，例如无符号数小于 0。 | `G.EXP.01-02` |
| `clippy::all` | Clippy lint 组 | Clippy 默认主集合，覆盖 correctness、suspicious、style、complexity、perf 等常规 lint；不包含 pedantic、nursery、restriction、cargo。 | `G.CTF.01-02`、`G.CTF.01-05`、`G.CTF.02-01`、`G.CTF.03-07`、`G.EXP.01-03`、`G.EXP.02-04`、`G.FUD.02-04`、`G.MAC.DCL.01-01`、`G.TRA.01-04` |
| `clippy::bad_bit_mask` | Clippy lint | 检查掩码和比较值不相容、导致条件恒真或恒假的位运算比较。 | `G.EXP.01-01`、`G.EXP.01-04` |
| `clippy::cast_precision_loss` | Clippy lint | 检查整数转浮点数等可能丢失数值精度的类型转换。 | `G.CTF.01-05` |
| `clippy::crate_in_macro_def` | Clippy lint | 检查导出宏定义中使用 `crate::`；通常应使用 `$crate::` 指向宏定义所在 crate。 | `P.MAC.DCL.01-04` |
| `clippy::derive_ord_xor_partial_ord` | Clippy lint | 检查 `Ord` 与 `PartialOrd` 一边 derive、另一边手写的混合实现，避免排序语义不一致。 | `G.TRA.01-02`、`G.TRA.01-03`、`G.TRA.01-05` |
| `clippy::derived_hash_with_manual_eq` | Clippy lint | 检查 derive(Hash) 与手写 PartialEq/Eq 的混合实现，避免相等值产生不同哈希。 | `G.TRA.01-01`、`G.TRA.01-04`、`G.TRA.01-05` |
| `clippy::enum_glob_use` | Clippy lint | 检查 `use Enum::*` 形式的枚举变体通配导入。 | `G.MOD.01-04` |
| `clippy::eq_op` | Clippy lint | 检查比较、运算两侧是同一表达式的情况，例如 `x == x`。 | `G.EXP.01-02` |
| `clippy::expect_used` | Clippy lint | 检查对 Option/Result 调用 `expect()`，因为失败时会触发 panic。 | `G.ERR.01-02`、`G.ERR.01-03`、`G.ERR.01-06` |
| `clippy::from_over_into` | Clippy lint | 检查直接实现 Into；通常应实现 From，由标准库自动提供对应的 Into。 | `G.TRA.02-01`、`G.TRA.02-02` |
| `clippy::impossible_comparisons` | Clippy lint | 检查多个比较条件组合后不可能同时成立的范围判断。 | `G.EXP.01-02` |
| `clippy::infinite_loop` | Clippy lint | 检查没有可见 `break`、`return` 等退出路径的 `loop`；有意不返回的 `-> !` 函数会被豁免。 | `G.CTF.03-01`、`G.CTF.03-02`、`G.CTF.03-03`、`G.CTF.03-04` |
| `clippy::large_types_passed_by_value` | Clippy lint | 检查大型 Copy 类型按值传参造成的复制开销，建议按引用传递。 | `G.FUD.01-01`、`G.FUD.01-02`、`G.FUD.01-03`、`G.FUD.01-04` |
| `clippy::macro_metavars_in_unsafe` | Clippy lint | 检查宏元变量在宏生成的 unsafe 块中展开，避免调用者提供的表达式被隐式置于 unsafe 上下文。 | `G.MAC.01-01`、`G.MAC.01-02`、`G.MAC.01-03`、`G.MAC.01-04`、`G.MAC.01-06` |
| `clippy::missing_const_for_fn` | Clippy lint | 检查函数是否可以声明为 `const fn`，属于 API/可用性建议。 | `G.EXP.01-03`、`G.EXP.02-04`、`G.FUD.02-04` |
| `clippy::must_use_candidate` | Clippy lint | 检查返回值看起来不应被忽略、但函数或类型尚未标注 `#[must_use]` 的候选。 | `G.CTF.01-02`、`G.CTF.01-05`、`G.CTF.03-07`、`G.EXP.01-03`、`G.EXP.02-04` |
| `clippy::needless_pass_by_value` | Clippy lint | 检查函数没有消费所有权却按值接收非 Copy 参数的情况，建议改为借用。 | `G.FUD.01-04` |
| `clippy::non_canonical_partial_ord_impl` | Clippy lint | 检查实现了 Ord 的类型是否以规范方式实现 PartialOrd，通常应返回 `Some(self.cmp(other))`。 | `G.TRA.01-03`、`G.TRA.01-05` |
| `clippy::nursery` | Clippy lint 组 | 仍在培育、可能调整或迁移分组的新 lint 集合，用于扩大前瞻性检查范围。 | `G.CTF.01-02`、`G.CTF.01-05`、`G.CTF.02-01`、`G.CTF.03-07`、`G.EXP.01-03`、`G.EXP.02-04`、`G.FUD.02-04`、`G.MAC.DCL.01-01`、`G.TRA.01-04` |
| `clippy::overly_complex_bool_expr` | Clippy lint | 检查可以化简或包含恒真、恒假部分的复杂布尔表达式。 | `G.EXP.01-01` |
| `clippy::pedantic` | Clippy lint 组 | 更严格、可能产生较多主观告警的可选 lint 组，适合提高代码一致性与可读性。 | `G.CTF.01-02`、`G.CTF.01-05`、`G.CTF.02-01`、`G.CTF.03-07`、`G.EXP.01-03`、`G.EXP.02-04`、`G.FUD.02-04`、`G.MAC.DCL.01-01`、`G.TRA.01-04` |
| `clippy::precedence` | Clippy lint | 检查不同优先级运算符混用但缺少括号、容易被误读的表达式。 | `G.EXP.02-01`、`G.EXP.02-02`、`G.EXP.02-03` |
| `clippy::precedence_bits` | Clippy lint | 检查位运算与移位运算混用时缺少括号导致的优先级歧义。 | `G.EXP.02-03` |
| `clippy::unnecessary_unwrap` | Clippy lint | 检查已经用 is_some/is_ok 或相反条件确认变体后又调用 unwrap/unwrap_err 的写法，建议直接模式匹配。 | `G.CTF.01-01`、`G.CTF.01-02`、`G.CTF.01-03` |
| `clippy::unnecessary_wraps` | Clippy lint | 检查函数始终只返回 Some/Ok 等单一包装形态、返回 Option/Result 可能没有必要的情况。 | `G.FUD.02-04` |
| `clippy::unnested_or_patterns` | Clippy lint | 检查可以写成嵌套形式的 or-pattern；只关注模式写法，不检查 Guard 副作用。 | `G.CTF.02-01` |
| `clippy::unwrap_used` | Clippy lint | 检查对 Option/Result 调用 `unwrap()`，因为 None/Err 时会触发 panic。 | `G.ERR.01-01`、`G.ERR.01-02`、`G.ERR.01-03`、`G.ERR.01-04`、`G.ERR.01-05`、`G.ERR.01-06` |
| `clippy::while_immutable_condition` | Clippy lint | 检查 while 条件依赖的变量在循环体中不发生变化，循环可能一次不进或永久不退出。 | `G.CTF.03-05` |
| `clippy::wildcard_imports` | Clippy lint | 检查 `use module::*` 通配导入，避免命名来源不清或未来新增名称污染作用域。 | `G.MOD.01-01`、`G.MOD.01-02`、`G.MOD.01-03`、`G.MOD.01-04` |
| `unconditional_recursion` | rustc lint | rustc lint：检查函数所有可达执行路径都会递归调用自身、无法正常返回。 | `G.CTF.03-06`、`G.CTF.03-07` |
| `unused_must_use` | rustc lint | rustc lint：检查忽略 Result 或其他标有 `#[must_use]` 的返回值。 | `G.FUD.02-01`、`G.FUD.02-02`、`G.FUD.02-03`、`G.FUD.02-04` |
