# Clippy 配置与覆盖边界

## 配置分两层

`config/Cargo.toml.lints.example` 负责开启 lint 与设置等级；`config/clippy.toml` 负责改变 lint 的行为参数。二者不能互相替代。

每个 PoC 为了隔离变量，直接在 `case.toml` 的 `args` 中声明本场景所需 lint，例如：

```toml
args = ["-W", "clippy::unwrap_used", "-W", "clippy::expect_used"]
```

行为参数只放在对应 case 的 `clippy.toml`。当前有三套关键配置：

| 条目 | 参数 | 作用 |
| --- | --- | --- |
| G.FUD.01 | `avoid-breaking-exported-api = false` | 不跳过公共 API 的大类型按值传递 |
| G.MAC.01 | `warn-unsafe-macro-metavars-in-private-macros = true` | 把私有声明宏纳入 unsafe 元变量检查 |
| G.ERR.01（项目建议） | `allow-unwrap-in-tests = true`、`allow-expect-in-tests = true` | 避免把仅限测试的 unwrap/expect 与生产代码同等处理 |

## 不能只靠配置解决的条目

- G.CTF.02：或模式 Guard 的重复副作用没有对应 lint。
- G.EXP.01：`x % 2 == 2`、`x != 1 || x != 2` 等恒值表达式仍会漏报。
- G.EXP.02：`&&`/`||` 混用不加括号仍会漏报。
- G.TRA.01：Hash/Eq/Ord 全部手写时的一致性只能靠测试与评审。
- G.MAC.01：过程宏生成的 unsafe 和宏内硬编码 unsafe 不在 `macro_metavars_in_unsafe` 的能力范围。
- G.MAC.DCL.01、P.MAC.PRO.01：宏规则顺序与过程宏卫生性主要依赖编译/运行用例，而不是 Clippy。

因此，项目配置只能作为自动门禁的一层；`docs/guideline-poc-list.md` 中标记为“漏报”或“语义验证”的场景仍需代码评审或专门测试。
