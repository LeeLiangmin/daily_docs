# G.TRA.01-05 — 修订稿 Ord 正例：相等性与排序口径一致

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.TRA.01`
- 场景类别：示例校验
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/main.rs`](src/main.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::derive_ord_xor_partial_ord -W clippy::non_canonical_partial_ord_impl -W clippy::derived_hash_with_manual_eq
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::derive_ord_xor_partial_ord` | 单项 lint |
| WARN | `-W` | `clippy::non_canonical_partial_ord_impl` | 单项 lint |
| WARN | `-W` | `clippy::derived_hash_with_manual_eq` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::derive_ord_xor_partial_ord` | Clippy lint | 检查 `Ord` 与 `PartialOrd` 一边 derive、另一边手写的混合实现，避免排序语义不一致。 | 显式启用的检查范围；目标诊断（期望 0，实际 0） |
| `clippy::non_canonical_partial_ord_impl` | Clippy lint | 检查实现了 Ord 的类型是否以规范方式实现 PartialOrd，通常应返回 `Some(self.cmp(other))`。 | 显式启用的检查范围；目标诊断（期望 0，实际 0） |
| `clippy::derived_hash_with_manual_eq` | Clippy lint | 检查 derive(Hash) 与手写 PartialEq/Eq 的混合实现，避免相等值产生不同哈希。 | 显式启用的检查范围；目标诊断（期望 0，实际 0） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::derive_ord_xor_partial_ord` | `-W clippy::derive_ord_xor_partial_ord` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |
| `clippy::non_canonical_partial_ord_impl` | `-W clippy::non_canonical_partial_ord_impl` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |
| `clippy::derived_hash_with_manual_eq` | `-W clippy::derived_hash_with_manual_eq` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |

## 实际证据

- 没有目标 lint / 编译错误诊断；这本身是本 case 要验证的实际结果。

实际运行输出：

```text
eq=true cmp=Equal names=ab
```

## 结论

PartialEq 与 Ord 均以 uid 为准，partial_cmp 采用规范写法 Some(self.cmp(other))，相关 lint 零告警。
