# G.TRA.01-03 — 原文 Ord「正例」实际违反 Ord 与 Eq 的一致性

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.TRA.01`
- 场景类别：示例校验
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/main.rs`](src/main.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::derive_ord_xor_partial_ord -W clippy::non_canonical_partial_ord_impl
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::derive_ord_xor_partial_ord` | 单项 lint |
| WARN | `-W` | `clippy::non_canonical_partial_ord_impl` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::derive_ord_xor_partial_ord` | Clippy lint | 检查 `Ord` 与 `PartialOrd` 一边 derive、另一边手写的混合实现，避免排序语义不一致。 | 显式启用的检查范围；目标诊断（期望 0，实际 0） |
| `clippy::non_canonical_partial_ord_impl` | Clippy lint | 检查实现了 Ord 的类型是否以规范方式实现 PartialOrd，通常应返回 `Some(self.cmp(other))`。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::derive_ord_xor_partial_ord` | `-W clippy::derive_ord_xor_partial_ord` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |
| `clippy::non_canonical_partial_ord_impl` | `-W clippy::non_canonical_partial_ord_impl` | 1 | 1 | `src/main.rs:9` |

## 实际证据

- `warning[clippy::non_canonical_partial_ord_impl]` `src/main.rs:9`：non-canonical implementation of `partial_cmp` on an `Ord` type

实际运行输出：

```text
eq=false cmp=Equal
btreeset_len=1
```

## 结论

PartialEq/Eq 由 derive 比较全部字段，Ord 只比较 uid，于是出现 a != b 但 a.cmp(&b) == Equal，BTreeSet 会把两人当作同一元素丢掉一个。这违反了 Ord 文档中「与 Eq 一致」的要求，原文却标为「符合」。该问题没有 lint 能发现（non_canonical_partial_ord_impl 只提示 partial_cmp 写法不规范）。
