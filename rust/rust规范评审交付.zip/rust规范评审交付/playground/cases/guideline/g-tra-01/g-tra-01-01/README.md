# G.TRA.01-01 — 原文反例：derive(Hash) + 手写 PartialEq

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.TRA.01`
- 场景类别：命中
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::derived_hash_with_manual_eq
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::derived_hash_with_manual_eq` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::derived_hash_with_manual_eq` | Clippy lint | 检查 derive(Hash) 与手写 PartialEq/Eq 的混合实现，避免相等值产生不同哈希。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::derived_hash_with_manual_eq` | `-W clippy::derived_hash_with_manual_eq` | 1 | 1 | `src/lib.rs:1` |

## 实际证据

- `warning[clippy::derived_hash_with_manual_eq]` `src/lib.rs:1`：you are deriving `Hash` but have implemented `PartialEq` explicitly

## 结论

可检出（correctness，默认 deny）。
