# G.MAC.DCL.01-02 — 片段解析一旦开始就不回溯：`$e:expr` 在前时 `m!(1 +)` 直接报错

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.MAC.DCL.01`
- 场景类别：语义验证
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- 
```

没有显式传递 `-W/-D/-A/-F`；rustc 和 Clippy 的默认 lint 等级仍然生效。

## 本 case 涉及的 lint 及作用

本 case 不依赖具体 lint；通过编译结果或运行时行为验证规范描述。

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| rustc 编译错误 `无错误码` | 不需要 Clippy lint | 编译失败 | 编译失败 | `src/lib.rs:7` |

## 实际证据

- `error[无错误码]` `src/lib.rs:7`：expected expression, found end of macro arguments

## 结论

规则顺序还影响能否编译：前面的规则已开始解析 expr 片段并失败时，编译器直接报错，不会尝试后续 tt 规则。修订稿在【说明】中补充这一点。
