# G.FUD.02-01 — 忽略 must_use 函数 / must_use 类型 / Result 返回值

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.FUD.02`
- 场景类别：命中
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- 
```

没有显式传递 `-W/-D/-A/-F`；rustc 和 Clippy 的默认 lint 等级仍然生效。

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `unused_must_use` | rustc lint | rustc lint：检查忽略 Result 或其他标有 `#[must_use]` 的返回值。 | 目标诊断（期望 3，实际 3） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `unused_must_use` | 未显式传递；使用工具链默认等级或验证零命中 | 3 | 3 | `src/lib.rs:12`、`src/lib.rs:13`、`src/lib.rs:14` |

## 实际证据

- `warning[unused_must_use]` `src/lib.rs:12`：unused return value of `foo1` that must be used
- `warning[unused_must_use]` `src/lib.rs:13`：unused `MyError` that must be used
- `warning[unused_must_use]` `src/lib.rs:14`：unused `std::result::Result` that must be used

## 结论

三种方式均触发 rustc unused_must_use（默认 warn）。原文写的 `rustc::unused_must_use` 不是合法写法，rustc 内建 lint 没有工具前缀，应写为 unused_must_use。
