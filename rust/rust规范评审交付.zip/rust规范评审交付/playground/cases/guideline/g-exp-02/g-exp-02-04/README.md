# G.EXP.02-04 — `&&` 与 `||` 混用不报

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.EXP.02`
- 场景类别：漏报
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::all -W clippy::pedantic -W clippy::nursery
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::all` | lint 组（由当前工具链展开） |
| WARN | `-W` | `clippy::pedantic` | lint 组（由当前工具链展开） |
| WARN | `-W` | `clippy::nursery` | lint 组（由当前工具链展开） |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::all` | Clippy lint 组 | Clippy 默认主集合，覆盖 correctness、suspicious、style、complexity、perf 等常规 lint；不包含 pedantic、nursery、restriction、cargo。 | 显式启用的检查范围 |
| `clippy::pedantic` | Clippy lint 组 | 更严格、可能产生较多主观告警的可选 lint 组，适合提高代码一致性与可读性。 | 显式启用的检查范围 |
| `clippy::nursery` | Clippy lint 组 | 仍在培育、可能调整或迁移分组的新 lint 集合，用于扩大前瞻性检查范围。 | 显式启用的检查范围 |
| `clippy::must_use_candidate` | Clippy lint | 检查返回值看起来不应被忽略、但函数或类型尚未标注 `#[must_use]` 的候选。 | 非目标诊断，已由 ignore 排除 |
| `clippy::missing_const_for_fn` | Clippy lint | 检查函数是否可以声明为 `const fn`，属于 API/可用性建议。 | 非目标诊断，已由 ignore 排除 |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| 所有相关 lint | `-W clippy::all`, `-W clippy::pedantic`, `-W clippy::nursery` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |

## 实际证据

- 没有目标 lint / 编译错误诊断；这本身是本 case 要验证的实际结果。

非目标诊断（由 `case.toml` 的 `ignore` 排除）：

- `warning[clippy::must_use_candidate]` `src/lib.rs:1`：this function could have a `#[must_use]` attribute
- `warning[clippy::missing_const_for_fn]` `src/lib.rs:1`：this could be a `const fn`

## 结论

逻辑运算优先级混用在全量 lint 下零告警，需人工审视。
