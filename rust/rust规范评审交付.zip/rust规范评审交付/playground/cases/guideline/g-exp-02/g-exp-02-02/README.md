# G.EXP.02-02 — `-1i32.abs()` 不被 precedence 命中，需 rustc ambiguous_negative_literals

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.EXP.02`
- 场景类别：漏报
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::precedence -W ambiguous_negative_literals
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::precedence` | 单项 lint |
| WARN | `-W` | `ambiguous_negative_literals` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::precedence` | Clippy lint | 检查不同优先级运算符混用但缺少括号、容易被误读的表达式。 | 显式启用的检查范围；目标诊断（期望 0，实际 0） |
| `ambiguous_negative_literals` | rustc lint | rustc lint：检查负数字面量后直接调用方法等容易产生解析歧义的写法，建议加括号。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::precedence` | `-W clippy::precedence` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |
| `ambiguous_negative_literals` | `-W ambiguous_negative_literals` | 1 | 1 | `src/lib.rs:2` |

## 实际证据

- `warning[ambiguous_negative_literals]` `src/lib.rs:2`：`-` has lower precedence than method calls, which might be unexpected

## 结论

Clippy 已把一元负号的检查移交 rustc（1.89 的 precedence.rs 只检查算术/位移/位运算的混用），原文第二个反例需要 rustc 的 ambiguous_negative_literals（allow-by-default，需显式开启）。
