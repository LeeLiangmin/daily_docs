# G.CTF.02-02 — 单一模式 + Guard：Guard 只执行 1 次（对照组）

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.CTF.02`
- 场景类别：语义验证
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/main.rs`](src/main.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- 
```

没有显式传递 `-W/-D/-A/-F`；rustc 和 Clippy 的默认 lint 等级仍然生效。

## 本 case 涉及的 lint 及作用

本 case 不依赖具体 lint；通过编译结果或运行时行为验证规范描述。

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| 编译/运行语义 | 不需要特定 Clippy lint | 编译成功 | 编译成功 | 见目标源码与运行输出 |

## 实际证据

- 没有目标 lint / 编译错误诊断；这本身是本 case 要验证的实际结果。

实际运行输出：

```text
add 1
final=1
```

## 结论

同样的值与 Guard，去掉 `|` 后 Guard 只执行 1 次。可见多次执行来自或模式；原文「匹配几次就会执行 Guard 几次」未点明这一前提，需修订。
