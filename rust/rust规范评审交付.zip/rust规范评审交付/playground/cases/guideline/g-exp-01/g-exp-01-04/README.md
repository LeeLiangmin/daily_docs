# G.EXP.01-04 — 以 const 作为特性开关掩码时 bad_bit_mask 报警

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.EXP.01`
- 场景类别：误报风险
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::bad_bit_mask
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::bad_bit_mask` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::bad_bit_mask` | Clippy lint | 检查掩码和比较值不相容、导致条件恒真或恒假的位运算比较。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::bad_bit_mask` | `-W clippy::bad_bit_mask` | 1 | 1 | `src/lib.rs:4` |

## 实际证据

- `warning[clippy::bad_bit_mask]` `src/lib.rs:4`：&-masking with zero

## 结论

掩码来自配置常量、在某些构建下为 0 时，表达式在该配置下确实恒假，lint 照样报警。属于「技术上正确但意图正常」的告警，需允许局部 #[allow] 并写明原因。
