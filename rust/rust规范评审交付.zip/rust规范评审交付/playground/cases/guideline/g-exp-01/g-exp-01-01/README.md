# G.EXP.01-01 — 原文三个反例：两个 bad_bit_mask + 一个 overly_complex_bool_expr

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.EXP.01`
- 场景类别：命中
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::bad_bit_mask -W clippy::overly_complex_bool_expr
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::bad_bit_mask` | 单项 lint |
| WARN | `-W` | `clippy::overly_complex_bool_expr` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::bad_bit_mask` | Clippy lint | 检查掩码和比较值不相容、导致条件恒真或恒假的位运算比较。 | 显式启用的检查范围；目标诊断（期望 2，实际 2） |
| `clippy::overly_complex_bool_expr` | Clippy lint | 检查可以化简或包含恒真、恒假部分的复杂布尔表达式。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::bad_bit_mask` | `-W clippy::bad_bit_mask` | 2 | 2 | `src/lib.rs:4`、`src/lib.rs:5` |
| `clippy::overly_complex_bool_expr` | `-W clippy::overly_complex_bool_expr` | 1 | 1 | `src/lib.rs:6` |

## 实际证据

- `warning[clippy::bad_bit_mask]` `src/lib.rs:4`：incompatible bit mask: `_ & 1` can never be equal to `2`
- `warning[clippy::bad_bit_mask]` `src/lib.rs:5`：incompatible bit mask: `_ & 3` will always be lower than `4`
- `warning[clippy::overly_complex_bool_expr]` `src/lib.rs:6`：this boolean expression contains a logic bug

## 结论

原文只列 bad_bit_mask，只能覆盖前两个反例；第三个反例 `(x < y) && false` 需要 clippy::overly_complex_bool_expr。

版本说明：overly_complex_bool_expr 在 1.89 属 correctness（默认 deny），1.97 已降为 pedantic；POC 显式 -W 开启以消除差异。
