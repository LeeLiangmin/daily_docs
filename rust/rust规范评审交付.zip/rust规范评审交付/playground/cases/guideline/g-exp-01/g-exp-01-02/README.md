# G.EXP.01-02 — 原文未列、但同属「恒真/恒假」的其他 lint

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.EXP.01`
- 场景类别：命中
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::impossible_comparisons -W clippy::absurd_extreme_comparisons -W clippy::eq_op
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::impossible_comparisons` | 单项 lint |
| WARN | `-W` | `clippy::absurd_extreme_comparisons` | 单项 lint |
| WARN | `-W` | `clippy::eq_op` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::impossible_comparisons` | Clippy lint | 检查多个比较条件组合后不可能同时成立的范围判断。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |
| `clippy::absurd_extreme_comparisons` | Clippy lint | 检查与类型最小值或最大值进行的不可能比较，例如无符号数小于 0。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |
| `clippy::eq_op` | Clippy lint | 检查比较、运算两侧是同一表达式的情况，例如 `x == x`。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::impossible_comparisons` | `-W clippy::impossible_comparisons` | 1 | 1 | `src/lib.rs:4` |
| `clippy::absurd_extreme_comparisons` | `-W clippy::absurd_extreme_comparisons` | 1 | 1 | `src/lib.rs:5` |
| `clippy::eq_op` | `-W clippy::eq_op` | 1 | 1 | `src/lib.rs:6` |

## 实际证据

- `warning[clippy::impossible_comparisons]` `src/lib.rs:4`：boolean expression will never evaluate to 'true'
- `warning[clippy::absurd_extreme_comparisons]` `src/lib.rs:5`：this comparison involving the minimum or maximum element for this type contains a case that is always true or always false
- `warning[clippy::eq_op]` `src/lib.rs:6`：equal expressions as operands to `==`

## 结论

区间矛盾、类型极值比较、自比较同样恒真/恒假，分别由 impossible_comparisons / absurd_extreme_comparisons / eq_op（均为 correctness）覆盖，建议补入。
