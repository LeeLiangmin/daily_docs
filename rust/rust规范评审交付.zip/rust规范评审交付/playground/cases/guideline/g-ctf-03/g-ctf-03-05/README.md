# G.CTF.03-05 — while 条件变量在循环体内不变

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.CTF.03`
- 场景类别：命中
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::while_immutable_condition
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::while_immutable_condition` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::while_immutable_condition` | Clippy lint | 检查 while 条件依赖的变量在循环体中不发生变化，循环可能一次不进或永久不退出。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::while_immutable_condition` | `-W clippy::while_immutable_condition` | 1 | 1 | `src/lib.rs:2` |

## 实际证据

- `warning[clippy::while_immutable_condition]` `src/lib.rs:2`：variables in the condition are not mutated in the loop body

## 结论

while 形式的死循环由 clippy::while_immutable_condition（correctness，默认 deny）覆盖，原文未列。
