# G.CTF.03-04 — 未 await 的 async 块中的常驻循环

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.CTF.03`
- 场景类别：版本差异
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::infinite_loop
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::infinite_loop` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::infinite_loop` | Clippy lint | 检查没有可见 `break`、`return` 等退出路径的 `loop`；有意不返回的 `-> !` 函数会被豁免。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::infinite_loop` | `-W clippy::infinite_loop` | 1 | 1 | `src/lib.rs:3` |

## 实际证据

- `warning[clippy::infinite_loop]` `src/lib.rs:3`：infinite loop detected

## 结论

Rust/Clippy 1.89.0 会报警；这是未执行 async 块上的误报，1.97 起已豁免。

版本说明：1.89.0 的 get_parent_fn_ret_ty 会跳过 async 块向上找到外层 fn，外层 fn 不是 `-> !` 即报警；1.97 新增 is_inside_unawaited_async_block 豁免。即 1.89 下 spawn(async { loop {..} }) 类常驻任务为误报（源码比对）。
