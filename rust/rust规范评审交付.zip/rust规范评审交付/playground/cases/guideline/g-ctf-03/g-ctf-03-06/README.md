# G.CTF.03-06 — 无出口递归被 rustc unconditional_recursion 命中

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.CTF.03`
- 场景类别：命中
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- 
```

没有显式传递 `-W/-D/-A/-F`；rustc 和 Clippy 的默认 lint 等级仍然生效。

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `unconditional_recursion` | rustc lint | rustc lint：检查函数所有可达执行路径都会递归调用自身、无法正常返回。 | 目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `unconditional_recursion` | 未显式传递；使用工具链默认等级或验证零命中 | 1 | 1 | `src/lib.rs:1` |

## 实际证据

- `warning[unconditional_recursion]` `src/lib.rs:1`：function cannot return without recursing

## 结论

条款标题包含「递归」，rustc 默认 warn 的 unconditional_recursion 可覆盖「完全没有出口」的递归，原文未列。
