# G.FUD.01-03 — 关闭 avoid-breaking-exported-api 后 pub 函数可报

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.FUD.01`
- 场景类别：命中
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::large_types_passed_by_value
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::large_types_passed_by_value` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::large_types_passed_by_value` | Clippy lint | 检查大型 Copy 类型按值传参造成的复制开销，建议按引用传递。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 配置文件：`cases\guideline\g-fud-01\g-fud-01-03\clippy.toml`（目录向上查找）
- `avoid-breaking-exported-api = false`

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::large_types_passed_by_value` | `-W clippy::large_types_passed_by_value` | 1 | 1 | `src/lib.rs:1` |

## 实际证据

- `warning[clippy::large_types_passed_by_value]` `src/lib.rs:1`：this argument (4000 byte) is passed by value, but might be more efficient if passed by reference (limit: 256 byte)

## 结论

在 clippy.toml 中设置 avoid-breaking-exported-api = false 后，导出 API 也会被检查。
