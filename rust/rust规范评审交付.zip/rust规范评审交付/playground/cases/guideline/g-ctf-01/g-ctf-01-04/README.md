# G.CTF.01-04 — 原文反例 `let list: &[f32] = vec![1.23];` 无法编译

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.CTF.01`
- 场景类别：示例校验
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- 
```

没有显式传递 `-W/-D/-A/-F`；rustc 和 Clippy 的默认 lint 等级仍然生效。

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `E0308` | rustc 诊断/错误码 | rustc 编译错误：表达式的实际类型与上下文期望类型不匹配。 | 预期或实际编译诊断 |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| rustc 编译错误 `E0308` | 不需要 Clippy lint | 编译失败 | 编译失败 | `src/lib.rs:8` |

## 实际证据

- `error[E0308]` `src/lib.rs:8`：mismatched types

## 结论

原文反例类型不匹配（Vec<f32> 不能直接赋给 &[f32]），需改为 `&[1.23]` 或 `&vec![1.23]`。
