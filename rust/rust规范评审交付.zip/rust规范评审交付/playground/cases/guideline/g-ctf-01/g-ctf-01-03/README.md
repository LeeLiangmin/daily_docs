# G.CTF.01-03 — 对结构体字段先判断后 unwrap

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.CTF.01`
- 场景类别：版本差异
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::unnecessary_unwrap
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::unnecessary_unwrap` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::unnecessary_unwrap` | Clippy lint | 检查已经用 is_some/is_ok 或相反条件确认变体后又调用 unwrap/unwrap_err 的写法，建议直接模式匹配。 | 显式启用的检查范围；目标诊断（期望 0，实际 0） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::unnecessary_unwrap` | `-W clippy::unnecessary_unwrap` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |

## 实际证据

- 没有目标 lint / 编译错误诊断；这本身是本 case 要验证的实际结果。

## 结论

Rust/Clippy 1.89.0 不命中字段接收者，属于漏报；1.97 起才能命中。

版本说明：1.89.0 的 unwrap.rs 仅通过 path_to_local 识别局部变量，字段接收者（self.v）不在检测范围，即 1.89 下为漏报；1.97 新增 FieldIdx 追踪后可命中（源码比对）。
