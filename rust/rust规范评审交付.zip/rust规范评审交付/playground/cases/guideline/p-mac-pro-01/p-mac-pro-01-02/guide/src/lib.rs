use proc_macro::{Group, Span, TokenStream, TokenTree};

fn with_span(stream: TokenStream, span: Span) -> TokenStream {
    stream
        .into_iter()
        .map(|token| match token {
            TokenTree::Group(group) => {
                let mut replacement = Group::new(group.delimiter(), with_span(group.stream(), span));
                replacement.set_span(span);
                TokenTree::Group(replacement)
            }
            mut other => {
                other.set_span(span);
                other
            }
        })
        .collect()
}

#[proc_macro]
pub fn my_macro(_input: TokenStream) -> TokenStream {
    let generated = "let local = \"hello\"; let _ = local;"
        .parse()
        .expect("generated tokens must parse");
    with_span(generated, Span::mixed_site())
}
