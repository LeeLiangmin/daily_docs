use proc_macro::TokenStream;

#[proc_macro]
pub fn my_macro(_input: TokenStream) -> TokenStream {
    "x = 999; let local = \"hello\";"
        .parse()
        .expect("generated tokens must parse")
}
