# G.MOD.01-04 — 枚举变体通配导入归 enum_glob_use

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.MOD.01`
- 场景类别：命中
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::wildcard_imports -W clippy::enum_glob_use
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::wildcard_imports` | 单项 lint |
| WARN | `-W` | `clippy::enum_glob_use` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::wildcard_imports` | Clippy lint | 检查 `use module::*` 通配导入，避免命名来源不清或未来新增名称污染作用域。 | 显式启用的检查范围；目标诊断（期望 0，实际 0） |
| `clippy::enum_glob_use` | Clippy lint | 检查 `use Enum::*` 形式的枚举变体通配导入。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::wildcard_imports` | `-W clippy::wildcard_imports` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |
| `clippy::enum_glob_use` | `-W clippy::enum_glob_use` | 1 | 1 | `src/lib.rs:2` |

## 实际证据

- `warning[clippy::enum_glob_use]` `src/lib.rs:2`：usage of wildcard import for enum variants

## 结论

`use Enum::*` 由 enum_glob_use 负责，只开 wildcard_imports 会漏掉。
