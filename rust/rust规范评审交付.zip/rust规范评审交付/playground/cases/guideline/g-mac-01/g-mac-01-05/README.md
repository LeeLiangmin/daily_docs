# G.MAC.01-05 — 原文【例外】示例在 edition 2024 下告警

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.MAC.01`
- 场景类别：示例校验
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- 
```

没有显式传递 `-W/-D/-A/-F`；rustc 和 Clippy 的默认 lint 等级仍然生效。

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `E0133` | rustc 诊断/错误码 | rustc 诊断：在缺少所需 unsafe 块或 unsafe 上下文时执行不安全操作。 | 目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `E0133` | 未显式传递；使用工具链默认等级或验证零命中 | 1 | 1 | `src/lib.rs:4` |

## 实际证据

- `warning[E0133]` `src/lib.rs:4`：dereference of raw pointer is unsafe and requires unsafe block

## 结论

例外示例存在三个问题：名为 safe_function 却声明为 unsafe fn；仅判空不足以保证指针有效（悬垂、未对齐同样是 UB）；且 2024 版次下 unsafe fn 体内的不安全操作必须放进 unsafe 块。修订稿改写了该示例。
