# G.MAC.01-02 — 开启 warn-unsafe-macro-metavars-in-private-macros 后命中

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.MAC.01`
- 场景类别：命中
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::macro_metavars_in_unsafe
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::macro_metavars_in_unsafe` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::macro_metavars_in_unsafe` | Clippy lint | 检查宏元变量在宏生成的 unsafe 块中展开，避免调用者提供的表达式被隐式置于 unsafe 上下文。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 配置文件：`cases\guideline\g-mac-01\g-mac-01-02\clippy.toml`（目录向上查找）
- `warn-unsafe-macro-metavars-in-private-macros = true`

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::macro_metavars_in_unsafe` | `-W clippy::macro_metavars_in_unsafe` | 1 | 1 | `src/lib.rs:4` |

## 实际证据

- `warning[clippy::macro_metavars_in_unsafe]` `src/lib.rs:4`：this macro expands metavariables in an unsafe block

## 结论

在 clippy.toml 打开私有宏检查后命中。
