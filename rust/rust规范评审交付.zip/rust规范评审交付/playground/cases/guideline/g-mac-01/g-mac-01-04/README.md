# G.MAC.01-04 — 过程宏把调用方表达式放进 unsafe 块：调用方无需 unsafe 即可执行不安全操作

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.MAC.01`
- 场景类别：漏报
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/main.rs`](src/main.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::macro_metavars_in_unsafe
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::macro_metavars_in_unsafe` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::macro_metavars_in_unsafe` | Clippy lint | 检查宏元变量在宏生成的 unsafe 块中展开，避免调用者提供的表达式被隐式置于 unsafe 上下文。 | 显式启用的检查范围；目标诊断（期望 0，实际 0） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::macro_metavars_in_unsafe` | `-W clippy::macro_metavars_in_unsafe` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |

## 实际证据

- 没有目标 lint / 编译错误诊断；这本身是本 case 要验证的实际结果。

实际运行输出：

```text
got=7
```

## 结论

与原文过程宏反例同构。编译、运行均通过且无任何告警：Clippy 对过程宏生成的 unsafe 无检测能力。
