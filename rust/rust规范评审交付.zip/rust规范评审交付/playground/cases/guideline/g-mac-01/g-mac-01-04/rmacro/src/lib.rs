use proc_macro::TokenStream;

#[proc_macro]
pub fn run_unchecked(input: TokenStream) -> TokenStream {
    format!("{{ unsafe {{ {input} }} }}")
        .parse()
        .expect("generated tokens must parse")
}
