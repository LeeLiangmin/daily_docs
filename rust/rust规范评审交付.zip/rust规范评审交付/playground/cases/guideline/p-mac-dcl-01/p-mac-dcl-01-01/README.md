# P.MAC.DCL.01-01 — 宏内硬编码生命周期 'a：对 Bar<'b> 编译失败

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`P.MAC.DCL.01`
- 场景类别：示例校验
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- 
```

没有显式传递 `-W/-D/-A/-F`；rustc 和 Clippy 的默认 lint 等级仍然生效。

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `E0261` | rustc 诊断/错误码 | rustc 编译错误：使用了未声明的生命周期名称。 | 预期或实际编译诊断 |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| rustc 编译错误 `E0261` | 不需要 Clippy lint | 编译失败 | 编译失败 | `src/lib.rs:15` |

## 实际证据

- `error[E0261]` `src/lib.rs:15`：use of undeclared lifetime name `'b`

## 结论

原文描述属实：Foo<'a> 能编译，Bar<'b> 报 E0261 undeclared lifetime。
