# P.MAC.DCL.01-04 — 导出宏中写 crate:: 被 crate_in_macro_def 命中；裸路径不报

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`P.MAC.DCL.01`
- 场景类别：命中
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::crate_in_macro_def
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::crate_in_macro_def` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::crate_in_macro_def` | Clippy lint | 检查导出宏定义中使用 `crate::`；通常应使用 `$crate::` 指向宏定义所在 crate。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::crate_in_macro_def` | `-W clippy::crate_in_macro_def` | 1 | 1 | `src/lib.rs:5` |

## 实际证据

- `warning[clippy::crate_in_macro_def]` `src/lib.rs:5`：`crate` references the macro call's crate

## 结论

clippy::crate_in_macro_def（suspicious，默认 warn）能检出导出宏里误用 `crate::`（应为 $crate::），可部分覆盖本原则；裸路径 helper() 不报。
