# G.ERR.01-02 — expect() 不在 unwrap_used 范围内

> 本文件由 `scripts/render-guideline-poc-list.py` 根据 `case.toml` 和最近一次实测结果生成，请勿手工维护。

- 规范条目：`G.ERR.01`
- 场景类别：漏报
- 实测状态：**PASS**
- 实跑工具链：`rustc 1.89.0 (29483883e 2025-08-04)`；`clippy 0.1.89 (29483883ee 2025-08-04)`
- 目标源码：[`src/lib.rs`](src/lib.rs)

## 实际检查配置

在本 case 目录中可复现：

```powershell
cargo clippy --offline --all-targets --message-format=json -- -W clippy::unwrap_used -W clippy::expect_used
```

实际显式传递的 lint 规则：

| 等级 | 参数 | 规则 | 类型 |
| --- | --- | --- | --- |
| WARN | `-W` | `clippy::unwrap_used` | 单项 lint |
| WARN | `-W` | `clippy::expect_used` | 单项 lint |

## 本 case 涉及的 lint 及作用

| 规则 | 类型 | 作用 | 在本 case 中的角色 |
| --- | --- | --- | --- |
| `clippy::unwrap_used` | Clippy lint | 检查对 Option/Result 调用 `unwrap()`，因为 None/Err 时会触发 panic。 | 显式启用的检查范围；目标诊断（期望 0，实际 0） |
| `clippy::expect_used` | Clippy lint | 检查对 Option/Result 调用 `expect()`，因为失败时会触发 panic。 | 显式启用的检查范围；目标诊断（期望 1，实际 1） |

Clippy 行为配置：

- 未发现 `clippy.toml` / `.clippy.toml`，使用 Clippy 默认行为参数。

## 对应位置需要什么 lint

| 检查目标 | 启用方式 | 期望 | 实际 | 对应位置 |
| --- | --- | ---: | ---: | --- |
| `clippy::unwrap_used` | `-W clippy::unwrap_used` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |
| `clippy::expect_used` | `-W clippy::expect_used` | 1 | 1 | `src/lib.rs:2` |

## 实际证据

- `warning[clippy::expect_used]` `src/lib.rs:2`：used `expect()` on a `Result` value

## 结论

原文只列 unwrap_used，expect 同样会 panic，需要同时开启 expect_used。
