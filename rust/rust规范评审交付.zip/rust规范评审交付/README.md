# Rust 编码规范评审交付

评审范围为 15 条规范条款，从四个维度评审：必要性、准确性、定级和 lint 能力。lint 基线为 rustc / Clippy **1.89.0**。评审最终保留 26 个 lint，其中 G.CTF.02、G.MAC.DCL.01、P.MAC.PRO.01 三条没有对应 lint。

## 阅读顺序

1. **Rust规范评审对照.html**：原文与修订稿逐条对照，并附评审结论、修订理由和 POC 结果。单文件，浏览器直接打开即可离线查看。
2. **评审报告.md**：总体结论、逐条评审意见、横向问题和建议的项目配置。
3. **规范-修订稿.md**：修订后的规范正文，可直接替换原文。每条都新增了【检测】字段，写明对应的 lint 和不覆盖的范围。
4. **规范评审处理记录.md**：逐条列出修改项（diff、理由、依据）、定级、lint 调整和 POC 位置，是修订的决策记录。
5. **规范lint对照表.md**：26 个 lint 的所属条款、来源、分组、默认级别、引入版本、检查行为和配置要点。
6. **POC清单.md**：A 部分是门禁 PoC，B 部分是学习用例，两者都可在下面的两个仓库中复现。

另外，**规范-整理版.md** 是原文只修 markdown 格式、不改内容的版本，可用来与修订稿逐字比对。

## 两个仓库

| 目录 | 定位 | 运行 |
| --- | --- | --- |
| `bot-gate-lab/` | 门禁 PoC：每个 lint 一个 case（`cases/<rustc\|clippy>/<lint>/`），漏报和豁免以 `pass/<场景>/` 表达，断言目标 lint 0 次命中。改动是分支 `feat/cases-review-15-rules` 上的一个提交，可直接推送或 cherry-pick。 | `./scripts/validate-guideline.sh` |
| `playground/` | 学习库：按条款组织的 63 个用例（`cases/guideline/<条款>/<场景>/`），覆盖命中、漏报、误报、运行时语义、示例校验和版本差异，并回显编译器原始输出。`config/` 下是建议的 `[lints]` 与 `clippy.toml` 配置。 | `python scripts/validate-guideline.py [过滤串]` |

## 验证状态

| 仓库 | rustc 1.97.0 | rustc 1.89.0 |
| --- | --- | --- |
| bot-gate-lab | 43 项检查全部通过；`validate-fast.sh`、`cargo test`、`cargo fmt --check` 通过 | **待复跑** |
| playground | 63/63 PASS | 63/63 PASS（`artifacts/guideline/` 中的结果即 1.89 实测数据） |

1.89 与 1.97 有三处行为差异，已在用例中用 `since` 区分，并写入【检测】说明：

- `unnecessary_unwrap` 在 1.97 起才识别结构体字段。
- `infinite_loop` 在 1.89 中会误报未 await 的 async 块。
- `overly_complex_bool_expr` 在 1.97 起降为 pedantic。

## 落地建议

- 项目配置可直接参考 `playground/config/Cargo.toml.lints.example`（恰好覆盖 26 个保留 lint）和 `playground/config/clippy.toml`。
- 处理记录和 POC 清单中标为「漏报」或「需人工评审」的场景，lint 无法覆盖，需要在代码评审清单中保留。
