# Rust 编程规范

本仓库的核心文件是 [coding-guidelines.md](coding-guidelines.md)，面向使用 Rust 语言（Rust 1.68.0+）开发自研代码的团队，用于统一编码风格、提升代码的可读性与可维护性，并规范 Unsafe Rust、FFI、并发、内存与指针等高风险场景的写法。

## 文档内容概览

| 章节 | 内容 | 条款数 |
| --- | --- | --- |
| 1 概述 | 背景、目标与适用范围、总体原则、条款组织方式 | — |
| 2 代码风格 | 命名，格式与注释 | 7 |
| 3 编程实践 | 常量、数据类型、表达式与流程控制、函数与闭包、泛型与 trait、错误处理、模块、宏、其他 | 30 |
| 4 安全实践 | Unsafe 函数和 trait、FFI、并发并行、内存与指针 | 19 |
| 5 附录 | Rustfmt 配置与模板、Clippy 配置与模板、参考资料 | — |

全文共 56 条条款：12 条原则（`P`）+ 44 条规则（`G`）；其中规则类条款有 19 条为「要求」、25 条为「建议」。

## 条款编号与级别

每个条款一般包含标题、级别、描述等组成部分：

- 标题前的编号标明类别、领域元素与序号，即 `P.Element.Number`（原则）或 `G.Element.Number`（规则）。`P` 为 Principle，工具不检测；`G` 为 Guideline，工具会检测。
- 元素下再分子类时编号扩展为 `P.Element.SubElement.Number`，例如 `G.TYP.BOL.01`。
- `Element` 为领域关键元素的三字母缩略语（如 `NAM` 命名、`FMT` 格式、`TYP` 数据类型、`MAC` 宏、`SAF` 内存安全、`UNS` 非安全），完整对照表见「1.4 条款组织方式」。
- `Number` 为从 1 开始递增的两位数字序号，不足两位时高位补 0。

规则类条款分为两个级别：

- **要求**：产品原则上应该遵从，但可以按照具体产品版本计划和节奏分期实现。
- **建议**：属于优秀的编程实践，产品可结合业务情况考虑是否纳入，但要保证实施一致的代码风格。

条款正文由【描述】【说明】【反例】【正例】【例外】【相关讨论】等小节组成，多数条款给出可直接对照的 Rust 代码示例与相应的规范依据。

## 如何配套使用

- **格式**：按[附录 A Rustfmt 配置与模板](coding-guidelines.md#附录a-rustfmt-配置与模板)配置 `rustfmt.toml`（行宽 120、`use_small_heuristics = "MAX"` 等），通过 `cargo fmt` 统一格式。
- **检查**：按[附录 B Clippy 配置与模板](coding-guidelines.md#附录b-clippy-配置与模板)配置 `clippy.toml`，并通过 `Cargo.toml`（Rust 1.74.0+ 的 `[lints]` 表）、`.cargo/config.toml` 的 `rustflags` 或源码内的 lint 属性，开启与本规范对应的 rustc / clippy lint（如 `clippy::default_numeric_fallback`、`clippy::undocumented_unsafe_blocks`、`clippy::unwrap_used` 等）。
- 附录 B 还给出了 `clippy.toml` 的可配置项示例，以及模块内、代码上方、编译选项与 `Cargo.toml` 四种 lint 级别配置方法。

## 参考

文末「参考资料」列出的外部规范包括 Rust 官方 API 编写指南、Rust Style Guide、Unsafe Code Guidelines Reference，以及 ANSSI、Diem、Teaclave、PingCAP、Fuchsia、rust-analyzer 等公开编码规范。
