param([Parameter(Mandatory=$true)][string]$File)
$ErrorActionPreference = 'Stop'
$lines = Get-Content $File -Encoding UTF8
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -like '*<div class="diffwrap">*G.FUD.02 宜合理使用 Result 类型*') {
        $n = ([regex]::Matches($lines[$i], '<tr class="add">')).Count
        $lines[$i] = $lines[$i].Replace('<span class="hint">220 行有变动</span>', ('<span class="hint">' + $n + ' 行有变动</span>'))
        Write-Host "diff line ${i}: add rows = $n"
    }
    if ($lines[$i] -like '*G.FUD.02</span><span class="nmeta">*') {
        $lines[$i] = $lines[$i] -replace '(G\.FUD\.02</span><span class="nmeta"><span class="dot part" title="部分支持"></span><span class=nchg>)\d+(</span>)', "`${1}$n`${2}"
        Write-Host "nav line ${i}: nchg = $n"
    }
}
[System.IO.File]::WriteAllText((Join-Path $PWD $File), ($lines -join "`n"), [System.Text.UTF8Encoding]::new($false))
