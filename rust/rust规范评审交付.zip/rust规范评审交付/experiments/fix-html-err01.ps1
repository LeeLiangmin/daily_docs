param([Parameter(Mandatory=$true)][string]$File)
$ErrorActionPreference = 'Stop'
$t = [System.IO.File]::ReadAllText((Join-Path $PWD $File))

$old1 = '<code>clippy::describe_used</code>'
$oldLints = '<code>clippy::expect_used</code><code>clippy::panic</code>'
$c = ([regex]::Matches($t, [regex]::Escape($oldLints))).Count
Write-Output ("lints code pair: " + $c)
if ($c -eq 1) { $t = $t.Replace($oldLints, '<code>clippy::expect_used</code>') }

$oldChg = '<div class="dl-add"><span class="sg">+</span>clippy::panic          # 可选</div>'
$c = ([regex]::Matches($t, [regex]::Escape($oldChg))).Count
Write-Output ("lintchg add: " + $c)
if ($c -eq 1) { $t = $t.Replace($oldChg, '') }

$oldLi = '<li><code>cases/clippy/panic</code> <span class="muted">clippy::panic</span></li>'
$c = ([regex]::Matches($t, [regex]::Escape($oldLi))).Count
Write-Output ("labl li: " + $c)
if ($c -eq 1) { $t = $t.Replace($oldLi, '') }

$t = [regex]::Replace($t, '(G\.ERR\.01</span><span class="nmeta"><span class="dot part" title="部分支持"></span><span class=nchg>)\d+(</span>)', { param($m) $m.Groups[1].Value + '26' + $m.Groups[2].Value })

[System.IO.File]::WriteAllText((Join-Path $PWD $File), $t, [System.Text.UTF8Encoding]::new($false))
Write-Output "done $File"
