import io
p = r"playground\cases\guideline\g-mac-01\g-mac-01-06\README.md"
t = io.open(p, encoding="utf-8").read()
t = t.replace(" -W clippy::macro_metavars_in_unsafe -W clippy::undocumented_unsafe_blocks", " -W clippy::macro_metavars_in_unsafe")
t = t.replace("| WARN | `-W` | `clippy::undocumented_unsafe_blocks` | 单项 lint |\n", "")
t = t.replace("| `clippy::undocumented_unsafe_blocks` | Clippy lint | 检查 unsafe 块或 unsafe impl 前是否缺少解释安全前提的 SAFETY 注释。 | 显式启用的检查范围；目标诊断（期望 0，实际 0） |\n", "")
t = t.replace("| `clippy::undocumented_unsafe_blocks` | `-W clippy::undocumented_unsafe_blocks` | 0 | 0 | 无命中；结合类别与结论判断为漏报、边界或合规 |\n", "")
io.open(p, "w", encoding="utf-8", newline="\n").write(t)
print("残:", t.count("undocumented_unsafe_blocks"))
