import io, os, re, glob

# 1) 对照表
rows = []
for line in io.open("规范lint对照表.md", encoding="utf-8"):
    if not line.startswith("| G.") and not line.startswith("| P."):
        continue
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    if len(cells) < 7:
        continue
    clause, lint = cells[0], cells[1]
    lint = lint.strip("`")
    group, level = cells[3], cells[4]
    if "—" in lint:
        rows.append((clause, None, group, level))
    else:
        rows.append((clause, lint, group, level))

table = {}
for clause, lint, group, level in rows:
    if lint:
        table.setdefault(clause, []).append((lint, group, level))

print("== 对照表中的 lint ==")
for c in table:
    for lint, g, lv in table[c]:
        print(f"  {c:14s} {lint:48s} {g:10s} {lv}")

# 2) 门禁 case
gate = []  # (dir, rule, lint_id, expect_codes)
for p in glob.glob("bot-gate-lab/cases/*/*/case.toml"):
    t = io.open(p, encoding="utf-8").read()
    idm = re.search(r'id\s*=\s*"([^"]+)"', t)
    rule = re.search(r'rule\s*=\s*"([^"]+)"', t)
    codes = re.findall(r'code\s*=\s*"([^"]+)"', t)
    gate.append((p.split(os.sep)[2] + "/" + p.split(os.sep)[3], rule.group(1) if rule else "", idm.group(1) if idm else "", codes))

print("\n== 门禁 case 断言 ==")
for d, rule, i, codes in gate:
    hit = [c for c in codes]
    print(f"  {d:44s} rule={rule:20s} codes={hit}")

# 3) playground 断言
play = []
for p in glob.glob("playground/cases/guideline/*/*/case.toml"):
    t = io.open(p, encoding="utf-8").read()
    rid = re.search(r'id\s*=\s*"([^"]+)"', t).group(1)
    catg = re.search(r'category\s*=\s*"([^"]+)"', t)
    codes = re.findall(r'code\s*=\s*"([^"]+)"', t)
    counts = re.findall(r'count\s*=\s*(\d+)', t)
    # 命中类且 count>0 视为有效正例
    hits = []
    for i, c in enumerate(codes):
        cnt = int(counts[i]) if i < len(counts) else 0
        if cnt > 0:
            hits.append(c)
    play.append((rid, catg.group(1) if catg else "", codes, counts, hits))

print("\n== playground 正向命中 ==")
for rid, catg, codes, counts, hits in play:
    print(f"  {rid:14s} {catg:8s} codes={codes} counts={counts}")

# 4) 对比
def norm(l):
    return l.replace("clippy::", "")

table_lints = {norm(lint): (c, g, lv) for c, lst in table.items() for lint, g, lv in lst}
gate_hits = {}
for d, rule, i, codes in gate:
    d0 = d.split("/")[-1]
    for c in codes:
        pass
# 门禁：正例为 id 本身（lint id），pass 场景 code 也常是同一 lint
gate_lints = {norm(i): d for d, rule, i, codes in gate}

play_hits = {}
for rid, catg, codes, counts, hits in play:
    for h in hits:
        play_hits.setdefault(norm(h), []).append(rid)

all_poc = set(gate_lints) | set(play_hits)

print("\n== 对照表有、POC 无任何命中 ==")
for lint, (c, g, lv) in sorted(table_lints.items()):
    if lint not in all_poc:
        print(f"  {c:14s} {lint:48s} {g:10s} {lv}")

print("\n== POC 有命中、对照表没有 ==")
for lint in sorted(all_poc - set(table_lints)):
    where = []
    if lint in gate_lints:
        where.append("gate:" + gate_lints[lint])
    if lint in play_hits:
        where.append("play:" + ",".join(play_hits[lint]))
    print(f"  {lint:48s} {' '.join(where)}")

print("\n== 对照表 lint 的 POC 分布（gate / play 命中） ==")
for lint, (c, g, lv) in sorted(table_lints.items()):
    gd = gate_lints.get(lint)
    pl = play_hits.get(lint, [])
    flag = "" if (gd or pl) else "  <<< 无"
    print(f"  {c:14s} {lint:44s} gate={'Y:' + gd if gd else '-':48s} play={','.join(pl) if pl else '-':30s}{flag}")
