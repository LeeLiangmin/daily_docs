import io, re, sys

def edit(path, pairs, regexes=()):
    with io.open(path, encoding="utf-8") as f:
        t = f.read()
    for old, new in pairs:
        if old not in t:
            print(f"  MISS  {path}: {old[:60]!r}")
        while old in t:
            t = t.replace(old, new)
    for pat, rep in regexes:
        t2 = re.sub(pat, rep, t)
        if t2 == t:
            print(f"  MISS(re) {path}: {pat[:60]!r}")
        t = t2
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(t)
    left = len(re.findall("undocumented_unsafe_blocks", t)) + len(re.findall("undocumented-unsafe-blocks", t))
    print(f"  done {path} 残={left}")

# 规范-修订稿
edit("规范-修订稿.md", [
    ("- 可选 `clippy::undocumented_unsafe_blocks`（restriction）：要求 unsafe 块带 `// SAFETY:` 注释，便于评审。\n", ""),
])
import shutil
shutil.copyfile("规范-修订稿.md", "playground/docs/规范/规范-修订稿.md")

# 评审报告
edit("评审报告.md", [
    ("<br>clippy::undocumented_unsafe_blocks", ""),
    ("建议：`clippy::macro_metavars_in_unsafe`、`clippy::undocumented_unsafe_blocks`。", "建议：`clippy::macro_metavars_in_unsafe`。"),
    ("+ clippy::undocumented_unsafe_blocks     # 可选\n", ""),
    ("- `undocumented_unsafe_blocks` 要求 `// SAFETY:` 注释，对应【例外】「写明理由」；它查所有 unsafe 块，范围比本条大，所以可选。\n", ""),
    ('undocumented_unsafe_blocks = "warn"   # G.MAC.01  restriction，可选\n', ""),
])

# 处理记录（+副本）
edit("规范评审处理记录.md", [
    ("+ clippy::undocumented_unsafe_blocks     # 可选\n", ""),
    ("- `undocumented_unsafe_blocks` 要求 `// SAFETY:` 注释，对应【例外】「写明理由」；它查所有 unsafe 块，范围比本条大，所以可选。\n", ""),
    ("2. `clippy::undocumented_unsafe_blocks`（restriction）：要求每个 unsafe 块带 `// SAFETY:` 注释，便于评审核对前置条件。\n", ""),
])
shutil.copyfile("规范评审处理记录.md", "playground/docs/规范/规范评审处理记录.md")

# lint 对照表
edit("规范lint对照表.md", [
    ("| G.MAC.01 | `clippy::undocumented_unsafe_blocks` | Clippy | restriction | allow | 1.58 | unsafe 块缺少 `// SAFETY:` 注释 | 需显式开启；可选，范围大于本条 |\n", ""),
    ("| allow（需显式开启） | 10 | Clippy：infinite_loop、precedence_bits、large_types_passed_by_value、needless_pass_by_value、unwrap_used、expect_used、wildcard_imports、enum_glob_use、undocumented_unsafe_blocks；rustc：ambiguous_negative_literals |",
     "| allow（需显式开启） | 9 | Clippy：infinite_loop、precedence_bits、large_types_passed_by_value、needless_pass_by_value、unwrap_used、expect_used、wildcard_imports、enum_glob_use；rustc：ambiguous_negative_literals |"),
])

# POC 清单三处
for p in ["POC清单.md", "playground/docs/guideline-poc-list.md", "playground/docs/guideline-poc-list-1.97-reference.md"]:
    edit(p, [("<br>`clippy::undocumented_unsafe_blocks` 0→0", "")])

# lint-catalog
edit("playground/docs/lint-catalog.md", [], [(r"\| `clippy::undocumented_unsafe_blocks` \|[^\n]*\n", "")])

# bot-gate-lab 文档
edit("bot-gate-lab/docs/guideline-lints.md", [], [(r"\| `clippy::undocumented_unsafe_blocks` \|[^\n]*\n", "")])
edit("bot-gate-lab/README.md", [("、undocumented_unsafe_blocks", "")])
