import io, re

for path in ["Rust规范评审对照.html", "规范对照.html"]:
    with io.open(path, encoding="utf-8") as f:
        t = f.read()
    # 顺序很重要：先删 <br> 形式的观测，再删裸 code
    steps = [
        ('<br><code>clippy::undocumented_unsafe_blocks</code> 0→0', ""),
        ('<code>clippy::undocumented_unsafe_blocks</code>', ""),
        ('<div class="dl-add"><span class="sg">+</span>clippy::undocumented_unsafe_blocks     # 可选</div>', ""),
        ('undocumented_unsafe_blocks = "warn"   # G.MAC.01  restriction，可选\n', ""),
    ]
    for old, new in steps:
        c = t.count(old)
        print(f"  [{c}] {old[:60]!r}")
        if c:
            t = t.replace(old, new)
    m = re.search(r'<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">\d+</td><td class="tx b">- 可选 `clippy::undocumented_unsafe_blocks`[^<]*</td></tr>', t)
    if m:
        t = t.replace(m.group(0), "")
        print("  [1] diff add row removed")
    else:
        print("  [0] diff add row NOT FOUND")
    t = re.sub(r'(G\.MAC\.01</span><span class="nmeta"><span class="dot part" title="部分支持"></span><span class=nchg>)\d+', r'\g<1>24', t)
    idx = t.find('G.MAC.01 不应通过宏将 unsafe 代码伪装为 safe 代码')
    before = t.rfind('行有变动', 0, idx)
    start = t.rfind('<span class="hint">', 0, before)
    end = t.find('</span>', start)
    print(f"  hint old: {t[start:end]!r}")
    t = t[:start] + '<span class="hint">24 行有变动' + t[end:]
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(t)
    print(f"  done {path} 残={t.count('undocumented_unsafe_blocks')}")
