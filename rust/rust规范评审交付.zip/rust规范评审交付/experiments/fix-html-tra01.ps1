param([Parameter(Mandatory=$true)][string]$File)
$ErrorActionPreference = 'Stop'
$t = [System.IO.File]::ReadAllText((Join-Path $PWD $File))

function Rep([string]$old, [string]$new) {
    $c = ([regex]::Matches($script:t, [regex]::Escape($old))).Count
    Write-Output ("  [$c] " + $old.Substring(0, [Math]::Min(70, $old.Length)))
    if ($c -eq 1) { $script:t = $script:t.Replace($old, $new) }
    elseif ($c -ne 0) { throw "multiple matches: $c" }
}

Rep '<code>clippy::impl_hash_borrow_with_str_and_bytes</code>' ''
Rep '；Borrow 部分有 impl_hash_borrow_with_str_and_bytes 覆盖一个特例。' '。'
Rep '<div class="dl-add"><span class="sg">+</span>clippy::impl_hash_borrow_with_str_and_bytes</div>' ''
Rep '<li><code>impl_hash_borrow_with_str_and_bytes</code> 覆盖原文 Borrow 约束中的一个特例。</li>' ''
Rep 'impl_hash_borrow_with_str_and_bytes = "deny"  # G.TRA.01' ''

# 删除 diff 中该 add 行（含行号 169 的整行）
$m = [regex]::Match($t, '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">\d+</td><td class="tx b">- `clippy::impl_hash_borrow_with_str_and_bytes`[^<]*</td></tr>')
if ($m.Success) { $t = $t.Replace($m.Value, ''); Write-Output '  [1] diff add row removed' } else { Write-Output '  [0] diff row NOT FOUND' }

# 右列行号顺序重排（仅 G.TRA.01 一节不必区分，全文按出现顺序重排会破坏其他节——改为逐 diff 表处理）
$t = [regex]::Replace($t, '<div class="diffwrap"><table class="diff">.*?</table></div>', {
    param($m2)
    $block = $m2.Value
    $script:k = 0
    $block = [regex]::Replace($block, '<td class="ln">(\d+)</td><td class="tx b">', {
        param($mm)
        $script:k = $script:k + 1
        '<td class="ln">' + $script:k + '</td><td class="tx b">'
    })
    $block
})

# 重算 G.TRA.01 的 hint 与导航 nchg
$diffLine = [regex]::Match($t, '<div class="diffwrap"><table class="diff">(?:(?!</table></div>).)*?G\.TRA\.01 在实现相等性.*?</table></div>')
if ($diffLine.Success) {
    $adds = ([regex]::Matches($diffLine.Value, '<tr class="add">')).Count
    Write-Output ("  G.TRA.01 diff add rows = " + $adds)
    $t = [regex]::Replace($t, '(<h3>原文对照 <span class="hint">)50( 行有变动</span></h3>\s*<div class="diffwrap"><table class="diff">(?:(?!</table>).)*?G\.TRA\.01)', ('${1}' + $adds + '${2}'))
    $t = [regex]::Replace($t, '(G\.TRA\.01</span><span class="nmeta"><span class="dot part" title="部分支持"></span><span class=nchg>)\d+(</span>)', ('${1}' + $adds + '${2}'))
}

[System.IO.File]::WriteAllText((Join-Path $PWD $File), $t, [System.Text.UTF8Encoding]::new($false))
Write-Output "done $File"
