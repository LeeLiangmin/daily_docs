$ErrorActionPreference = 'Stop'
Get-ChildItem 'playground\cases\guideline\g-fud-02' -Directory | ForEach-Object {
  $c = Get-Content "$($_.FullName)\case.toml" -Raw
  $src = Get-Content "$($_.FullName)\src\lib.rs" -ErrorAction SilentlyContinue
  if (-not $src) { $src = Get-Content "$($_.FullName)\src\main.rs" -ErrorAction SilentlyContinue }
  "===== $($_.Name) ====="
  ($c -split "`n" | Where-Object { $_ -match '^(id|category|title|conclusion|version_note|args|ignore|\[\[expect\]\]|code|count)' } | ForEach-Object ToString)
  "--- src ---"
  $src
  ""
}
'===== gate cases ====='
Get-ChildItem 'bot-gate-lab\cases' -Recurse -Filter case.toml | Where-Object { (Get-Content $_.FullName -Raw) -match 'G\.FUD\.02' } | ForEach-Object {
  $d = $_.Directory.FullName
  "===== " + $d.Replace((Join-Path $PWD 'bot-gate-lab\cases\'), '') + " ====="
  Get-Content $_.FullName
  Get-ChildItem $d -Recurse -Filter lib.rs | ForEach-Object { "--- " + $_.FullName.Replace("$d\", '') + " ---"; Get-Content $_.FullName }
  ""
}
