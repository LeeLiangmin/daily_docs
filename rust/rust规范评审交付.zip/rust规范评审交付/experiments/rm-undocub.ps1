$ErrorActionPreference = 'Stop'
# ---- 修订稿 ----
$p = '规范-修订稿.md'
$t = Get-Content $p -Raw
$t = $t.Replace("- 可选 ``clippy::undocumented_unsafe_blocks``（restriction）：要求 unsafe 块带 ``// SAFETY:`` 注释，便于评审。`r`n", '')
$t = $t.Replace("- 可选 ``clippy::undocumented_unsafe_blocks``（restriction）：要求 unsafe 块带 ``// SAFETY:`` 注释，便于评审。`n", '')
Set-Content $p $t -NoNewline -Encoding utf8
Copy-Item $p 'playground\docs\规范\规范-修订稿.md' -Force
Write-Output ("修订稿残留: " + ((Select-String -Path $p -Pattern 'undocumented_unsafe' | Measure-Object).Count))

# ---- 评审报告 ----
$p = '评审报告.md'
$t = Get-Content $p -Raw
$t = $t.Replace('<br>clippy::undocumented_unsafe_blocks', '')
$t = $t.Replace('建议：``clippy::macro_metavars_in_unsafe``、``clippy::undocumented_unsafe_blocks``。', '建议：``clippy::macro_metavars_in_unsafe``。')
$t = $t.Replace("+ clippy::undocumented_unsafe_blocks     # 可选`r`n", '')
$t = $t.Replace("+ clippy::undocumented_unsafe_blocks     # 可选`n", '')
$t = $t.Replace("- ``undocumented_unsafe_blocks`` 要求 ``// SAFETY:`` 注释，对应【例外】「写明理由」；它查所有 unsafe 块，范围比本条大，所以可选。`r`n", '')
$t = $t.Replace("- ``undocumented_unsafe_blocks`` 要求 ``// SAFETY:`` 注释，对应【例外】「写明理由」；它查所有 unsafe 块，范围比本条大，所以可选。`n", '')
$t = $t.Replace("undocumented_unsafe_blocks = `"warn`"   # G.MAC.01  restriction，可选`r`n", '')
$t = $t.Replace("undocumented_unsafe_blocks = `"warn`"   # G.MAC.01  restriction，可选`n", '')
Set-Content $p $t -NoNewline -Encoding utf8
Write-Output ("评审报告残留: " + ((Select-String -Path $p -Pattern 'undocumented_unsafe' | Measure-Object).Count))

# ---- 处理记录 ----
$p = '规范评审处理记录.md'
$t = Get-Content $p -Raw
$t = $t.Replace("+ clippy::undocumented_unsafe_blocks     # 可选`r`n", '')
$t = $t.Replace("+ clippy::undocumented_unsafe_blocks     # 可选`n", '')
$t = $t.Replace("- ``undocumented_unsafe_blocks`` 要求 ``// SAFETY:`` 注释，对应【例外】「写明理由」；它查所有 unsafe 块，范围比本条大，所以可选。`r`n", '')
$t = $t.Replace("- ``undocumented_unsafe_blocks`` 要求 ``// SAFETY:`` 注释，对应【例外】「写明理由」；它查所有 unsafe 块，范围比本条大，所以可选。`n", '')
$t = $t.Replace("2. ``clippy::undocumented_unsafe_blocks``（restriction）：要求每个 unsafe 块带 ``// SAFETY:`` 注释，便于评审核对前置条件。`r`n", '')
$t = $t.Replace("2. ``clippy::undocumented_unsafe_blocks``（restriction）：要求每个 unsafe 块带 ``// SAFETY:`` 注释，便于评审核对前置条件。`n", '')
Set-Content $p $t -NoNewline -Encoding utf8
Copy-Item $p 'playground\docs\规范\规范评审处理记录.md' -Force
Write-Output ("处理记录残留: " + ((Select-String -Path $p -Pattern 'undocumented_unsafe' | Measure-Object).Count))

# ---- lint 对照表 ----
$p = '规范lint对照表.md'
$t = Get-Content $p -Raw
$t = $t.Replace("| G.MAC.01 | ``clippy::undocumented_unsafe_blocks`` | Clippy | restriction | allow | 1.58 | unsafe 块缺少 ``// SAFETY:`` 注释 | 需显式开启；可选，范围大于本条 |`r`n", '')
$t = $t.Replace("| G.MAC.01 | ``clippy::undocumented_unsafe_blocks`` | Clippy | restriction | allow | 1.58 | unsafe 块缺少 ``// SAFETY:`` 注释 | 需显式开启；可选，范围大于本条 |`n", '')
$t = $t.Replace('| allow（需显式开启） | 10 | Clippy：infinite_loop、precedence_bits、large_types_passed_by_value、needless_pass_by_value、unwrap_used、expect_used、wildcard_imports、enum_glob_use、undocumented_unsafe_blocks；rustc：ambiguous_negative_literals |', '| allow（需显式开启） | 9 | Clippy：infinite_loop、precedence_bits、large_types_passed_by_value、needless_pass_by_value、unwrap_used、expect_used、wildcard_imports、enum_glob_use；rustc：ambiguous_negative_literals |')
Set-Content $p $t -NoNewline -Encoding utf8
Write-Output ("lint对照表残留: " + ((Select-String -Path $p -Pattern 'undocumented_unsafe' | Measure-Object).Count))

# ---- POC 清单（A/B 与 playground 两份清单） ----
foreach ($p in @('POC清单.md','playground\docs\guideline-poc-list.md','playground\docs\guideline-poc-list-1.97-reference.md')) {
  $t = Get-Content $p -Raw
  $t = $t.Replace('<br>``clippy::undocumented_unsafe_blocks`` 0→0', '')
  Set-Content $p $t -NoNewline -Encoding utf8
  Write-Output ("$p 残留: " + ((Select-String -Path $p -Pattern 'undocumented_unsafe' | Measure-Object).Count))
}

# ---- lint-catalog ----
$p = 'playground\docs\lint-catalog.md'
$t = Get-Content $p -Raw
$t = [regex]::Replace($t, '\| ``clippy::undocumented_unsafe_blocks`` \|[^\r\n]*\r?\n', '')
Set-Content $p $t -NoNewline -Encoding utf8
Write-Output ("lint-catalog 残留: " + ((Select-String -Path $p -Pattern 'undocumented_unsafe' | Measure-Object).Count))

# ---- bot-gate-lab 文档 ----
$p = 'bot-gate-lab\docs\guideline-lints.md'
$t = Get-Content $p -Raw
$t = [regex]::Replace($t, '\| ``clippy::undocumented_unsafe_blocks`` \|[^\r\n]*\r?\n', '')
Set-Content $p $t -NoNewline -Encoding utf8
$p = 'bot-gate-lab\README.md'
$t = Get-Content $p -Raw
$t = $t.Replace('、undocumented_unsafe_blocks', '')
Set-Content $p $t -NoNewline -Encoding utf8
Write-Output ("gate docs 残留: " + ((Select-String -Path 'bot-gate-lab\docs\guideline-lints.md','bot-gate-lab\README.md' -Pattern 'undocumented_unsafe' | Measure-Object).Count))
