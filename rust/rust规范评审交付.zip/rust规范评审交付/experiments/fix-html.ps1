param([Parameter(Mandatory=$true)][string]$File)
$ErrorActionPreference = 'Stop'
$text = [System.IO.File]::ReadAllText($File)
$changed = 0
function Rep([string]$old, [string]$new) {
    $c = ([regex]::Matches($script:text, [regex]::Escape($old))).Count
    Write-Host ("  [{0}] {1}" -f $c, $old.Substring(0, [Math]::Min(60, $old.Length)))
    if ($c -eq 1) { $script:text = $script:text.Replace($old, $new); $script:changed++ }
    elseif ($c -eq 0) { Write-Host "    !! NOT FOUND" }
    else { throw "multiple matches ($c)" }
}

Write-Host "== $File =="

# A. lint 建议行
Rep '<div class="lints"><span class="lk">建议</span><code>unused_must_use</code><code>clippy::let_underscore_must_use</code><code>clippy::unused_result_ok</code><code>clippy::must_use_candidate</code><code>clippy::return_self_not_must_use</code></div>' '<div class="lints"><span class="lk">建议</span><code>unused_must_use</code></div>'

# B. lint 说明段落
Rep '<p>原文写法 <code>rustc::unused_must_use</code> 不合法：rustc 内建 lint 没有工具前缀，应为 unused_must_use。该 lint 只检查调用方是否忽略，不检查定义方是否该加 must_use（需 must_use_candidate / return_self_not_must_use）。漏报：<code>let _ =</code>（需 let_underscore_must_use）、<code>.ok();</code>（需 unused_result_ok）、Option&lt;MustUse&gt;（无 lint）。</p>' '<p>原文写法 <code>rustc::unused_must_use</code> 不合法：rustc 内建 lint 没有工具前缀，应为 unused_must_use。该 lint 只检查调用方是否忽略。<code>let _ =</code>、<code>.ok();</code> 属显式放弃告警的有意写法，不计入漏报；真实缺口是 Option&lt;MustUse&gt;（无 lint）。</p>'

# C. 修订项 chlist（整行）
$lines = $text -split "`r?`n"
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -like '*<div class="chlist"><div class="chitem"><div class="chtitle"><span class="chn">1</span>新增【说明】：三种让告警失效的写法*') {
        $lines[$i] = '  <div class="chlist"><div class="chitem"><div class="chtitle"><span class="chn">1</span>新增【说明】：界定有意写法与真实缺口</div><div class="dblock"><div class="dl-add"><span class="sg">+</span>【说明】</div><div class="dl-add"><span class="sg">+</span>- `let _ = f();`、`f().ok();` 属显式放弃告警的有意写法，不计入本条的漏报场景；</div><div class="dl-add"><span class="sg">+</span>- 标注了 `#[must_use]` 的类型被包在 `Option` 等容器中返回时，类型上的标注不再生效。对关键返回值，宜在函数上同时标注 `#[must_use]`。</div></div><div class="why"><span class="whyk">理由</span><p><code>let _ =</code> 与 <code>.ok();</code> 是调用方有意为之的写法，不属于缺陷；Option 包装稀释 must_use 才是条款目标的真实落空点。</p></div><div class="basis">依据：POC <a class="pocref" href="#poc-G.FUD.02-04">G.FUD.02-04</a></div></div><div class="chitem"><div class="chtitle"><span class="chn">2</span>删除重复正例</div><div class="dblock"><div class="dl-del"><span class="sg">-</span>#[must_use] fn foo1() ...   // 第二份重复的正例</div><div class="dl-del"><span class="sg">-</span>#[must_use] struct MyError ...</div></div><div class="why"><span class="whyk">理由</span><p>格式问题，同一段正例出现了两次。</p></div></div></div>'
        Write-Host "  [1] chlist line $i"
        $changed++
    }
    elseif ($lines[$i] -like '*<div class="lintchg"><div class="dblock"><div class="dl-del"><span class="sg">-</span>rustc::unused_must_use</div>*') {
        $lines[$i] = '  <div class="lintchg"><div class="dblock"><div class="dl-del"><span class="sg">-</span>rustc::unused_must_use</div><div class="dl-add"><span class="sg">+</span>unused_must_use</div></div><ul><li>原写法不合法：rustc 内建 lint 没有前缀，<code>rustc::</code> 是编译器内部 lint 的命名空间。</li><li><code>let _ =</code>、<code>.ok();</code> 属显式放弃告警的有意写法，不视为漏报，无需 lint 补位。</li><li>真实缺口是 must_use 类型包在 Option 中返回（POC <a class="pocref" href="#poc-G.FUD.02-04">G.FUD.02-04</a>），无 lint 能覆盖，靠「函数上同时标注 <code>#[must_use]</code>」规避。</li></ul></div>'
        Write-Host "  [1] lintchg line $i"
        $changed++
    }
    elseif ($lines[$i] -like '*<ul class="labl"><li><code>cases/clippy/let-underscore-must-use</code>*') {
        $lines[$i] = '  <ul class="labl"><li><code>cases/rustc/unused-must-use</code> <span class="muted">unused_must_use</span><div class="labp"><code>pass/let-underscore</code> <span class="cat edge">边界</span> <code>let _ =</code> 显式丢弃，属有意写法，不报。</div><div class="labp"><code>pass/ok-discard</code> <span class="cat edge">边界</span> <code>.ok();</code> 显式丢弃，属有意写法，不报。</div><div class="labp"><code>pass/option-wrapped</code> <span class="cat fn">漏报</span> must_use 类型包在 Option 中返回，不报，没有 lint 能覆盖。</div></li></ul>'
        Write-Host "  [1] labl line $i"
        $changed++
    }
    elseif ($lines[$i] -like '*id="poc-G.FUD.02-01"*') {
        $row01 = '<tr><td class="pid" id="poc-G.FUD.02-01">G.FUD.02-01<span class="st pass">PASS</span></td><td><span class="cat hit">命中</span></td><td><div class="ptitle">忽略 must_use 函数 / must_use 类型 / Result 返回值</div><div class="obs"><code>unused_must_use</code> 3→3</div></td><td class="pnote">三种方式均触发 rustc unused_must_use（默认 warn）。原文写的 <code>rustc::unused_must_use</code> 不是合法写法，rustc 内建 lint 没有工具前缀，应写为 unused_must_use。</td></tr>'
        $row04 = '<tr><td class="pid" id="poc-G.FUD.02-04">G.FUD.02-04<span class="st pass">PASS</span></td><td><span class="cat fn">漏报</span></td><td><div class="ptitle">must_use 类型包在 Option 中返回</div><div class="obs"><code>unused_must_use</code> 0→0</div></td><td class="pnote">must_use 标注在类型上时，套一层 Option 即失效；对关键返回值宜在函数上也标注 #[must_use]。</td></tr>'
        $lines[$i] = '  <div class="pocwrap"><table class="poc"><colgroup><col class="c-pid"><col class="c-cat"><col><col></colgroup><thead><tr><th>ID</th><th>类别</th><th>场景与实测</th><th>结论</th></tr></thead><tbody>' + $row01 + $row04 + '</tbody></table></div><p style="color:var(--muted,#888)">注：原 G.FUD.02-02（<code>let _ =</code>）、G.FUD.02-03（<code>.ok();</code>）、G.FUD.02-05（must_use_candidate）已移除——显式丢弃属有意写法，不作为漏报场景。</p>'
        Write-Host "  [1] poc table line $i"
        $changed++
    }
}
$text = $lines -join "`n"

# D. 原文对照 diff 行：说明块重写
Rep '<td class="tx b">以下写法会使上述告警失效，需在评审中关注：</td>' '<td class="tx b">- `let _ = f();`、`f().ok();` 属显式放弃告警的有意写法，不计入本条的漏报场景；</td>'
Rep '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">18</td><td class="tx b">- `f().ok();` 把 Result 转为 Option 后丢弃；</td></tr>' ''
Rep '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">19</td><td class="tx b">- 标注了 `#[must_use]` 的类型被包在 `Option` 等容器中返回时，类型上的标注不再生效。对关键返回值，宜在函数上同时标注 `#[must_use]`。</td></tr>' ''
Rep '<td class="tx b">- `let _ = f();` 显式丢弃返回值；</td>' '<td class="tx b">- 标注了 `#[must_use]` 的类型被包在 `Option` 等容器中返回时，类型上的标注不再生效。对关键返回值，宜在函数上同时标注 `#[must_use]`。</td>'
Rep '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">20</td><td class="tx b">&#8203;</td></tr>' ''

# E. 反例块整块删除（L21-33）
$fank = '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">21</td><td class="tx b">**【反例】**</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">22</td><td class="tx b">&#8203;</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">23</td><td class="tx b">```rust</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">24</td><td class="tx b">#[must_use]</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">25</td><td class="tx b">fn foo1() -&gt; i32 {</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">26</td><td class="tx b">    0</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">27</td><td class="tx b">}</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">28</td><td class="tx b">&#8203;</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">29</td><td class="tx b">fn caller() {</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">30</td><td class="tx b">    // 不符合：静默丢弃了 must_use 返回值</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">31</td><td class="tx b">    let _ = foo1();</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">32</td><td class="tx b">}</td></tr>' +
    '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">33</td><td class="tx b">```</td></tr>'
Rep $fank ''

# F. 检测块收敛
Rep '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">58</td><td class="tx b">- `clippy::let_underscore_must_use`（restriction）：用 `let _ =` 丢弃 must_use 值。</td></tr>' ''
Rep '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">59</td><td class="tx b">- `clippy::unused_result_ok`（restriction）：`.ok();` 丢弃 Result。</td></tr>' ''
Rep '<tr class="add"><td class="ln"></td><td class="tx a">&#8203;</td><td class="ln">60</td><td class="tx b">- `clippy::must_use_candidate`、`clippy::return_self_not_must_use`（pedantic）：从定义方提示缺失的 `#[must_use]`。</td></tr>' ''

# G. 右列行号顺序重排
$text = [regex]::Replace($text, '<td class="ln">(\d+)</td><td class="tx b">', {
    param($m)
    $script:n = ($script:n + 1)
    '<td class="ln">' + $script:n + '</td><td class="tx b">'
})
$script:n = 0

# H. 「N 行有变动」提示与导航 nchg
$addCount = ([regex]::Matches($text, '<tr class="add">')).Count
Rep '<span class="hint">30 行有变动</span>' ('<span class="hint">' + $addCount + ' 行有变动</span>')
Rep 'G.FUD.02</span><span class="nmeta"><span class="dot part" title="部分支持"></span><span class=nchg>30</span>' ('G.FUD.02</span><span class="nmeta"><span class="dot part" title="部分支持"></span><span class=nchg>' + $addCount + '</span>')

# I. clippy.toml 示例配置行删除
foreach ($l in @('let_underscore_must_use = "warn"      # G.FUD.02  restriction', 'unused_result_ok = "warn"             # G.FUD.02  restriction', 'must_use_candidate = "warn"           # G.FUD.02  pedantic，存量代码告警较多，可后置', 'return_self_not_must_use = "warn"     # G.FUD.02  pedantic')) {
    $c = ([regex]::Matches($text, [regex]::Escape($l + "`n"))).Count
    if ($c -eq 1) { $text = $text.Replace($l + "`n", ''); $changed++ ; Write-Host "  [1] config: $l" }
    else { Write-Host "  [$c] config NOT REMOVED: $l" }
}

[System.IO.File]::WriteAllText($File, $text, [System.Text.UTF8Encoding]::new($false))
Write-Host "changed blocks: $changed"
