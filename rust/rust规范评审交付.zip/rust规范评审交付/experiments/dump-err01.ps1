$ErrorActionPreference = 'Stop'
foreach ($n in 'unwrap-used','expect-used','panic') {
  $d = Join-Path 'bot-gate-lab\cases\clippy' $n
  Write-Output "===== $n ====="
  Get-ChildItem $d -Recurse -File |
    Where-Object { ($_.Name -eq 'case.toml' -or $_.Name -eq 'lib.rs') -and $_.FullName -notmatch '\\target\\' } |
    ForEach-Object { Write-Output ('--- ' + $_.FullName.Substring($PWD.Path.Length + 1) + ' ---'); Get-Content $_.FullName }
  Write-Output ''
}
