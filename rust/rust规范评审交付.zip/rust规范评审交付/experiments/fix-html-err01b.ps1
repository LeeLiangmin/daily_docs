param([Parameter(Mandatory=$true)][string]$File)
$ErrorActionPreference = 'Stop'
$t = [System.IO.File]::ReadAllText((Join-Path $PWD $File))
function Rep([string]$old, [string]$new) {
    $c = ([regex]::Matches($script:t, [regex]::Escape($old))).Count
    Write-Output ("  [$c] " + $old.Substring(0, [Math]::Min(70, $old.Length)))
    if ($c -eq 1) { $script:t = $script:t.Replace($old, $new) }
    elseif ($c -ne 0) { throw "multiple: $c" }
}

Rep '；<code>unwrap_or_else(|e| panic!(..))</code> 两者都不报（需 clippy::panic）。' '；<code>unwrap_or_else(|e| panic!(..))</code> 两者都不报，无可用的兜底 lint，需人工评审。'
Rep '闭包中 panic 与 unwrap 等价，但不报，需 clippy::panic 兜底。' '闭包中 panic 与 unwrap 等价，兜底检查需人工评审。'
Rep '<br><code>clippy::panic</code> 1→1' ''
Rep '。需 clippy::panic 兜底，并在描述中加以限定。' '，本条相关 lint 均不报，需人工评审并在描述中加以限定。'
Rep '可开启 `clippy::panic`（restriction）兜底。' '无可用的 lint，需人工评审。'
Rep 'panic = "warn"                        # G.ERR.01  restriction，可选' ''

[System.IO.File]::WriteAllText((Join-Path $PWD $File), $t, [System.Text.UTF8Encoding]::new($false))
Write-Output "done $File"
