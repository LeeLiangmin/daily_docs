# 规范评审 lint PoC

这组 case 支撑内部 Rust 编码规范评审中的【检测】结论，与 Fast 集合遵循同一契约：每个 lint 一个 case；`rule` 按 BotGate 分组登记，规范条款编号写在 `guideline_rules`。

分组规则沿用仓库约定：要求级条款归 Fast（`bot-gate.fast.clippy`），建议级与原则类条款归 PR（`bot-gate.pr.clippy`）；rustc lint 在 Fast 的 `cargo check` 中以 warning 出现，统一归 `bot-gate.fast.check`。

运行（与 Fast 集合同一入口）：

~~~bash
./scripts/validate-fast.sh
~~~

检测方式与 Fast 集合相同（`cargo check` / `cargo clippy -- -W <lint>` + `assert-diagnostics.py`）。另外：

- 每个 case 的 fixture 是故意违规的代码，期望至少命中一次。
- 0 次命中的场景放在对应 case 目录下，样例必须编译通过，且目标 lint **0 次命中**：
  - `pass/<场景>/`：合规代码，lint 有意豁免，与规范一致（`case.toml` 中的 `[[pass]]`）；
  - `known-limit/<场景>/`：规范要求覆盖、但目标 lint 不报的代码，即已知漏报（`case.toml` 中的 `[[known_limit]]`），原因写在 `reason`。
- 0 次命中的断言会同时检查目标 lint 是否被工具链识别（出现 E0602 / unknown_lints 即失败），避免因 lint 名写错而误判通过。
- `derived-hash-with-manual-eq`、`derive-ord-xor-partial-ord`、`macro-metavars-in-unsafe` 是已有的 Fast case，这里只追加了 `guideline_rules`、`known_limits` 与 known-limit 场景，触发契约不变。

规范条款中与 lint 无关的验证（运行时语义、示例能否编译、版本差异）不放在本仓库，见配套的 playground 仓库。

## G.CTF.01

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::unnecessary_unwrap` | `cases/clippy/unnecessary-unwrap` | `bot-gate.pr.clippy` | 1 | `known-limit/struct-field`（漏报）：1.89 只跟踪局部变量，对结构体字段（如 self.value）先判断后 unwrap 不报，1.97 起支持。 | 1.89 只识别局部变量，对结构体字段（如 self.v）先判断后 unwrap 不报；1.97 起支持。 |

## G.CTF.02

无对应 lint（检测能力：不支持），无 PoC。

## G.CTF.03

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::infinite_loop` | `cases/clippy/infinite-loop` | `bot-gate.pr.clippy` | 1 | `pass/never-return`（边界）：函数返回类型为 `!` 时豁免，与规范「有意常驻的循环声明为 `-> !`」一致。<br>`known-limit/panic-exit`（漏报）：以 panic 为唯一出口的循环被视为可退出，但不属于规范要求的安全退出。 | 任何返回 `!` 的调用（panic!、process::exit）都被视为出口。<br>1.89 中未 await 的 async 块内的常驻循环会被误报，1.97 起豁免。 |
| `clippy::while_immutable_condition` | `cases/clippy/while-immutable-condition` | `bot-gate.pr.clippy` | 1 | — | — |
| `unconditional_recursion` | `cases/rustc/unconditional-recursion` | `bot-gate.fast.check` | 1 | `known-limit/unreachable-base`（漏报）：n > 0 时永不终止，但存在终止分支，不报。 | 只要存在语法上的终止分支就不报，即使该分支实际不可达。 |

## G.EXP.01

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::absurd_extreme_comparisons` | `cases/clippy/absurd-extreme-comparisons` | `bot-gate.pr.clippy` | 1 | — | — |
| `clippy::bad_bit_mask` | `cases/clippy/bad-bit-mask` | `bot-gate.pr.clippy` | 2 | — | 掩码来自构建配置生成的常量、在某些配置下为 0 时同样报警（`&-masking with zero`），需局部 allow 并写明原因。 |
| `clippy::eq_op` | `cases/clippy/eq-op` | `bot-gate.pr.clippy` | 1 | — | — |
| `clippy::impossible_comparisons` | `cases/clippy/impossible-comparisons` | `bot-gate.pr.clippy` | 1 | — | — |
| `clippy::overly_complex_bool_expr` | `cases/clippy/overly-complex-bool-expr` | `bot-gate.pr.clippy` | 1 | — | 1.89 属 correctness（默认 deny），1.97 降为 pedantic，升级工具链后需显式开启。 |
| `unused_comparisons` | `cases/rustc/unused-comparisons` | `bot-gate.fast.check` | 1 | — | — |

## G.EXP.02

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::precedence` | `cases/clippy/precedence` | `bot-gate.pr.clippy` | 1 | `known-limit/negative-literal-method`（漏报）：一元负号接方法调用不报，需 rustc ambiguous_negative_literals。<br>`known-limit/bit-shift-mix`（漏报）：位运算与移位混用不报，需 clippy::precedence_bits。 | 1.89 起不再检查一元负号接方法调用，由 rustc 的 ambiguous_negative_literals 负责。<br>1.86 起位运算与移位混用拆到 clippy::precedence_bits。<br>`&&` 与 `||` 混用不在检查范围。 |
| `clippy::precedence_bits` | `cases/clippy/precedence-bits` | `bot-gate.pr.clippy` | 1 | — | — |
| `ambiguous_negative_literals` | `cases/rustc/ambiguous-negative-literals` | `bot-gate.fast.check` | 1 | — | — |

## G.FUD.01

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::large_types_passed_by_value` | `cases/clippy/large-types-passed-by-value` | `bot-gate.pr.clippy` | 1 | `known-limit/pub-fn-default`（漏报）：pub 函数默认被跳过（avoid-breaking-exported-api = true）。<br>`known-limit/non-copy`（漏报）：非 Copy 的大结构体按值传入不报。 | 只检查 Copy 类型；非 Copy 的大类型需 clippy::needless_pass_by_value，且仅在参数未被消费时报。<br>默认 avoid-breaking-exported-api = true，跳过导出 API；在 clippy.toml 中设为 false 后可检查。 |
| `clippy::needless_pass_by_value` | `cases/clippy/needless-pass-by-value` | `bot-gate.pr.clippy` | 1 | — | — |

## G.FUD.02

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `unused_must_use` | `cases/rustc/unused-must-use` | `bot-gate.fast.check` | 3 | `known-limit/let-underscore`（漏报）：`let _ =` 显式丢弃，不报，需人工评审。<br>`known-limit/ok-discard`（漏报）：`.ok();` 丢弃 Result，不报，需人工评审。<br>`known-limit/option-wrapped`（漏报）：must_use 类型包在 Option 中返回，不报，需人工评审。 | 只检查调用方直接忽略；`let _ =`、`.ok();` 不报。<br>#[must_use] 标在类型上时，包一层 Option 后不再生效。 |

## G.TRA.01

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::derive_ord_xor_partial_ord` | `cases/clippy/derive-ord-xor-partial-ord` | `bot-gate.fast.clippy` | 1 | `known-limit/derived-eq-manual-ord`（漏报）：derive 的 PartialEq 比较全部字段、Ord 只比较 uid，a != b 时 cmp 仍可能为 Equal，但不报。 | 只检查 Ord 与 PartialOrd 一个 derive、一个手写；不检查排序与相等性（PartialEq/Eq）是否一致。 |
| `clippy::derived_hash_with_manual_eq` | `cases/clippy/derived-hash-with-manual-eq` | `bot-gate.fast.clippy` | 1 | `known-limit/both-manual`（漏报）：PartialEq 只比较 uid、Hash 还计入 name，口径不一致但不报。 | 只在 derive(Hash) 与手写 PartialEq 混用时介入，两边都手写时不检查口径是否一致。 |
| `clippy::non_canonical_partial_ord_impl` | `cases/clippy/non-canonical-partial-ord-impl` | `bot-gate.fast.clippy` | 1 | — | 只检查 partial_cmp 是否写成 Some(self.cmp(other))，不检查 Ord 与 PartialEq 的口径是否一致。 |

## G.TRA.02

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::from_over_into` | `cases/clippy/from-over-into` | `bot-gate.pr.clippy` | 1 | — | — |

## G.ERR.01

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::expect_used` | `cases/clippy/expect-used` | `bot-gate.pr.clippy` | 1 | — | — |
| `clippy::unwrap_used` | `cases/clippy/unwrap-used` | `bot-gate.pr.clippy` | 1 | `known-limit/expect-call`（漏报）：expect 不在检查范围，需 clippy::expect_used。 | 规范允许的「已提前校验」场景同样报警，需用 #[expect(clippy::unwrap_used, reason = "...")] 局部豁免。<br>测试代码默认也报，需在 clippy.toml 中设置 allow-unwrap-in-tests = true。 |

## G.MOD.01

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::enum_glob_use` | `cases/clippy/enum-glob-use` | `bot-gate.pr.clippy` | 1 | — | — |
| `clippy::wildcard_imports` | `cases/clippy/wildcard-imports` | `bot-gate.pr.clippy` | 1 | `pass/prelude-and-reexport`（边界）：prelude::* 与 pub use 再导出默认豁免，与规范例外一致。<br>`known-limit/test-module`（漏报）：测试模块中的 use std::collections::* 也不报。<br>`known-limit/enum-glob`（漏报）：枚举变体通配导入不报，需 clippy::enum_glob_use。 | cfg(test) 编译时整体跳过，测试模块内任何通配导入都不报。<br>`use Enum::*` 由 clippy::enum_glob_use 负责。 |

## G.MAC.01

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::macro_metavars_in_unsafe` | `cases/clippy/macro-metavars-in-unsafe` | `bot-gate.fast.clippy` | 1 | `known-limit/hardcoded-unsafe-call`（漏报）：宏把固定的 unsafe 调用包装成 safe fn，不经元变量，不报。<br>`known-limit/proc-macro`（漏报）：过程宏把调用方表达式放进 unsafe 块，不报。 | 默认只检查导出宏；私有宏需 warn-unsafe-macro-metavars-in-private-macros = true（本 case 已开启）。<br>只检查实际被调用过的宏。<br>宏内写死、不经元变量的 unsafe 调用不报。<br>过程宏生成的 unsafe 块不在检查范围。 |

## P.MAC.DCL.01

| lint | case | 分组 | 期望 | 0 次命中场景 | 覆盖限制 |
| --- | --- | --- | :---: | --- | --- |
| `clippy::crate_in_macro_def` | `cases/clippy/crate-in-macro-def` | `bot-gate.pr.clippy` | 1 | `known-limit/bare-path`（漏报）：导出宏使用裸路径，跨 crate 调用会找不到 helper，但不报。 | 只检查导出宏中的 `crate::`；宏内裸路径（如 helper()、helper!()）不报。 |

## G.MAC.DCL.01

无对应 lint（检测能力：不支持），无 PoC。

## P.MAC.PRO.01

无对应 lint（检测能力：不支持），无 PoC。
