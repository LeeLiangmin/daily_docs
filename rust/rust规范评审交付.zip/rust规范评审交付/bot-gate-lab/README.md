<div align="center" markdown="1">

**面向 Rust lint 的可复现 PoC 集成测试：用最小 fixture 验证诊断是否真实产生。**

➡️ [这是什么](#what) | [快速开始](#start) | [覆盖范围](#map) | [检测方式](#usage) | [目录与文档](#docs) ⬅️

![Rust](https://img.shields.io/badge/Rust-1.89%2B-orange)
![Lint PoCs](https://img.shields.io/badge/PoCs-43-blue)
![Diagnostics](https://img.shields.io/badge/diagnostics-Cargo%20JSON-brightgreen)
![License](https://img.shields.io/badge/license-Apache--2.0-lightgrey)

</div>

---

<a id="what"></a>

## 🤔 这是什么

bot-gate-lab 是一个 Rust 编译器与 Clippy lint 的 PoC 集成测试仓库。每个 lint 都有独立的最小 fixture、case 元数据和预期诊断；测试运行真实的 cargo check 或 cargo clippy，再从 Cargo JSON compiler-message 中确认目标 lint 是否命中。

当前样例以 BotGate fast 检查的基础 lint 为基线，覆盖 rustc check lint、Fast Minimal Clippy lint，以及由 .botgate/managed/clippy/.../clippy.toml 驱动的 clippy::disallowed_methods，另补充了不在参考 Minimal 集合内的 clippy::approx_constant、clippy::mutex_atomic 和 clippy::mut_from_ref。

这个仓库验证的是“指定工具链下，指定代码是否产生指定诊断”。一个 PoC 命中不代表对应自然语言规则已经得到完整覆盖；wrapper、别名、函数指针、间接调用和其他未写入 fixture 的场景需要单独增加 case。

每次运行交付两类结果：

| 结果 | 作用 |
| --- | --- |
| Case 判定 | 精确确认 lint code、诊断级别、fixture 来源和命中数量。 |
| 原始证据 | 将每个 case 的 Cargo JSON 输出保存到 artifacts/fast/，便于复查工具链行为。 |

---

<a id="start"></a>

## 🚀 快速开始

需要 Rust、Cargo、Clippy 和 Python 3：

~~~bash
rustc --version
cargo --version
cargo clippy --version
python3 --version
~~~

在仓库根目录运行全部 Fast 基础 lint PoC：

~~~bash
./scripts/validate-fast.sh
~~~

预期输出为 63 个 PASS（43 个 case，另有 20 个 pass/ 场景）。结果文件位于：

~~~text
artifacts/fast/
~~~

运行 harness 自身的 Cargo 测试：

~~~bash
cargo test --workspace
~~~

检查格式：

~~~bash
cargo fmt --all -- --check
~~~

---

<a id="map"></a>

## 🗺️ 覆盖范围

### rustc check

| lint | PoC |
| --- | --- |
| missing_abi | cases/rustc/missing-abi |
| improper_ctypes | cases/rustc/improper-ctypes |
| improper_ctypes_definitions | cases/rustc/improper-ctypes-definitions |
| unconditional_recursion | cases/rustc/unconditional-recursion |
| unused_comparisons | cases/rustc/unused-comparisons |
| ambiguous_negative_literals | cases/rustc/ambiguous-negative-literals |
| unused_must_use | cases/rustc/unused-must-use |

### Fast Minimal Clippy

| lint | PoC |
| --- | --- |
| clippy::borrow_interior_mutable_const | cases/clippy/borrow-interior-mutable-const |
| clippy::declare_interior_mutable_const | cases/clippy/declare-interior-mutable-const |
| clippy::derived_hash_with_manual_eq | cases/clippy/derived-hash-with-manual-eq |
| clippy::derive_ord_xor_partial_ord | cases/clippy/derive-ord-xor-partial-ord |
| clippy::blocks_in_conditions | cases/clippy/blocks-in-conditions |
| clippy::recursive_format_impl | cases/clippy/recursive-format-impl |
| clippy::default_numeric_fallback | cases/clippy/default-numeric-fallback |
| clippy::repr_packed_without_abi | cases/clippy/repr-packed-without-abi |
| clippy::macro_metavars_in_unsafe | cases/clippy/macro-metavars-in-unsafe |
| clippy::disallowed_methods | cases/clippy/disallowed-methods |
| clippy::approx_constant | cases/clippy/approx-constant |
| clippy::mutex_atomic | cases/clippy/mutex-atomic |
| clippy::mut_from_ref | cases/clippy/mut-from-ref |
| clippy::wrong_self_convention | cases/clippy/wrong-self-convention |
| clippy::redundant_allocation | cases/clippy/redundant-allocation |
| clippy::borrowed_box | cases/clippy/borrowed-box |
| clippy::box_collection | cases/clippy/box-collection |
| clippy::vec_box | cases/clippy/vec-box |
| clippy::unnecessary_unwrap | cases/clippy/unnecessary-unwrap |
| clippy::infinite_loop | cases/clippy/infinite-loop |
| clippy::while_immutable_condition | cases/clippy/while-immutable-condition |
| clippy::bad_bit_mask | cases/clippy/bad-bit-mask |
| clippy::overly_complex_bool_expr | cases/clippy/overly-complex-bool-expr |
| clippy::impossible_comparisons | cases/clippy/impossible-comparisons |
| clippy::absurd_extreme_comparisons | cases/clippy/absurd-extreme-comparisons |
| clippy::eq_op | cases/clippy/eq-op |
| clippy::precedence | cases/clippy/precedence |
| clippy::precedence_bits | cases/clippy/precedence-bits |
| clippy::large_types_passed_by_value | cases/clippy/large-types-passed-by-value |
| clippy::needless_pass_by_value | cases/clippy/needless-pass-by-value |
| clippy::non_canonical_partial_ord_impl | cases/clippy/non-canonical-partial-ord-impl |
| clippy::from_over_into | cases/clippy/from-over-into |
| clippy::unwrap_used | cases/clippy/unwrap-used |
| clippy::wildcard_imports | cases/clippy/wildcard-imports |
| clippy::enum_glob_use | cases/clippy/enum-glob-use |
| clippy::crate_in_macro_def | cases/clippy/crate-in-macro-def |

blocks_in_conditions case 对应 G.TYP.BOL.01（要求级，归 Fast 分组），预期命中三次目标 warning，覆盖该检查的全部触发位置与消息变体：`if` 条件中的单表达式块、`if` 条件中的含语句块、`match` 被匹配表达式中的块。该检查不覆盖 `while` 条件等位置，条文已注明。

disallowed_methods case 使用参考 BotGate managed Clippy 配置中的代表性 C 函数：memcpy、getenv、strcpy 和 strtok。它验证的是配置名单对直接调用的拦截，不是对所有间接调用的通用安全证明。

approx_constant case 对应编程规范 G.CNS.02，该条款为建议级，因此按“要求级归 Fast、建议级归 PR”的分组规则登记为 `bot-gate.pr.clippy`；它不在参考实现的 Minimal 集合内，属于本仓库的补充覆盖。fixture 中只有 `let x = 3.14_f64;` 这一行命中；同一 fixture 中的 `let y = 1_f64 / x;` 因为 x 是变量而非字面量，实测不触发该 lint。

mutex_atomic case 同样按 Fast clippy 组维护，属于参考 Minimal 集合之外的补充覆盖，预期命中一次目标 warning。

mut_from_ref case 同样按 Fast clippy 组维护，属于参考 Minimal 集合之外的补充覆盖，预期命中一次目标 warning。

wrong_self_convention case 对应编程规范 G.NAM.02，该条款为建议级，因此按“要求级归 Fast、建议级归 PR”的分组规则登记为 `bot-gate.pr.clippy`，预期命中四次目标 warning。fixture 使用私有方法分别违反 `as_`、`to_`、`into_`、`from_` 前缀的接收者约定；该检查只看接收者形式，不覆盖返回值所有权，且在 `avoid-breaking-exported-api` 默认开启时跳过 `pub` 类型上的 `pub` 方法，这也是 fixture 全部使用私有方法的原因。

redundant_allocation case 对应编程规范 G.TYP.PTR.01，该条款为建议级，因此按“要求级归 Fast、建议级归 PR”的分组规则登记为 `bot-gate.pr.clippy`，预期命中四次目标 warning。fixture 覆盖该 lint 的两类形态：智能指针相互嵌套（含 `Arc<Arc<T>>` 这类同类型嵌套）与智能指针包裹引用。该检查只作用于写出的类型，局部变量（即使显式标注类型）与类型别名都不会被检查到，且受 `avoid-breaking-exported-api`（默认 `true`）影响会跳过公开 API，因此 fixture 全部使用私有项并写在类型声明位置。G.TYP.PTR.01 正文提到的 `&Box<T>`、`Box<String>`/`Box<Vec<T>>`、`Vec<Box<T>>` 三类形态分别由 clippy::borrowed_box、clippy::box_collection、clippy::vec_box 检查，已各自建立独立 case。

borrowed_box、box_collection、vec_box 三个 case 同为 G.TYP.PTR.01（建议级）的 PoC，均登记为 `bot-gate.pr.clippy`：borrowed_box 验证 `&Box<T>`（`&mut Box<T>` 不在其检查范围内），预期命中一次；box_collection 验证 `Box<String>` 与 `Box<Vec<T>>`，预期命中两次（`Box<[T]>`、`Box<str>`、`Box<dyn Trait>` 属合理用法，不触发）；vec_box 验证 `Vec<Box<T>>`，预期命中一次（`Vec<Box<dyn Trait>>` 属合理用法，不触发）。三者与 redundant_allocation 一样，只作用于写出的类型，并受 `avoid-breaking-exported-api` 影响跳过公开 API。

---

<a id="usage"></a>

## 🧭 检测方式

validate-fast.sh 根据 case 类型运行：

~~~text
rustc case   cargo check --all-targets --message-format=json
Clippy case  cargo clippy --all-targets --message-format=json -- -W <lint>
~~~

assert-diagnostics.py 解析结构化 compiler-message，校验：

- lint code 与 case 声明完全一致；
- 诊断级别为 warning；
- 主 span 或宏展开来源回到当前 fixture；
- 命中数量符合 case 期望。

BotGate Fast 的策略是“warning 诊断阻断检查步骤”，所以 PoC 不把所有 lint 强制改成 -D，也不只看 Cargo 进程退出码。Cargo 可以成功退出，但只要目标 warning 出现在结构化诊断中，Fast step 就应判定为失败。

每个 case 目录包含：

~~~text
case.toml       # lint、工具、稳定性和预期诊断
Cargo.toml      # 独立 Cargo package
src/lib.rs      # 最小故意违规 fixture
clippy.toml     # 仅在 case 需要独有配置时提供
pass/           # 可选：0 次命中场景；kind 区分 lint 有意豁免（boundary）与已知漏报（known-limit）
~~~

根 workspace 只包含 harness，故意产生诊断的 case 不会被 cargo test --workspace 意外编译。

---

<a id="docs"></a>

## 📚 目录与文档

| 路径 | 内容 |
| --- | --- |
| cases/ | 按 rustc / Clippy 分类的独立 lint PoC。 |
| scripts/validate-fast.sh | 全量验证入口，含规范评审 case 与 pass/ 场景。 |
| scripts/assert-diagnostics.py | Cargo JSON 诊断断言器。 |
| docs/fast-lints.md | BotGate Fast lint 清单、来源和覆盖边界。 |
| docs/lint-poc-architecture.md | PoC、case 契约、runner 和 CI 架构设计。 |

新增 lint 时，创建一个独立 case，写入真实 lint ID 和预期命中数量，再把验证命令加入 scripts/validate-fast.sh。不要用整段日志文本或仅凭退出码作为通过条件。

## ⚖️ 许可证

本项目使用 Apache License 2.0，详见 LICENSE。

