#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "$0")/.." && pwd)"
work="$root/artifacts/fast"
mkdir -p "$work"

check_case() {
    kind="$1"
    name="$2"
    lint="$3"
    fixture="$4"
    count="${5:-1}"
    manifest="$root/cases/$kind/$name/Cargo.toml"
    output="$work/$kind-$name.jsonl"
    if [[ "$kind" == "rustc" ]]; then
        command=(cargo check --manifest-path "$manifest" --all-targets --message-format=json)
    else
        command=(cargo clippy --manifest-path "$manifest" --all-targets --message-format=json -- -W "$lint")
    fi
    if "${command[@]}" >"$output" 2>&1; then
        :
    elif ! grep -q '"reason":"compiler-message"' "$output"; then
        printf 'FAIL %s: command failed without compiler diagnostics\n' "$lint"
        return 1
    fi
    local status=0
    python3 "$root/scripts/assert-diagnostics.py" "$output" "$lint" "$fixture" "$count" || status=1
    # 顺带执行该 case 在 case.toml 中登记的 pass 场景。
    local scenarios
    if ! scenarios="$(list_scenarios "$root/cases/$kind/$name")"; then
        printf 'FAIL %s: invalid scenario registration\n' "$lint"
        return 1
    fi
    local scenario
    while read -r scenario; do
        [[ -n "$scenario" ]] || continue
        check_scenario "$kind" "$name" "$lint" "$scenario" || status=1
    done <<<"$scenarios"
    return "$status"
}

# 列出 case.toml 中登记的 pass 场景（每行一个场景名），并要求与 pass/ 下的场景目录一一对应、kind 合法。
list_scenarios() {
    python3 - "$1" <<'PY'
import pathlib, sys, tomllib

sys.stdout.reconfigure(newline="\n")  # Windows 上默认输出 CRLF，会混进场景名
case_dir = pathlib.Path(sys.argv[1])
case = tomllib.loads((case_dir / "case.toml").read_text(encoding="utf-8"))
ok = True
scenarios = case.get("pass", [])
registered = [s["name"] for s in scenarios]
on_disk = sorted(d.name for d in (case_dir / "pass").glob("*") if (d / "Cargo.toml").is_file())
if sorted(registered) != on_disk:
    print(f"{case_dir.name}: [[pass]] {sorted(registered)} != pass/ {on_disk}", file=sys.stderr)
    ok = False
for s in scenarios:
    if s.get("kind") not in ("boundary", "known-limit"):
        print(f"{case_dir.name}: pass/{s['name']} kind must be boundary or known-limit", file=sys.stderr)
        ok = False
    print(s["name"])
sys.exit(0 if ok else 1)
PY
}

# pass/<scenario>：0 次命中场景，样例必须编译通过，且目标 lint 0 次命中。
# kind = "boundary" 为合规代码、lint 有意豁免；kind = "known-limit" 为规则要求覆盖、但目标 lint 不报。
check_scenario() {
    kind="$1"
    name="$2"
    lint="$3"
    scenario="$4"
    manifest="$root/cases/$kind/$name/pass/$scenario/Cargo.toml"
    output="$work/$kind-$name-pass-$scenario.jsonl"
    if [[ "$kind" == "rustc" ]]; then
        command=(cargo check --manifest-path "$manifest" --all-targets --message-format=json)
    else
        command=(cargo clippy --manifest-path "$manifest" --all-targets --message-format=json -- -W "$lint")
    fi
    if ! "${command[@]}" >"$output" 2>&1; then
        printf 'FAIL %s pass/%s: build failed\n' "$lint" "$scenario"
        return 1
    fi
    python3 "$root/scripts/assert-diagnostics.py" "$output" "$lint" lib.rs 0
}

failed=0

check_case rustc missing-abi missing_abi lib.rs || failed=$((failed + 1))
check_case rustc improper-ctypes improper_ctypes lib.rs || failed=$((failed + 1))
check_case rustc improper-ctypes-definitions improper_ctypes_definitions lib.rs || failed=$((failed + 1))
check_case clippy borrow-interior-mutable-const clippy::borrow_interior_mutable_const lib.rs || failed=$((failed + 1))
check_case clippy declare-interior-mutable-const clippy::declare_interior_mutable_const lib.rs || failed=$((failed + 1))
check_case clippy derived-hash-with-manual-eq clippy::derived_hash_with_manual_eq lib.rs || failed=$((failed + 1))
check_case clippy derive-ord-xor-partial-ord clippy::derive_ord_xor_partial_ord lib.rs || failed=$((failed + 1))
check_case clippy blocks-in-conditions clippy::blocks_in_conditions lib.rs 3 || failed=$((failed + 1))
check_case clippy recursive-format-impl clippy::recursive_format_impl lib.rs || failed=$((failed + 1))
check_case clippy default-numeric-fallback clippy::default_numeric_fallback lib.rs 5 || failed=$((failed + 1))
check_case clippy repr-packed-without-abi clippy::repr_packed_without_abi lib.rs || failed=$((failed + 1))
check_case clippy macro-metavars-in-unsafe clippy::macro_metavars_in_unsafe lib.rs || failed=$((failed + 1))
check_case clippy disallowed-methods clippy::disallowed_methods lib.rs 4 || failed=$((failed + 1))
check_case clippy approx-constant clippy::approx_constant lib.rs || failed=$((failed + 1))
check_case clippy mutex-atomic clippy::mutex_atomic lib.rs || failed=$((failed + 1))
check_case clippy mut-from-ref clippy::mut_from_ref lib.rs || failed=$((failed + 1))
check_case clippy wrong-self-convention clippy::wrong_self_convention lib.rs 4 || failed=$((failed + 1))
check_case clippy redundant-allocation clippy::redundant_allocation lib.rs 4 || failed=$((failed + 1))
check_case clippy borrowed-box clippy::borrowed_box lib.rs 1 || failed=$((failed + 1))
check_case clippy box-collection clippy::box_collection lib.rs 2 || failed=$((failed + 1))
check_case clippy vec-box clippy::vec_box lib.rs 1 || failed=$((failed + 1))

# 规范 G.CTF.01
check_case clippy unnecessary-unwrap clippy::unnecessary_unwrap lib.rs || failed=$((failed + 1))
# 规范 G.CTF.03
check_case clippy infinite-loop clippy::infinite_loop lib.rs || failed=$((failed + 1))
check_case clippy while-immutable-condition clippy::while_immutable_condition lib.rs || failed=$((failed + 1))
check_case rustc unconditional-recursion unconditional_recursion lib.rs || failed=$((failed + 1))
# 规范 G.EXP.01
check_case clippy bad-bit-mask clippy::bad_bit_mask lib.rs 2 || failed=$((failed + 1))
check_case clippy overly-complex-bool-expr clippy::overly_complex_bool_expr lib.rs || failed=$((failed + 1))
check_case clippy impossible-comparisons clippy::impossible_comparisons lib.rs || failed=$((failed + 1))
check_case clippy absurd-extreme-comparisons clippy::absurd_extreme_comparisons lib.rs || failed=$((failed + 1))
check_case clippy eq-op clippy::eq_op lib.rs || failed=$((failed + 1))
check_case rustc unused-comparisons unused_comparisons lib.rs || failed=$((failed + 1))
# 规范 G.EXP.02
check_case clippy precedence clippy::precedence lib.rs || failed=$((failed + 1))
check_case clippy precedence-bits clippy::precedence_bits lib.rs || failed=$((failed + 1))
check_case rustc ambiguous-negative-literals ambiguous_negative_literals lib.rs || failed=$((failed + 1))
# 规范 G.FUD.01
check_case clippy large-types-passed-by-value clippy::large_types_passed_by_value lib.rs || failed=$((failed + 1))
check_case clippy needless-pass-by-value clippy::needless_pass_by_value lib.rs || failed=$((failed + 1))
# 规范 G.FUD.02
check_case rustc unused-must-use unused_must_use lib.rs 3 || failed=$((failed + 1))
# 规范 G.TRA.01
check_case clippy non-canonical-partial-ord-impl clippy::non_canonical_partial_ord_impl lib.rs || failed=$((failed + 1))
# 规范 G.TRA.02
check_case clippy from-over-into clippy::from_over_into lib.rs || failed=$((failed + 1))
# 规范 G.ERR.01
check_case clippy unwrap-used clippy::unwrap_used lib.rs || failed=$((failed + 1))
# 规范 G.MOD.01
check_case clippy wildcard-imports clippy::wildcard_imports lib.rs || failed=$((failed + 1))
check_case clippy enum-glob-use clippy::enum_glob_use lib.rs || failed=$((failed + 1))
# 规范 P.MAC.DCL.01
check_case clippy crate-in-macro-def clippy::crate_in_macro_def lib.rs || failed=$((failed + 1))

printf '\n'
if ((failed > 0)); then
    printf 'FAILED: %d case(s)\n' "$failed"
    exit 1
fi
printf 'OK: all cases passed\n'

