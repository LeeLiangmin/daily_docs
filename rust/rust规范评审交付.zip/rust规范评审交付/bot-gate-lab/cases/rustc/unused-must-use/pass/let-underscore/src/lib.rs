// pass 场景 let-underscore（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.FUD.02；目标 lint：unused_must_use，断言 0 次命中。
//
// let _ = 显式丢弃了 #[must_use] 函数的返回值，规范要求在评审中关注这种写法。
// unused_must_use 把 let _ = 视为有意丢弃，不报，需人工评审。

#[must_use]
fn foo1() -> i32 { 0 }

pub fn caller() {
    let _ = foo1(); // 显式丢弃 must_use 返回值
}
