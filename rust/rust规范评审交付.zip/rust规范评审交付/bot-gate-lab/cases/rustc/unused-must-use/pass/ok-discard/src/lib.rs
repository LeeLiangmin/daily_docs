// pass 场景 ok-discard（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.FUD.02；目标 lint：unused_must_use，断言 0 次命中。
//
// .ok() 把 Result 转成 Option 后直接丢弃，错误被静默吞掉。
// Option 不是 must_use 类型，unused_must_use 不报，需人工评审。

fn foo3() -> Result<(), String> { Ok(()) }

pub fn caller() {
    foo3().ok(); // Result 转为 Option 后丢弃，错误被忽略
}
