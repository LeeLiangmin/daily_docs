// pass 场景 option-wrapped（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.FUD.02；目标 lint：unused_must_use，断言 0 次命中。
//
// Token 标注了 #[must_use]，但包在 Option 中返回后，类型上的标注不再生效，调用方丢弃返回值不报。
// 规范建议对关键返回值在函数上同时标注 #[must_use]；当前写法需人工评审。

#[must_use]
pub struct Token(u32);

fn issue() -> Option<Token> { Some(Token(1)) }

pub fn caller() {
    issue(); // 丢弃了 Option<Token>，Token 上的 must_use 不生效
}
