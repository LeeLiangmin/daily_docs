// pass 场景 unreachable-base（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.CTF.03；目标 lint：unconditional_recursion，断言 0 次命中。
//
// n > 0 时每次递归 n + 1，永远到不了终止分支 n == 0，违反「循环或递归应能安全退出」。
// unconditional_recursion 只要存在不递归的分支就认为可以终止，不分析该分支能否到达，不报。

pub fn depth(n: u64) -> u64 {
    if n == 0 { 0 } else { depth(n + 1) } // n 只增不减，n > 0 时无法终止
}
