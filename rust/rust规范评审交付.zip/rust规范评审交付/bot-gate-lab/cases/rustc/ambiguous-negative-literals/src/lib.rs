#![warn(ambiguous_negative_literals)]

pub fn demo() -> i32 {
    -1i32.abs()
}
