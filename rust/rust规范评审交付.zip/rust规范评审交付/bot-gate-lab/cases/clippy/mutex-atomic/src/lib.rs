use std::sync::Mutex;

pub static READY: Mutex<bool> = Mutex::new(false);
