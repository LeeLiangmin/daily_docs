// 对应规范 G.TYP.BOL.01：不宜使用块表达式作为控制表达式。
// 覆盖该 lint 的全部触发位置与消息变体：if 条件中的单表达式块、
// if 条件中的含语句块、match 被匹配表达式中的块。
pub fn condition() -> bool {
    // 不符合：if 条件为单表达式块
    if { true } {
        true
    } else {
        false
    }
}

pub fn complex_condition(value: u8) -> bool {
    // 不符合：if 条件为含语句的复杂块
    if {
        let threshold = 10;
        value > threshold
    } {
        true
    } else {
        false
    }
}

pub fn scrutinee() {
    // 不符合：match 被匹配表达式为含语句的块
    match {
        println!("side effect");
        std::env::var("PATH")
    } {
        Ok(_) => (),
        _ => (),
    }
}
