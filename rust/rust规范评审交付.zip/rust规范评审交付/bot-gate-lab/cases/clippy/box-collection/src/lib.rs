// 对应规范 G.TYP.PTR.01：对已在堆上的类型重复装箱是冗余的。
// 该检查只作用于写出的类型；Box<[T]>、Box<str>、Box<dyn Trait> 属于合理用法，不触发。
#![allow(dead_code)]

// 不符合：String 本身已在堆上，无需装箱
fn name() -> Box<String> {
    Box::new(String::new())
}

// 不符合：Vec 本身已在堆上，无需装箱
fn items() -> Box<Vec<u32>> {
    Box::new(vec![])
}
