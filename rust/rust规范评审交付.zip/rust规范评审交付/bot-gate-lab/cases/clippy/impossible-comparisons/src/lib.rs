pub fn demo(x: u32) -> bool {
    x > 10 && x < 5
}
