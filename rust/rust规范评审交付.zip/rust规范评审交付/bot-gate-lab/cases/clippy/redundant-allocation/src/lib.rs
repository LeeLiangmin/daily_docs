// 对应规范 G.TYP.PTR.01：不宜使用冗余的智能指针嵌套与装箱。
#![allow(dead_code)]

use std::rc::Rc;
use std::sync::Arc;

// 触发条件决定了 fixture 的写法：
// 1. 该检查只作用于写出的类型，局部变量（即使显式标注类型）与类型别名都不会被检查到；
// 2. 该检查受 avoid-breaking-exported-api（默认 true）影响，会跳过公开 API。
// fixture 只使用 redundant_allocation 覆盖的形态：智能指针相互嵌套、智能指针包裹引用。
struct Config {
    // 不符合：Rc 与 Box 相互嵌套
    name: Rc<Box<String>>,
    // 不符合：Box 与 Arc 相互嵌套
    handler: Box<Arc<u32>>,
    // 不符合：Arc 与 Arc 同类型嵌套
    backup: Arc<Arc<u8>>,
}

// 不符合：智能指针包裹引用，被包裹的引用本身已是指针
fn unwrap_name(wrapped: Box<&'static str>) -> &'static str {
    *wrapped
}
