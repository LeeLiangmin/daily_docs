// pass 场景 pub-fn-default（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.FUD.01；目标 lint：clippy::large_types_passed_by_value，断言 0 次命中。
//
// [i32; 1000] 约 4KB，按值传入，违反「拷贝代价大的参数应按引用传递」。
// clippy 默认 avoid-breaking-exported-api = true，对 pub 函数跳过检查，因此不报；
// 需在 clippy.toml 中设为 false 才能覆盖公开接口。

pub fn func(val: [i32; 1000]) -> i32 {
    val[0]
}
