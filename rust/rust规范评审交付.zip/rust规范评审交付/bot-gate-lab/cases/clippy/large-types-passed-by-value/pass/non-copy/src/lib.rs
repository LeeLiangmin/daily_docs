// pass 场景 non-copy（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.FUD.01；目标 lint：clippy::large_types_passed_by_value，断言 0 次命中。
//
// Big 超过 4KB，却按值传入 inspect，违反「拷贝代价大的参数应按引用传递」。
// large_types_passed_by_value 只检查实现了 Copy 的类型；Big 含 String，不是 Copy，不报。

pub struct Big {
    pub buf: [u8; 4096],
    pub name: String,
}

#[allow(dead_code)]
fn inspect(b: Big) -> usize {
    b.buf.len() + b.name.len()
}
