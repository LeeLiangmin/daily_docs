// pass 场景 proc-macro（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.MAC.01；目标 lint：clippy::macro_metavars_in_unsafe，断言 0 次命中。
//
// 过程宏 rmacro::run_unchecked!（见 rmacro/src/lib.rs）把调用方传入的表达式原样放进 unsafe 块，
// 调用方不写 unsafe 就能调用 unsafe fn，违反「不应通过宏将 unsafe 代码伪装为 safe 代码」。
// macro_metavars_in_unsafe 只分析声明宏（macro_rules!），不检查过程宏，不报。

unsafe fn read_raw(p: *const i32) -> i32 {
    unsafe { *p }
}

pub fn caller() -> i32 {
    let v = 7;
    let p = &v as *const i32;
    // 调用方没有写 unsafe，却执行了 unsafe fn
    rmacro::run_unchecked!(read_raw(p))
}
