// 配套的过程宏 crate，供上一级 pass/proc-macro 场景使用（G.MAC.01 漏报）。
// run_unchecked! 把调用方传入的表达式原样包进 unsafe 块，等于替调用方写了 unsafe。

use proc_macro::TokenStream;

#[proc_macro]
pub fn run_unchecked(input: TokenStream) -> TokenStream {
    format!("{{ unsafe {{ {input} }} }}")
        .parse()
        .expect("generated tokens must parse")
}
