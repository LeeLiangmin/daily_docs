// pass 场景 hardcoded-unsafe-call（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.MAC.01；目标 lint：clippy::macro_metavars_in_unsafe，断言 0 次命中。
//
// 宏 expose! 把固定的 unsafe 调用（解引用空指针）包装成 safe 的 pub fn，违反「不应通过宏将 unsafe 代码伪装为 safe 代码」。
// macro_metavars_in_unsafe 只检查元变量（$x）是否被展开在 unsafe 块内；这里 unsafe 块里没有元变量，不报。

unsafe fn dangerous_function() -> i32 {
    let ptr: *const i32 = std::ptr::null();
    unsafe { *ptr }
}

#[macro_export]
macro_rules! expose {
    ($name:ident) => {
        pub fn $name() -> i32 {
            unsafe { dangerous_function() } // 没有校验前置条件，却对外暴露为 safe fn
        }
    };
}

expose!(looks_safe);
