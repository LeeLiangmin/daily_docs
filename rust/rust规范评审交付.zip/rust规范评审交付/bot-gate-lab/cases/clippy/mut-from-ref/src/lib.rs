use std::slice;

pub struct Buffer<T> {
    ptr: *const T,
    len: usize,
}

impl<T> Buffer<T> {
    fn len(&self) -> usize {
        self.len
    }

    // Intentionally unsound: repeated calls can create overlapping mutable slices.
    pub fn as_mut_slice(&self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr as *mut T, self.len()) }
    }
}
