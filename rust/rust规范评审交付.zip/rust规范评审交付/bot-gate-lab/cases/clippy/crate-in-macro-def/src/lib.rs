pub fn helper() -> i32 { 1 }

#[macro_export]
macro_rules! with_crate_kw {
    () => { crate::helper() };
}
