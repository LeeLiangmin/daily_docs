// pass 场景 bare-path（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：P.MAC.DCL.01；目标 lint：clippy::crate_in_macro_def，断言 0 次命中。
//
// 导出宏 with_bare_path 用裸路径 helper() 引用本 crate 的函数，违反「同 crate 内的 item 应通过 $crate 引用」。
// 其他 crate 调用该宏时 helper 会按调用方 crate 解析，找不到或指向错误的函数。
// crate_in_macro_def 只检查宏里写了 crate:: 却没写 $crate:: 的情况，裸路径不在检查范围。

pub fn helper() -> i32 { 1 }

#[macro_export]
macro_rules! with_bare_path {
    () => { helper() }; // 应写为 $crate::helper()
}
