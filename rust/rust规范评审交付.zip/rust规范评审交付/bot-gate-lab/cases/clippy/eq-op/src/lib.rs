pub fn demo(x: u32) -> bool {
    x == x
}
