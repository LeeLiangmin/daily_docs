// pass 场景 both-manual（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.TRA.01；目标 lint：clippy::derived_hash_with_manual_eq，断言 0 次命中。
//
// PartialEq 只比较 uid，Hash 还计入 name，违反「a == b ⇒ hash(a) == hash(b)」：
// uid 相同、name 不同时 a == b，但哈希值不同，HashMap / HashSet 会查找失败。
// 该 lint 只检查 derive(Hash) 与手写 PartialEq 混用；这里两者都手写，不报。

use std::hash::{Hash, Hasher};

#[derive(Eq)]
pub struct Employee {
    uid: u32,
    name: String,
}

impl PartialEq for Employee {
    fn eq(&self, other: &Self) -> bool {
        self.uid == other.uid
    }
}

impl Hash for Employee {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.uid.hash(state);
        self.name.hash(state); // eq 没有比较 name，hash 却计入了 name
    }
}
