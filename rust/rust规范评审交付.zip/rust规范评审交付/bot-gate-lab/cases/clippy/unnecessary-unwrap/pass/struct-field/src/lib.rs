// pass 场景 struct-field（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.CTF.01；目标 lint：clippy::unnecessary_unwrap，断言 0 次命中。
//
// 先用 is_some() 判断、再对 self.value 调用 unwrap()，违反「宜优先使用模式匹配而非判断后再取值」。
// unnecessary_unwrap 在 1.89 中只跟踪局部变量，结构体字段不报；1.97 起可识别（版本差异）。

pub struct Holder {
    pub value: Option<i32>,
}

impl Holder {
    pub fn take(&self) -> i32 {
        if self.value.is_some() {
            return self.value.unwrap(); // 应改为 if let Some(v) = self.value
        }
        0
    }
}
