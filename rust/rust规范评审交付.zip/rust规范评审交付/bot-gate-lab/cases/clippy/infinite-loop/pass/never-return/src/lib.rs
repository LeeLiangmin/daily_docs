// pass 场景 never-return（边界：lint 有意豁免，与规范一致）
// 规范：G.CTF.03；目标 lint：clippy::infinite_loop，断言 0 次命中。
//
// 有意常驻的循环，所在函数返回类型声明为 `!`，符合规范要求的写法。
// infinite_loop 对返回 `!` 的函数豁免，与规范一致，不报是预期行为。

pub fn serve() -> ! {
    loop {
        std::hint::black_box(0);
    }
}
