// pass 场景 panic-exit（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.CTF.03；目标 lint：clippy::infinite_loop，断言 0 次命中。
//
// 循环唯一的出口是 panic!，规范不把 panic 视为安全退出。
// infinite_loop 只要循环体内存在发散出口（panic!、return、break 等）就认为可退出，不报。

pub fn run(limit: u32) {
    let mut counter = 0u32;
    loop {
        counter += 1;
        if counter > limit {
            panic!("overflow"); // 唯一出口是 panic，不是安全退出
        }
    }
}
