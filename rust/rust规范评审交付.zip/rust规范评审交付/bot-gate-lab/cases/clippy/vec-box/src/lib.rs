// 对应规范 G.TYP.PTR.01：Vec 本身已在堆上，元素无需再装箱。
// Vec<Box<dyn Trait>> 属于合理用法，不触发。
#![allow(dead_code)]

// 不符合：Vec 元素无需装箱
fn numbers() -> Vec<Box<u32>> {
    vec![Box::new(1)]
}
