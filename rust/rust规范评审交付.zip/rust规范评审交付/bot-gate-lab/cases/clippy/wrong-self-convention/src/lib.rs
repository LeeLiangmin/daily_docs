// 对应规范 G.NAM.02：类型转换函数命名宜遵循所有权语义。
// 四个方法分别违反 as_、to_、into_、from_ 前缀的接收者约定。
#![allow(dead_code)]

pub struct Wrapper(String);

impl Wrapper {
    // 不符合：as_ 命名的方法不应获取 self 的所有权
    fn as_str(self) -> String {
        self.0
    }

    // 不符合：非 Copy 类型以 to_ 命名的方法不应使用 &mut self 作为接收者
    fn to_my_string(&mut self) -> String {
        self.0.clone()
    }

    // 不符合：into_ 命名的方法应获取 self 的所有权
    fn into_my_string(&self) -> String {
        self.0.clone()
    }

    // 不符合：from_ 命名的方法是构造转换，不应接收 self
    fn from_my_string(&self) -> String {
        self.0.clone()
    }
}
