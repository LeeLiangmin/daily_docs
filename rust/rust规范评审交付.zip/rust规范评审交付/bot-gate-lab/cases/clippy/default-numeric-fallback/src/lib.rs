// 对应规范 G.TYP.01：定义局部变量初始化为数值字面量时，应添加明确的类型标识。
// 覆盖裸字面量与初始值表达式内部嵌套的字面量：后者每个字面量各命中一次。
#![allow(dead_code)]

pub fn defaulted_number() -> String {
    // 不符合：未标注类型，回退为 i32
    let value = 1;
    value.to_string()
}

pub fn nested_literals() {
    // 不符合：vec! 中的两个字面量各自回退为 i32
    let items = vec![1, 2];
    // 不符合：运算表达式中的两个字面量各自回退为 i32
    let total = 1 + 2;
    // 符合：写明类型后，初始值内部的字面量不再回退
    let typed: Vec<u32> = vec![1, 2];
    let _ = (items, total, typed);
}
