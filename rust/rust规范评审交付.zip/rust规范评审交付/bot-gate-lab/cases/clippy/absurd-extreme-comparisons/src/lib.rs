#![allow(unused_comparisons)]
pub fn demo(x: u32) -> bool {
    x >= 0
}
