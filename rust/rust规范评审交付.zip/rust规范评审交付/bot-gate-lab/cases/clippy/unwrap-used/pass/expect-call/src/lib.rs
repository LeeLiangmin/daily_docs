// pass 场景 expect-call（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.ERR.01；目标 lint：clippy::unwrap_used，断言 0 次命中。
//
// expect() 与 unwrap() 一样会在失败时 panic，同样属于规范要求关注的写法。
// unwrap_used 只检查 unwrap()，不检查 expect()；expect 的使用需人工评审。

pub fn port(s: &str) -> u16 {
    s.parse().expect("bad port")
}
