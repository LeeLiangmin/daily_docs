// pass 场景 negative-literal-method（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.EXP.02；目标 lint：clippy::precedence，断言 0 次命中。
//
// -1i32.abs() 实际按 -(1i32.abs()) 计算，结果为 -1 而不是 1，违反「用括号明确操作顺序」。
// precedence 不检查一元负号与方法调用的组合，需 rustc 的 ambiguous_negative_literals。

pub fn demo() -> i32 {
    -1i32.abs() // 实际为 -(1i32.abs())，结果是 -1
}
