// pass 场景 bit-shift-mix（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.EXP.02；目标 lint：clippy::precedence，断言 0 次命中。
//
// x & 0xF0 >> 4 实际按 x & (0xF0 >> 4) 计算，容易误读为 (x & 0xF0) >> 4，违反「用括号明确操作顺序」。
// precedence 不检查位运算与移位混用，需另开 clippy::precedence_bits。

pub fn demo(x: u32) -> u32 {
    x & 0xF0 >> 4 // 实际为 x & (0xF0 >> 4)
}
