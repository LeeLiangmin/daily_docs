#![allow(unused)]
use std::ptr::*;

pub fn demo() {
    let mut rust = vec!['b', 'u', 's', 't'];
    let b = unsafe { replace(&mut rust[0], 'r') };
}
