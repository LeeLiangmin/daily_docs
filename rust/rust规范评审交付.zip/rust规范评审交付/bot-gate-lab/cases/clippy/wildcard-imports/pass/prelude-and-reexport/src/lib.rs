// pass 场景 prelude-and-reexport（边界：lint 有意豁免，与规范一致）
// 规范：G.MOD.01；目标 lint：clippy::wildcard_imports，断言 0 次命中。
//
// prelude::* 是规范允许的例外；pub use inner::* 是再导出，不属于为本模块导入名字。
// wildcard_imports 默认对这两种写法豁免，与规范一致，不报是预期行为。

pub mod inner {
    pub fn helper() {}
    pub mod prelude {
        pub fn p() {}
    }
}

pub use inner::*; // 再导出，默认豁免
use inner::prelude::*; // prelude，规范例外

pub fn demo() {
    p();
}
