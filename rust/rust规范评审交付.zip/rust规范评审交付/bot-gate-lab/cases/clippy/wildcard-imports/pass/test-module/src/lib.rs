// pass 场景 test-module（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.MOD.01；目标 lint：clippy::wildcard_imports，断言 0 次命中。
//
// 规范只允许测试模块用 use super::* 导入被测模块，use std::collections::* 不在例外范围。
// wildcard_imports 对测试模块中的通配导入一律豁免，因此 std::collections::* 也不报。

pub fn add(a: i32, b: i32) -> i32 { a + b }

#[cfg(test)]
mod tests {
    use super::*; // 规范允许
    use std::collections::*; // 规范不允许，但同样不报

    #[test]
    fn t() {
        let mut m = HashMap::new();
        m.insert(1, add(1, 2));
        assert_eq!(m[&1], 3);
    }
}
