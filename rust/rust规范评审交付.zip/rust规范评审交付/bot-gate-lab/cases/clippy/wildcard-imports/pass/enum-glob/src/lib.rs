// pass 场景 enum-glob（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.MOD.01；目标 lint：clippy::wildcard_imports，断言 0 次命中。
//
// use Color::* 是通配符导入，违反「导入时应避免直接使用通配符」。
// wildcard_imports 不检查枚举变体的通配导入，需另开 clippy::enum_glob_use。

pub enum Color { Red, Green }
use Color::*; // 枚举变体通配导入

pub fn is_red(c: &Color) -> bool {
    matches!(c, Red)
}
