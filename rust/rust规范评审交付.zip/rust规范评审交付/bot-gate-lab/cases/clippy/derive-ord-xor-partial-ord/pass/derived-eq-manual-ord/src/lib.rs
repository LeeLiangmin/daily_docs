// pass 场景 derived-eq-manual-ord（漏报：规范要求覆盖，但目标 lint 不报）
// 规范：G.TRA.01；目标 lint：clippy::derive_ord_xor_partial_ord，断言 0 次命中。
//
// derive 的 PartialEq/Eq 比较全部字段，手写的 Ord 只比较 uid，违反「a == b ⇔ a.cmp(&b) == Equal」：
// uid 相同、name 不同时 a != b，但 cmp 返回 Equal，放进 BTreeSet 会丢元素。
// 该 lint 只检查 Ord 与 PartialOrd 是否一个 derive、一个手写；这里两者都手写，不报。

use std::cmp::Ordering;

#[derive(PartialEq, Eq)]
pub struct Employee {
    uid: u32,
    name: String,
}

impl PartialOrd for Employee {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Employee {
    fn cmp(&self, other: &Self) -> Ordering {
        self.uid.cmp(&other.uid) // 与 derive 的 PartialEq 口径不一致
    }
}
