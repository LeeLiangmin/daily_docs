// 对应规范 G.TYP.PTR.01：对 Box<T> 取引用是冗余的，宜直接使用 &T。
// 该检查只看写出的类型，且 &mut Box<T> 不属于本条检查范围。
#![allow(dead_code)]

// 不符合：&Box<String> 宜改为 &String
fn value_len(text: &Box<String>) -> usize {
    text.len()
}
