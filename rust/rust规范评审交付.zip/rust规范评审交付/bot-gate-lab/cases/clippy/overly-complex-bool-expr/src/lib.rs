#![allow(clippy::nonminimal_bool)]
pub fn demo(x: u32, y: u32) -> bool {
    (x < y) && false
}
