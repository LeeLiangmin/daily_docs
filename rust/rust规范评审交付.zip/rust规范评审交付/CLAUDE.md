# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

Not a single project: a **review deliverable** for an internal Rust coding guideline (15 clauses, e.g. `G.ERR.01`, `P.MAC.DCL.01`), written in Chinese. It is a set of documents plus two independent Cargo repos that back the documents' lint claims with reproducible experiments. Lint baseline is rustc/Clippy **1.89.0**; 26 lints are retained (G.CTF.02, G.MAC.DCL.01, P.MAC.PRO.01 have no lint).

The top-level directory is not a git repo or Cargo workspace. `bot-gate-lab/` has its own `.git` (work lives on branch `feat/cases-review-15-rules`); `playground/` has no git. `.acl-recovery/` and `experiments/` are scratch/one-off scripts (HTML/PoC fix-ups), not part of the deliverable.

## Documents (top level)

- `规范-整理版.md` = original guideline, formatting fixes only. `规范-修订稿.md` = revised guideline (each clause gains a 【检测】 field naming the lint and what it does not cover). Keep these two diffable against each other.
- `规范评审处理记录.md` is the decision log (diff, rationale, severity, lint changes, PoC location per clause); `评审报告.md` the overall review; `规范lint对照表.md` the 26-lint table; `POC清单.md` the PoC index.
- `Rust规范评审对照.html` is a single-file offline side-by-side (original vs revised + conclusions + PoC results), ~330KB. It duplicates content from the markdown files, so edits to clauses/conclusions must be mirrored there (`experiments/fix-html*.ps1` are earlier ad-hoc patchers).
- Clause IDs are the join key across everything: document sections, `playground/cases/guideline/<clause>/`, and `bot-gate-lab` `case.toml` `rule` field.

## bot-gate-lab (lint gate PoCs)

One case per lint ID under `cases/<rustc|clippy>/<lint>/` (independent Cargo package + `case.toml` + `src/lib.rs`). The root workspace contains only `harness/` (`exclude = ["cases/*"]`), so the deliberately-violating fixtures are never built by `cargo test --workspace`. Misses/exemptions are `pass/<scenario>/` sub-packages asserting **0 hits** of the target lint (`kind` distinguishes boundary vs. known-limit).

Pass criteria come from parsing Cargo JSON `compiler-message`s (`scripts/assert-diagnostics.py`: lint code, level, fixture span, count) — never exit codes or log text. Clippy cases run with `-W <lint>`; rustc cases use `cargo check`.

```bash
./scripts/validate-guideline.sh   # 23 guideline cases + 20 pass scenarios
./scripts/validate-fast.sh        # 14 base Fast lint cases
cargo test --workspace            # harness tests only
cargo fmt --all -- --check
```

There is no per-case runner flag; to run one case manually: `cargo clippy --manifest-path cases/clippy/<lint>/Cargo.toml --all-targets --message-format=json -- -W clippy::<lint>`. New lint = new case dir with real lint ID + expected count, plus a line in the relevant `scripts/validate-*.sh`. Output goes to gitignored `artifacts/`. Docs: `docs/guideline-lints.md` (clause mapping/limits), `docs/lint-poc-architecture.md` (case contract).

## playground (learning library)

63 cases organized by clause: `cases/guideline/<clause>/<clause>-NN/` (`case.toml` with `category` ∈ 命中/漏报/误报/误报风险/边界/语义验证/示例校验/版本差异, `args`, `[[expect]]` counts, optional compile-fail or runtime-output assertions). No external deps; runner forces `--offline`. Cases do **not** inherit `config/` — each case's lint levels come solely from its own `args`.

```powershell
python scripts/validate-guideline.py                  # all cases
python scripts/validate-guideline.py g-err-01         # filter (also "G.ERR.01", or one case "G.ERR.01-03")
python scripts/validate-guideline.py -v G.ERR.01-03   # full evidence for one case
python scripts/validate-guideline.py --category 漏报   # by category;  --list to only list
python scripts/render-guideline-poc-list.py           # regenerate docs/guideline-poc-list.md, lint-catalog.md
```

Exit codes: 0 all match, 1 mismatch, 2 environment/args. A PASS means "observed matches `case.toml`", not "Clippy catches it" (expected-zero and expected-compile-fail cases PASS). Version-sensitive cases declare `since = { "1.97.0" = N }` in `[[expect]]`; only unfiltered full runs overwrite `artifacts/guideline/results.json`. `artifacts/guideline/` holds the 1.89 measured data; per the top-level `README.md`, 1.97 differs in three lints (`unnecessary_unwrap`, `infinite_loop`, `overly_complex_bool_expr`), handled via `since`. `config/Cargo.toml.lints.example` (exactly the 26 lints) and `config/clippy.toml` are the recommended project config. `docs/规范/` holds copies of the revised/original guideline and decision log — keep in sync with the top-level files.

Generated files (per-case `README.md`, `docs/guideline-poc-list*.md`, `docs/lint-catalog.md`) come from the render script; regenerate rather than hand-edit.
