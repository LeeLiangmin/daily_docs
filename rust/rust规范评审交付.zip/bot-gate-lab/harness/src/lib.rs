//! The fast lint PoCs are intentionally executed as external Cargo packages.
//! This package exists as the workspace-owned harness boundary.

#[cfg(test)]
mod tests {
    #[test]
    fn harness_boundary_is_present() {
        assert!(true);
    }
}
