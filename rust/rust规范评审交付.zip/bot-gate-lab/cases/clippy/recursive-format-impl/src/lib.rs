use std::fmt;

pub struct Recursive;

impl fmt::Display for Recursive {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{self}")
    }
}

