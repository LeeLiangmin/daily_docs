#[repr(packed)]
pub struct Packed {
    pub value: u16,
}

