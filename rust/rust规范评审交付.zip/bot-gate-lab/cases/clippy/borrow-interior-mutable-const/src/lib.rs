use std::cell::Cell;

pub const VALUE: Cell<u32> = Cell::new(0);

pub fn borrow_value() {
    let _borrowed = &VALUE;
}

