macro_rules! hide_unsafe {
    ($expr:expr) => {{ unsafe { $expr } }};
}

unsafe fn dangerous() -> i32 {
    42
}

pub fn invoke() {
    let _ = hide_unsafe!(dangerous());
}

