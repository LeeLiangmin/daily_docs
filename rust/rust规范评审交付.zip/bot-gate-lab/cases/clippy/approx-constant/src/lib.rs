#![allow(unused_variables)]

pub fn approximate_constant() {
    let min: i8 = -128;
    let max: u16 = 65535;

    // 不符合：用字面量近似 f64::consts::PI
    let x = 3.14_f64;
    let y = 1_f64 / x;
}
