use std::cell::Cell;

pub const VALUE: Cell<u32> = Cell::new(0);

