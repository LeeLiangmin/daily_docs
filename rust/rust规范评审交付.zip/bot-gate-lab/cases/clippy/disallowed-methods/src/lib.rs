#![allow(dead_code)]

pub unsafe fn prohibited_calls(
    destination: *mut libc::c_void,
    source: *const libc::c_void,
) {
    // SAFETY: this fixture intentionally exercises the configured policy.
    unsafe {
        libc::memcpy(destination, source, 1);
        let _ = libc::getenv(c"BOTGATE".as_ptr());
        let _ = libc::strcpy(destination.cast(), source.cast());
        let _ = libc::strtok(destination.cast(), source.cast());
    }
}

