pub fn condition() -> bool {
    if { true } {
        true
    } else {
        false
    }
}

