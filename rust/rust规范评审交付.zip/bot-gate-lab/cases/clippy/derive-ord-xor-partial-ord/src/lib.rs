use std::cmp::Ordering;

#[derive(PartialOrd, Eq, PartialEq)]
pub struct Value(u8);

impl Ord for Value {
    fn cmp(&self, other: &Self) -> Ordering {
        self.0.cmp(&other.0)
    }
}

