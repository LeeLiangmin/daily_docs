pub fn defaulted_number() -> String {
    let value = 1;
    value.to_string()
}

