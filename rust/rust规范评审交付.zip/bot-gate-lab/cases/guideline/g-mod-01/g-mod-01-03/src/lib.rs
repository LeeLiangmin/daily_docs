pub fn add(a: i32, b: i32) -> i32 { a + b }

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::*;

    #[test]
    fn t() {
        let mut m = HashMap::new();
        m.insert(1, add(1, 2));
        assert_eq!(m[&1], 3);
    }
}
