pub mod inner {
    pub fn helper() {}
    pub mod prelude {
        pub fn p() {}
    }
}

pub use inner::*;
use inner::prelude::*;

pub fn demo() {
    p();
}
