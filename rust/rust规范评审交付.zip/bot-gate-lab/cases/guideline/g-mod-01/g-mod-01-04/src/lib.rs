pub enum Color { Red, Green }
use Color::*;

pub fn is_red(c: &Color) -> bool {
    matches!(c, Red)
}
