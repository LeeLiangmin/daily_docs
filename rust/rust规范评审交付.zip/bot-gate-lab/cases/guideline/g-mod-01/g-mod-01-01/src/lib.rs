#![allow(unused)]
use std::sync::Arc;
use std::ptr::*;

pub fn demo() {
    let foo = Arc::new(vec![1.0, 2.0, 3.0]);
    let a = foo.clone();
    let mut rust = vec!['b', 'u', 's', 't'];
    let b = unsafe { replace(&mut rust[0], 'r') };
}
