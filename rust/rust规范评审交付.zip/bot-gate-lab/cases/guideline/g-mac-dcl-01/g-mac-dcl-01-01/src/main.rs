macro_rules! match_tokens {
    ($($other:tt)*) => {"got something else"};
    ($a:tt + $b:tt) => {"got an addition"};
    ($i:ident) => {"got an identifier"};
}

fn main() {
    println!("{},{},{}", match_tokens!(caravan), match_tokens!(3 + 6), match_tokens!(5));
}
