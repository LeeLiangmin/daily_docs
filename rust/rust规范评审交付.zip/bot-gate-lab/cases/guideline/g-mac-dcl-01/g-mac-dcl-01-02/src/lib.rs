macro_rules! m {
    ($e:expr) => {"expr"};
    ($($t:tt)*) => {"tokens"};
}

pub fn demo() -> &'static str {
    m!(1 +)
}
