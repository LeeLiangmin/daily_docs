pub struct Cfg {
    pub v: Option<i32>,
}

impl Cfg {
    pub fn get(&self) -> i32 {
        if self.v.is_some() { self.v.unwrap() } else { 0 }
    }
}
