pub fn demo(list: &[f32]) -> f32 {
    if !list.is_empty() {
        let first = list[0];
        return first;
    }
    0.0
}
