pub fn demo(opt: Option<i32>, list: &[f32], index: usize) -> f32 {
    let mut sum = 0.0;
    if let Some(value) = opt {
        sum += value as f32;
    }
    if let [first, ..] = list {
        sum += *first;
    }
    if let Some(val) = list.get(index) {
        sum += *val;
    }
    sum
}
