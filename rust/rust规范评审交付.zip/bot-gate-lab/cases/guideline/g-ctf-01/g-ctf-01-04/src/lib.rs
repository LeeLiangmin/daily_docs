#![allow(unused)]
pub fn demo() {
    let opt: Option<i32> = Some(2);
    if opt.is_some() {
        let value = opt.unwrap();
    }

    let list: &[f32] = vec![1.23];
    if !list.is_empty() {
        let first = list[0];
    }
}
