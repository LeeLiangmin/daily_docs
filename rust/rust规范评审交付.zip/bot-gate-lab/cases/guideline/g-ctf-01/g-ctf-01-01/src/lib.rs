pub fn demo(opt: Option<i32>) -> i32 {
    if opt.is_some() {
        let value = opt.unwrap();
        return value;
    }
    0
}
