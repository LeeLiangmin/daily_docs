#[must_use]
fn foo1() -> i32 { 0 }

#[must_use]
struct MyError(i32, i32);

fn foo2() -> MyError { MyError(0, 0) }

fn foo3() -> Result<(), String> { Ok(()) }

pub fn caller() {
    foo1();
    foo2();
    foo3();
}
