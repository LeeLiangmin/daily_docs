#[must_use]
fn foo1() -> i32 { 0 }

fn foo3() -> Result<(), String> { Ok(()) }

pub fn caller() {
    let _ = foo1();
    let _ = foo3();
}
