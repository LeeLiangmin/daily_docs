pub fn checksum(data: &[u8]) -> u32 {
    data.iter().map(|&b| u32::from(b)).sum()
}
