fn foo3() -> Result<(), String> { Ok(()) }

pub fn caller() {
    foo3().ok();
}
