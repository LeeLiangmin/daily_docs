#[must_use]
pub struct Token(u32);

fn issue() -> Option<Token> { Some(Token(1)) }

pub fn caller() {
    issue();
}
