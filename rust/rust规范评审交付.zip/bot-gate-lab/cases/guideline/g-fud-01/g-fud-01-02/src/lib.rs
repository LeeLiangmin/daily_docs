pub fn func(val: [i32; 1000]) -> i32 {
    val[0]
}
