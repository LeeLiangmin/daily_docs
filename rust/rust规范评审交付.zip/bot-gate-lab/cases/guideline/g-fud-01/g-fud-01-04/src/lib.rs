pub struct Big {
    pub buf: [u8; 4096],
    pub name: String,
}

#[allow(dead_code)]
fn inspect(b: Big) -> usize {
    b.buf.len() + b.name.len()
}
