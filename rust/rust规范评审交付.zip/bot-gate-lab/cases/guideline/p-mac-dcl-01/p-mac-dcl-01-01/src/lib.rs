macro_rules! impl_for {
    ($name:ty) => {
        impl<'a> $name {
            pub fn get(&self) -> i32 {
                *self.0
            }
        }
    };
}

pub struct Foo<'a>(&'a i32);
impl_for!(Foo<'a>);

pub struct Bar<'b>(&'b i32);
impl_for!(Bar<'b>);
