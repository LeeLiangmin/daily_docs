use helper_macro::helped;

pub fn unit() {
    helped!();
}
