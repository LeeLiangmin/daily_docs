#[macro_export]
macro_rules! helped {
    () => { helper!() };
}

#[macro_export]
macro_rules! helper {
    () => { () };
}
