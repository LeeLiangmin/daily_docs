#[macro_export]
macro_rules! answer {
    () => { ::helper_dep::value() };
}
