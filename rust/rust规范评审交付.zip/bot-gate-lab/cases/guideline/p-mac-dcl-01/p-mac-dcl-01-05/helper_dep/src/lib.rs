pub fn value() -> i32 { 42 }
