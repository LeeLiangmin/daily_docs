pub fn use_it() -> i32 {
    helper_macro::answer!()
}
