#[macro_export]
macro_rules! helped {
    () => { $crate::helper!() };
}

#[macro_export]
macro_rules! helper {
    () => { () };
}
