#[doc(hidden)]
pub use helper_dep as __dep;

#[macro_export]
macro_rules! answer {
    () => { $crate::__dep::value() };
}
