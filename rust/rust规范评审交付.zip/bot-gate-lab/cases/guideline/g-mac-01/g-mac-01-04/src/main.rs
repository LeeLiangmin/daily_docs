unsafe fn read_raw(p: *const i32) -> i32 {
    unsafe { *p }
}

fn main() {
    let v = 7;
    let p = &v as *const i32;
    // 调用方没有写 unsafe，却执行了 unsafe fn
    let got = rmacro::run_unchecked!(read_raw(p));
    println!("got={got}");
}
