use proc_macro::TokenStream;
use quote::quote;
use syn::{parse_macro_input, Expr};

#[proc_macro]
pub fn run_unchecked(input: TokenStream) -> TokenStream {
    let expr = parse_macro_input!(input as Expr);
    quote!({
        unsafe { #expr }
    })
    .into()
}
