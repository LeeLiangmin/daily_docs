macro_rules! checked_get {
    ($slice:expr, $idx:expr) => {{
        // 元变量先在 unsafe 块外求值，调用方传入的表达式仍受正常的安全检查
        let slice: &[_] = $slice;
        let idx: usize = $idx;
        if idx < slice.len() {
            // SAFETY: 上一行已确认 idx < slice.len()，下标在界内
            Some(unsafe { *slice.get_unchecked(idx) })
        } else {
            None
        }
    }};
}

fn main() {
    let v = [10, 20, 30];
    println!("{:?} {:?}", checked_get!(&v, 1), checked_get!(&v, 9));
}
