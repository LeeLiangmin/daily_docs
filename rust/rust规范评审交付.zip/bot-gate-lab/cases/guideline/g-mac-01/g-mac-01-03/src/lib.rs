unsafe fn dangerous_function() -> i32 {
    let ptr: *const i32 = std::ptr::null();
    *ptr
}

#[macro_export]
macro_rules! expose {
    ($name:ident) => {
        pub fn $name() -> i32 {
            unsafe { dangerous_function() }
        }
    };
}

expose!(looks_safe);
