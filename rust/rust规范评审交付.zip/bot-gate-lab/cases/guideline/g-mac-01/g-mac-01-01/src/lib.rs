macro_rules! make_safe {
    ($safe_name:ident, $unsafe_fn:expr) => {
        pub fn $safe_name() {
            unsafe {
                $unsafe_fn();
            }
        }
    };
}

unsafe fn dangerous_function() {
    let ptr: *const i32 = std::ptr::null();
    println!("value: {}", *ptr);
}

make_safe!(safe_function, dangerous_function);
