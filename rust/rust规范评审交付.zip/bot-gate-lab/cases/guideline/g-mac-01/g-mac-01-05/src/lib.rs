unsafe fn safe_function() {
    let ptr: *const i32 = std::ptr::null();
    if !ptr.is_null() {
        println!("value: {}", *ptr);
    }
}

pub fn call() {
    unsafe { safe_function() }
}
