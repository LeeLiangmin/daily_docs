pub fn demo() -> i32 {
    -1i32.abs()
}
