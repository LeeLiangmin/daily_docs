pub fn demo(a: bool, b: bool, c: bool) -> bool {
    a && b || c
}
