pub fn demo(x: u32) -> u32 {
    x & 0xF0 >> 4
}
