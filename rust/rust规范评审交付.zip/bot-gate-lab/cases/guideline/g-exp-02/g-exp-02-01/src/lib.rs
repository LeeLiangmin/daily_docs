pub fn demo() -> i32 {
    1 << 2 + 3
}
