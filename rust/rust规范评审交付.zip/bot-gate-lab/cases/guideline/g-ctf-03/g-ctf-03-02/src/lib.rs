pub fn serve() -> ! {
    loop {
        std::hint::black_box(0);
    }
}
