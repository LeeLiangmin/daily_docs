pub fn wait(ready: bool) {
    while !ready {
        std::hint::black_box(0);
    }
}
