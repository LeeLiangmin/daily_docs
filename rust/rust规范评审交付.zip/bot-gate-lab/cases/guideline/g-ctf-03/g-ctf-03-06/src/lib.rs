pub fn depth(n: u64) -> u64 {
    depth(n + 1)
}
