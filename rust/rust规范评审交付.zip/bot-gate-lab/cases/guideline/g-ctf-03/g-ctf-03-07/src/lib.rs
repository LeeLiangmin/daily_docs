pub fn depth(n: u64) -> u64 {
    if n == 0 { 0 } else { depth(n + 1) }
}
