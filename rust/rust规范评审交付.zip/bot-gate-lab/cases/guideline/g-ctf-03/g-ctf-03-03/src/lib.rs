pub fn run(limit: u32) {
    let mut counter = 0u32;
    loop {
        counter += 1;
        if counter > limit {
            panic!("overflow");
        }
    }
}
