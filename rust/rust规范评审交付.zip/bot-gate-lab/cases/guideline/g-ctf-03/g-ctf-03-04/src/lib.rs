pub fn start() -> impl std::future::Future<Output = ()> {
    async {
        loop {
            std::hint::black_box(0);
        }
    }
}
