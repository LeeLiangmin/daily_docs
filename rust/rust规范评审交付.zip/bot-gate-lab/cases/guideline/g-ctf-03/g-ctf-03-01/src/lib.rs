pub fn run() {
    let mut counter = 0u32;
    loop {
        counter = counter.wrapping_add(1);
        std::hint::black_box(counter);
    }
}
