use proc_macro::TokenStream;
use proc_macro2::Span;
use quote::quote_spanned;

#[proc_macro]
pub fn my_macro(_input: TokenStream) -> TokenStream {
    quote_spanned! {Span::mixed_site()=>
        let local = "hello";
        let _ = local;
    }
    .into()
}
