fn main() {
    let local = "";
    guide::my_macro!();
    println!("local={local:?}");
}
