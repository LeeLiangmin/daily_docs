fn main() {
    #[allow(unused_assignments)]
    let mut x = 0;
    let local = "";
    guide::my_macro!();
    println!("x={x} local={local:?}");
}
