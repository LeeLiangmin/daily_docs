use proc_macro::TokenStream;
use quote::quote;

#[proc_macro]
pub fn my_macro(_input: TokenStream) -> TokenStream {
    quote! {
        x = 999;
        let local = "hello";
    }
    .into()
}
