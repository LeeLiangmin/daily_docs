use std::cell::Cell;

fn main() {
    let i: Cell<i32> = Cell::new(0);
    let opt = Some(1);
    match opt {
        Some(1) | Some(_) if condition(&i) => {}
        _ => {}
    }
    assert_eq!(i.get(), 2);
    println!("final={}", i.get());
}

fn condition(i: &Cell<i32>) -> bool {
    println!("add 1");
    i.set(i.get() + 1);
    false
}
