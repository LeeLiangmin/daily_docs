pub fn demo(x: u32) -> u32 {
    let mut n = 0;
    if x % 2 == 2 { n += 1; }
    if x != 1 || x != 2 { n += 1; }
    n
}
