const TRACE_MASK: u32 = 0; // 由构建配置生成，某些配置下为 0

pub fn traced(flags: u32) -> bool {
    flags & TRACE_MASK != 0
}
