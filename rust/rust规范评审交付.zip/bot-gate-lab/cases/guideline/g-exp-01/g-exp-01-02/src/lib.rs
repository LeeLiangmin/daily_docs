#![allow(unused_comparisons)]
pub fn demo(x: u32) -> u32 {
    let mut n = 0;
    if x > 10 && x < 5 { n += 1; }
    if x >= 0 { n += 1; }
    if x == x { n += 1; }
    n
}
