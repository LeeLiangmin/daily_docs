pub fn first_char(s: &str) -> char {
    if s.is_empty() {
        return ' ';
    }
    s.chars().next().unwrap()
}
