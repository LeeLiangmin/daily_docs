pub fn add(a: i32, b: i32) -> i32 { a + b }

#[cfg(test)]
mod tests {
    #[test]
    fn t() {
        let v: Result<i32, ()> = Ok(super::add(1, 2));
        assert_eq!(v.unwrap(), 3);
    }
}
