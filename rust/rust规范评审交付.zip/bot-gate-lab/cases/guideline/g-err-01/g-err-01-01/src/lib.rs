pub fn port(s: &str) -> u16 {
    s.parse().unwrap()
}
