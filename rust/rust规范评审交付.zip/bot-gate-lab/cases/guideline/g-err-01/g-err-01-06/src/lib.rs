use std::fs;
use std::io::ErrorKind;

const CONFIG_PATH: &str = "/etc/app/config.toml";

pub fn load_config() -> Option<String> {
    match fs::read_to_string(CONFIG_PATH) {
        Ok(content) => Some(content),
        Err(e) => {
            match e.kind() {
                ErrorKind::NotFound => { /* 处理文件找不到的情况 */ }
                ErrorKind::PermissionDenied => { /* 处理文件权限不够的情况 */ }
                _ => { /* 处理其它错误情况 */ }
            }
            None
        }
    }
}
