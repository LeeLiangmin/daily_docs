pub fn port(s: &str) -> u16 {
    s.parse().unwrap_or_else(|e| panic!("bad port: {e}"))
}
