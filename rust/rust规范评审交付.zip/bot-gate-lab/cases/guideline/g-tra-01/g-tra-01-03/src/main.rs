use std::cmp::Ordering;

#[derive(PartialEq, Eq)]
struct Employee {
    uid: u32,
    name: String,
}

impl PartialOrd for Employee {
    fn partial_cmp(&self, other: &Employee) -> Option<Ordering> {
        Some(self.uid.cmp(&other.uid))
    }
}

impl Ord for Employee {
    fn cmp(&self, other: &Self) -> Ordering {
        self.uid.cmp(&other.uid)
    }
}

fn main() {
    let a = Employee { uid: 1, name: "a".into() };
    let b = Employee { uid: 1, name: "b".into() };
    println!("eq={} cmp={:?}", a == b, a.cmp(&b));
    let mut set = std::collections::BTreeSet::new();
    set.insert(a);
    set.insert(b);
    println!("btreeset_len={}", set.len());
}
