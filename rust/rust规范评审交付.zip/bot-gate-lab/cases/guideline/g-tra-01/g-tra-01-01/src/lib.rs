#[derive(Hash, Eq)]
pub struct Employee {
    uid: u32,
    name: String,
}

impl PartialEq for Employee {
    fn eq(&self, other: &Self) -> bool {
        self.uid == other.uid
    }
}
