use std::cmp::Ordering;

#[derive(Eq)]
struct Employee {
    uid: u32,
    name: String,
}

impl PartialEq for Employee {
    fn eq(&self, other: &Self) -> bool {
        self.uid == other.uid
    }
}

impl PartialOrd for Employee {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Employee {
    fn cmp(&self, other: &Self) -> Ordering {
        self.uid.cmp(&other.uid)
    }
}

fn main() {
    let a = Employee { uid: 1, name: "a".into() };
    let b = Employee { uid: 1, name: "b".into() };
    println!("eq={} cmp={:?} names={}{}", a == b, a.cmp(&b), a.name, b.name);
}
