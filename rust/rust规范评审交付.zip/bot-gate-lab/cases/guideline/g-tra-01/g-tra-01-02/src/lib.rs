use std::cmp::Ordering;

#[derive(Ord, PartialEq, Eq)]
pub struct Employee {
    uid: u32,
    name: String,
}

impl PartialOrd for Employee {
    fn partial_cmp(&self, other: &Employee) -> Option<Ordering> {
        Some(self.uid.cmp(&other.uid))
    }
}
