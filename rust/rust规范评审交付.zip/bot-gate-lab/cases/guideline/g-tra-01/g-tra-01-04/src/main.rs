use std::hash::{DefaultHasher, Hash, Hasher};

#[derive(Eq)]
struct Employee {
    uid: u32,
    name: String,
}

impl PartialEq for Employee {
    fn eq(&self, other: &Self) -> bool {
        self.uid == other.uid
    }
}

impl Hash for Employee {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.uid.hash(state);
        self.name.hash(state);
    }
}

fn h(e: &Employee) -> u64 {
    let mut s = DefaultHasher::new();
    e.hash(&mut s);
    s.finish()
}

fn main() {
    let a = Employee { uid: 1, name: "a".into() };
    let b = Employee { uid: 1, name: "b".into() };
    println!("eq={} same_hash={}", a == b, h(&a) == h(&b));
}
