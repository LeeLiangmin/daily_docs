pub struct Wrapper<T>(pub Vec<T>);

impl<T> Into<Wrapper<T>> for Vec<T> {
    fn into(self) -> Wrapper<T> {
        Wrapper(self)
    }
}
