#![allow(dead_code)]

pub struct NotFfiSafe {
    pub value: String,
}

#[no_mangle]
pub extern "C" fn returns_not_ffi_safe() -> NotFfiSafe {
    NotFfiSafe { value: String::new() }
}

