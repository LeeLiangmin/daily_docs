#![allow(dead_code)]

extern {
    fn accepts_pointer(value: *const u8);
}

