#![allow(dead_code)]

#[repr(C)]
pub struct NotFfiSafe {
    pub value: String,
}

extern "C" {
    fn accepts_not_ffi_safe(value: NotFfiSafe);
}

