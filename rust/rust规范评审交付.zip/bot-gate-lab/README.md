<div align="center" markdown="1">

**面向 Rust lint 的可复现 PoC 集成测试：用最小 fixture 验证诊断是否真实产生。**

➡️ [这是什么](#what) | [快速开始](#start) | [覆盖范围](#map) | [检测方式](#usage) | [目录与文档](#docs) ⬅️

![Rust](https://img.shields.io/badge/Rust-1.89%2B-orange)
![Lint PoCs](https://img.shields.io/badge/PoCs-14-blue)
![Diagnostics](https://img.shields.io/badge/diagnostics-Cargo%20JSON-brightgreen)
![License](https://img.shields.io/badge/license-Apache--2.0-lightgrey)

</div>

---

<a id="what"></a>

## 🤔 这是什么

bot-gate-lab 是一个 Rust 编译器与 Clippy lint 的 PoC 集成测试仓库。每个 lint 都有独立的最小 fixture、case 元数据和预期诊断；测试运行真实的 cargo check 或 cargo clippy，再从 Cargo JSON compiler-message 中确认目标 lint 是否命中。

当前样例以 BotGate fast 检查的基础 lint 为基线，覆盖 rustc check lint、Fast Minimal Clippy lint，以及由 .botgate/managed/clippy/.../clippy.toml 驱动的 clippy::disallowed_methods，另补充了不在参考 Minimal 集合内的 clippy::approx_constant。

这个仓库验证的是“指定工具链下，指定代码是否产生指定诊断”。一个 PoC 命中不代表对应自然语言规则已经得到完整覆盖；wrapper、别名、函数指针、间接调用和其他未写入 fixture 的场景需要单独增加 case。

每次运行交付两类结果：

| 结果 | 作用 |
| --- | --- |
| Case 判定 | 精确确认 lint code、诊断级别、fixture 来源和命中数量。 |
| 原始证据 | 将每个 case 的 Cargo JSON 输出保存到 artifacts/fast/，便于复查工具链行为。 |

---

<a id="start"></a>

## 🚀 快速开始

需要 Rust、Cargo、Clippy 和 Python 3：

~~~bash
rustc --version
cargo --version
cargo clippy --version
python3 --version
~~~

在仓库根目录运行全部 Fast 基础 lint PoC：

~~~bash
./scripts/validate-fast.sh
~~~

预期输出为 14 个 PASS。结果文件位于：

~~~text
artifacts/fast/
~~~

运行 harness 自身的 Cargo 测试：

~~~bash
cargo test --workspace
~~~

检查格式：

~~~bash
cargo fmt --all -- --check
~~~

---

<a id="map"></a>

## 🗺️ 覆盖范围

### rustc check

| lint | PoC |
| --- | --- |
| missing_abi | cases/rustc/missing-abi |
| improper_ctypes | cases/rustc/improper-ctypes |
| improper_ctypes_definitions | cases/rustc/improper-ctypes-definitions |

### Fast Minimal Clippy

| lint | PoC |
| --- | --- |
| clippy::borrow_interior_mutable_const | cases/clippy/borrow-interior-mutable-const |
| clippy::declare_interior_mutable_const | cases/clippy/declare-interior-mutable-const |
| clippy::derived_hash_with_manual_eq | cases/clippy/derived-hash-with-manual-eq |
| clippy::derive_ord_xor_partial_ord | cases/clippy/derive-ord-xor-partial-ord |
| clippy::blocks_in_conditions | cases/clippy/blocks-in-conditions |
| clippy::recursive_format_impl | cases/clippy/recursive-format-impl |
| clippy::default_numeric_fallback | cases/clippy/default-numeric-fallback |
| clippy::repr_packed_without_abi | cases/clippy/repr-packed-without-abi |
| clippy::macro_metavars_in_unsafe | cases/clippy/macro-metavars-in-unsafe |
| clippy::disallowed_methods | cases/clippy/disallowed-methods |
| clippy::approx_constant | cases/clippy/approx-constant |

disallowed_methods case 使用参考 BotGate managed Clippy 配置中的代表性 C 函数：memcpy、getenv、strcpy 和 strtok。它验证的是配置名单对直接调用的拦截，不是对所有间接调用的通用安全证明。

approx_constant case 按 Fast clippy 组维护，但不在参考实现的 Minimal 集合内，属于本仓库的补充覆盖。fixture 中只有 `let x = 3.14_f64;` 这一行命中；同一 fixture 中的 `let y = 1_f64 / x;` 因为 x 是变量而非字面量，实测不触发该 lint。

---

<a id="usage"></a>

## 🧭 检测方式

validate-fast.sh 根据 case 类型运行：

~~~text
rustc case   cargo check --all-targets --message-format=json
Clippy case  cargo clippy --all-targets --message-format=json -- -W <lint>
~~~

assert-diagnostics.py 解析结构化 compiler-message，校验：

- lint code 与 case 声明完全一致；
- 诊断级别为 warning；
- 主 span 或宏展开来源回到当前 fixture；
- 命中数量符合 case 期望。

BotGate Fast 的策略是“warning 诊断阻断检查步骤”，所以 PoC 不把所有 lint 强制改成 -D，也不只看 Cargo 进程退出码。Cargo 可以成功退出，但只要目标 warning 出现在结构化诊断中，Fast step 就应判定为失败。

每个 case 目录包含：

~~~text
case.toml       # lint、工具、稳定性和预期诊断
Cargo.toml      # 独立 Cargo package
src/lib.rs      # 最小故意违规 fixture
clippy.toml     # 仅在 case 需要独有配置时提供
~~~

根 workspace 只包含 harness，故意产生诊断的 case 不会被 cargo test --workspace 意外编译。

---

<a id="docs"></a>

## 📚 目录与文档

| 路径 | 内容 |
| --- | --- |
| cases/ | 按 rustc / Clippy 分类的独立 lint PoC。 |
| scripts/validate-fast.sh | Fast 基础 lint 全量验证入口。 |
| scripts/assert-diagnostics.py | Cargo JSON 诊断断言器。 |
| docs/fast-lints.md | BotGate Fast lint 清单、来源和覆盖边界。 |
| docs/lint-poc-architecture.md | PoC、case 契约、runner 和 CI 架构设计。 |

新增 lint 时，创建一个独立 case，写入真实 lint ID 和预期命中数量，再把验证命令加入 scripts/validate-fast.sh。不要用整段日志文本或仅凭退出码作为通过条件。

## ⚖️ 许可证

本项目使用 Apache License 2.0，详见 LICENSE。


---

<a id="guideline"></a>

## 📋 规范评审 PoC（cases/guideline）

为内部 Rust 编码规范评审新增的 64 个 case，按条款分目录（如 `cases/guideline/g-tra-01/`）。与 Fast case 不同，这组 case 需要证明「不报」和「行为」，因此 `case.toml` 额外支持：

| 字段 | 作用 |
| --- | --- |
| `[[expect]] count = 0` | 断言某 lint 不命中（漏报证据）；`code = "*"` 表示全部 lint |
| `[build] success = false` | 断言编译失败，可校验错误码或错误信息 |
| `[run]` | 编译通过后 `cargo run`，校验标准输出 |
| `version_note` | 记录 1.89 与实跑工具链的行为差异（源码比对结论） |

~~~bash
python3 scripts/validate-guideline.py            # 全部运行，结果写入 artifacts/guideline/results.json
python3 scripts/validate-guideline.py g-mac-01   # 按路径过滤
python3 scripts/render-guideline-poc-list.py     # 生成 docs/guideline-poc-list.md
~~~

每个 case 使用独立的 `CARGO_TARGET_DIR`，避免同名 path 依赖（如 `helper_macro`）在共享目录中互相覆盖。
