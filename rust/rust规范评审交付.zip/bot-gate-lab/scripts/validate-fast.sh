#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "$0")/.." && pwd)"
work="$root/artifacts/fast"
mkdir -p "$work"

check_case() {
    kind="$1"
    name="$2"
    lint="$3"
    fixture="$4"
    count="${5:-1}"
    manifest="$root/cases/$kind/$name/Cargo.toml"
    output="$work/$kind-$name.jsonl"
    if [[ "$kind" == "rustc" ]]; then
        command=(cargo check --manifest-path "$manifest" --all-targets --message-format=json)
    else
        command=(cargo clippy --manifest-path "$manifest" --all-targets --message-format=json -- -W "$lint")
    fi
    if "${command[@]}" >"$output" 2>&1; then
        :
    elif ! grep -q '"reason":"compiler-message"' "$output"; then
        printf 'FAIL %s: command failed without compiler diagnostics\n' "$lint"
        return 1
    fi
    python3 "$root/scripts/assert-diagnostics.py" "$output" "$lint" "$fixture" "$count"
}

failed=0

check_case rustc missing-abi missing_abi lib.rs || failed=$((failed + 1))
check_case rustc improper-ctypes improper_ctypes lib.rs || failed=$((failed + 1))
check_case rustc improper-ctypes-definitions improper_ctypes_definitions lib.rs || failed=$((failed + 1))
check_case clippy borrow-interior-mutable-const clippy::borrow_interior_mutable_const lib.rs || failed=$((failed + 1))
check_case clippy declare-interior-mutable-const clippy::declare_interior_mutable_const lib.rs || failed=$((failed + 1))
check_case clippy derived-hash-with-manual-eq clippy::derived_hash_with_manual_eq lib.rs || failed=$((failed + 1))
check_case clippy derive-ord-xor-partial-ord clippy::derive_ord_xor_partial_ord lib.rs || failed=$((failed + 1))
check_case clippy blocks-in-conditions clippy::blocks_in_conditions lib.rs || failed=$((failed + 1))
check_case clippy recursive-format-impl clippy::recursive_format_impl lib.rs || failed=$((failed + 1))
check_case clippy default-numeric-fallback clippy::default_numeric_fallback lib.rs || failed=$((failed + 1))
check_case clippy repr-packed-without-abi clippy::repr_packed_without_abi lib.rs || failed=$((failed + 1))
check_case clippy macro-metavars-in-unsafe clippy::macro_metavars_in_unsafe lib.rs || failed=$((failed + 1))
check_case clippy disallowed-methods clippy::disallowed_methods lib.rs 4 || failed=$((failed + 1))
check_case clippy approx-constant clippy::approx_constant lib.rs || failed=$((failed + 1))

printf '\n'
if ((failed > 0)); then
    printf 'FAILED: %d case(s)\n' "$failed"
    exit 1
fi
printf 'OK: all cases passed\n'

