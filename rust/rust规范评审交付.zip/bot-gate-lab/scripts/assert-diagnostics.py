#!/usr/bin/env python3
"""Assert one target lint in Cargo JSON compiler-message records."""

import json
import pathlib
import sys


def main():
    if len(sys.argv) != 5:
        print("usage: assert-diagnostics.py OUTPUT LINT FIXTURE COUNT", file=sys.stderr)
        return 2
    output_path = pathlib.Path(sys.argv[1])
    expected_code = sys.argv[2]
    fixture = pathlib.Path(sys.argv[3])
    expected_count = int(sys.argv[4])
    levels = []
    seen = set()
    for line in output_path.read_text(errors="replace").splitlines():
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if record.get("reason") != "compiler-message":
            continue
        message = record.get("message", {})
        code = (message.get("code") or {}).get("code")
        if code != str(expected_code):
            continue
        primary = next(
            (span for span in message.get("spans", []) if span.get("is_primary")),
            None,
        )
        source_files = []
        if primary is not None:
            source_files.append(primary.get("file_name", ""))
            expansion = primary.get("expansion") or {}
            source_files.append((expansion.get("span") or {}).get("file_name", ""))
        if primary is None:
            print(f"FAIL {expected_code}: missing primary span", file=sys.stderr)
            return 1
        if not any(pathlib.Path(path).name == fixture.name for path in source_files):
            print(f"FAIL {expected_code}: unexpected primary span", file=sys.stderr)
            return 1
        key = (
            expected_code,
            message.get("level"),
            message.get("message"),
            primary.get("file_name"),
            primary.get("line_start"),
            primary.get("column_start"),
        )
        if key not in seen:
            seen.add(key)
            levels.append(message.get("level"))
    if len(levels) != expected_count:
        print(
            f"FAIL {expected_code}: expected {expected_count} diagnostics, got {len(levels)}",
            file=sys.stderr,
        )
        return 1
    if levels[0] != "warning":
        print(f"FAIL {expected_code}: expected warning, got {levels[0]}", file=sys.stderr)
        return 1
    print(f"PASS {expected_code} ({fixture})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

