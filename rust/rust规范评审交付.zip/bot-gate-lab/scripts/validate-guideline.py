#!/usr/bin/env python3
"""Run guideline-review PoCs under cases/guideline and assert their contracts.

Each case directory holds a case.toml. Supported contract sections:

  [[expect]]   code = "<lint id>" | "*", count = N   (N may be 0)
               "*" counts every lint diagnostic in the fixture except `ignore`.
  [build]      success = true|false, error_codes = [...], message_contains = [...]
  [run]        stdout_contains = [...], stdout_count = [["text", N], ...]

Diagnostics come from `cargo clippy --all-targets --message-format=json -- <args>`;
only diagnostics whose primary span (or macro call site) lies in one of the
case's `fixtures` are counted. Results are written to
artifacts/guideline/results.json for report generation.
"""

import json
import os
import pathlib
import subprocess
import sys
import tomllib

ROOT = pathlib.Path(__file__).resolve().parent.parent
CASES = ROOT / "cases" / "guideline"
ART = ROOT / "artifacts" / "guideline"


def toolchain():
    out = {}
    for key, cmd in (("rustc", ["rustc", "-V"]), ("clippy", ["cargo", "clippy", "-V"])):
        out[key] = subprocess.run(cmd, capture_output=True, text=True).stdout.strip()
    return out


def span_files(span):
    files = [span.get("file_name", "")]
    exp = span.get("expansion")
    while exp:
        files.append((exp.get("span") or {}).get("file_name", ""))
        exp = (exp.get("span") or {}).get("expansion")
    return files


def collect(lines, case_dir, fixtures):
    """Return (diagnostics, errors) for messages rooted in the case fixtures."""
    fixture_paths = {(case_dir / f).resolve() for f in fixtures}
    diags, errors, seen = [], [], set()
    for line in lines:
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if rec.get("reason") != "compiler-message":
            continue
        msg = rec["message"]
        primary = next((s for s in msg.get("spans", []) if s.get("is_primary")), None)
        code = (msg.get("code") or {}).get("code")
        if msg.get("level") == "error":
            errors.append({"code": code, "message": msg.get("message", "")})
        if primary is None or code is None:
            continue
        pkg_root = pathlib.Path(rec.get("manifest_path", "")).parent
        hit = any((pkg_root / f).resolve() in fixture_paths for f in span_files(primary) if f)
        if not hit:
            continue
        key = (code, msg.get("level"), primary.get("file_name"), primary.get("line_start"),
               primary.get("column_start"), msg.get("message"))
        if key in seen:
            continue
        seen.add(key)
        diags.append({"code": code, "level": msg.get("level"),
                      "file": primary.get("file_name"), "line": primary.get("line_start"),
                      "message": msg.get("message")})
    return diags, errors


def run_case(case_dir, env):
    spec = tomllib.loads((case_dir / "case.toml").read_text())
    fixtures = spec.get("fixtures", ["src/lib.rs", "src/main.rs"])
    manifest = case_dir / "Cargo.toml"
    args = spec.get("args", [])
    cmd = ["cargo", "clippy", "--manifest-path", str(manifest), "--all-targets",
           "--message-format=json", "--", *args]
    env = dict(env, CARGO_TARGET_DIR=str(ART / "target" / spec["id"]))
    proc = subprocess.run(cmd, capture_output=True, text=True, env=env, cwd=case_dir)
    raw = proc.stdout.splitlines()
    log = ART / "logs" / f"{spec['id']}.jsonl"
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(proc.stdout + "\n--- stderr ---\n" + proc.stderr)
    diags, errors = collect(raw, case_dir, fixtures)
    build_ok = proc.returncode == 0 and not errors

    problems, observed = [], []
    ignore = set(spec.get("ignore", []))
    for exp in spec.get("expect", []):
        code = exp["code"]
        if code == "*":
            got = [d for d in diags if d["code"] not in ignore and not d["code"].startswith("E")]
        else:
            got = [d for d in diags if d["code"] == code]
        observed.append({"code": code, "expected": exp["count"], "actual": len(got),
                         "lines": sorted({d["line"] for d in got})})
        if len(got) != exp["count"]:
            problems.append(f"{code}: expected {exp['count']}, got {len(got)} "
                            f"{[(d['code'], d['line']) for d in got]}")

    build = spec.get("build", {"success": True})
    if build.get("success", True) != build_ok:
        problems.append(f"build success expected {build.get('success', True)}, got {build_ok}: "
                        f"{[e['message'] for e in errors][:3]}")
    for ec in build.get("error_codes", []):
        if not any(e["code"] == ec for e in errors):
            problems.append(f"missing error code {ec}")
    for text in build.get("message_contains", []):
        if not any(text in e["message"] for e in errors):
            problems.append(f"missing error message containing {text!r}")

    run_out = None
    if "run" in spec and build_ok:
        rp = subprocess.run(["cargo", "run", "-q", "--manifest-path", str(manifest)],
                            capture_output=True, text=True, env=env, cwd=case_dir)
        run_out = rp.stdout
        if rp.returncode != 0:
            problems.append(f"run failed ({rp.returncode}): {rp.stderr.strip()[-300:]}")
        for text in spec["run"].get("stdout_contains", []):
            if text not in rp.stdout:
                problems.append(f"stdout missing {text!r}")
        for text, n in spec["run"].get("stdout_count", []):
            if rp.stdout.count(text) != n:
                problems.append(f"stdout count of {text!r}: expected {n}, got {rp.stdout.count(text)}")

    return {
        "id": spec["id"], "rule": spec["rule"], "category": spec["category"],
        "title": spec["title"], "conclusion": spec.get("conclusion", ""),
        "version_note": spec.get("version_note", ""), "path": str(case_dir.relative_to(ROOT)),
        "args": args, "observed": observed, "build_ok": build_ok,
        "errors": [e for e in errors][:5], "stdout": run_out,
        "status": "PASS" if not problems else "FAIL", "problems": problems,
    }


def main():
    selected = sys.argv[1:]
    env = dict(os.environ)
    env["CARGO_TERM_COLOR"] = "never"
    cases = sorted(p.parent for p in CASES.rglob("case.toml"))
    if selected:
        cases = [c for c in cases if any(s in str(c) for s in selected)]
    results, failed = [], 0
    for case_dir in cases:
        res = run_case(case_dir, env)
        results.append(res)
        obs = ", ".join(f"{o['code']}={o['actual']}" for o in res["observed"])
        print(f"{res['status']} {res['id']:<28} {res['category']:<9} build={'ok' if res['build_ok'] else 'fail'} {obs}")
        for p in res["problems"]:
            print(f"     - {p}")
        failed += res["status"] != "PASS"
    ART.mkdir(parents=True, exist_ok=True)
    if not selected:
        (ART / "results.json").write_text(json.dumps(
            {"toolchain": toolchain(), "cases": results}, ensure_ascii=False, indent=2))
    print(f"\n{len(results) - failed}/{len(results)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
