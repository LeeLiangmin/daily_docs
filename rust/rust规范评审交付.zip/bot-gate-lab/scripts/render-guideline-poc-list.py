#!/usr/bin/env python3
"""Render artifacts/guideline/results.json into docs/guideline-poc-list.md."""

import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
RULE_ORDER = ["G.CTF.01", "G.CTF.02", "G.CTF.03", "G.EXP.01", "G.EXP.02", "G.FUD.01", "G.FUD.02",
              "G.TRA.01", "G.TRA.02", "G.ERR.01", "G.MOD.01", "G.MAC.01", "P.MAC.DCL.01",
              "G.MAC.DCL.01", "P.MAC.PRO.01"]


def cell(text):
    return str(text).replace("|", "\\|").replace("\n", " ")


def main():
    data = json.loads((ROOT / "artifacts/guideline/results.json").read_text())
    cases = data["cases"]
    tc = data["toolchain"]
    passed = sum(c["status"] == "PASS" for c in cases)
    out = [
        "# 规范评审 POC 清单",
        "",
        f"- 实跑工具链：`{tc['rustc']}`，`{tc['clippy']}`",
        "- lint 存在性与分组基线：rustc / Clippy **1.89.0** 源码（rust-lang/rust@1.89.0、rust-clippy@rust-1.89.0）",
        f"- 结果：{passed}/{len(cases)} PASS（PASS 表示实测结果与 case.toml 中声明的预期完全一致，预期本身可以是 0 次命中或编译失败）",
        "- 运行：`python3 scripts/validate-guideline.py [过滤串]`，原始 Cargo JSON 在 `artifacts/guideline/logs/`",
        "",
        "类别说明：**命中**＝lint 能检出；**漏报**＝条款要求覆盖但 lint 不报；**误报 / 误报风险**＝条款允许或意图正常但 lint 报警；"
        "**边界**＝lint 的豁免与条款一致；**语义验证**＝验证条款描述的运行时行为；**示例校验**＝验证原文或修订稿示例能否编译、行为是否正确；"
        "**版本差异**＝1.89 与实跑版本行为不同，结论来自源码比对。",
        "",
        "「*」表示在 `clippy::all + pedantic + nursery` 下该 fixture 的全部 lint 告警数（已排除与本条无关的噪声 lint）。",
        "",
    ]
    for rule in RULE_ORDER:
        group = [c for c in cases if c["rule"] == rule]
        if not group:
            continue
        out += [f"## {rule}", "", "| ID | 类别 | 场景 | 预期 → 实测 | 结论 | 状态 |", "| --- | --- | --- | --- | --- | --- |"]
        for c in group:
            obs = []
            for o in c["observed"]:
                obs.append(f"`{o['code']}` {o['expected']}→{o['actual']}")
            if c["errors"]:
                obs.append("编译失败：" + cell(c["errors"][0]["message"]))
            elif not c["observed"]:
                obs.append("编译通过")
            if c["stdout"]:
                obs.append("输出：`" + cell(c["stdout"].strip().replace("\n", " / ")) + "`")
            concl = c["conclusion"]
            if c["version_note"]:
                concl += "<br>**版本说明**：" + c["version_note"]
            title = f"{cell(c['title'])}<br>`{c['path']}`"
            out.append(f"| {c['id']} | {c['category']} | {title} | {'<br>'.join(obs)} | {cell(concl)} | {c['status']} |")
        out.append("")
    (ROOT / "docs/guideline-poc-list.md").write_text("\n".join(out))
    print("wrote docs/guideline-poc-list.md")


if __name__ == "__main__":
    main()
