# Rust lint PoC 集成测试仓库架构

## 目标与边界

本仓库用于回答一个可重复验证的问题：在指定的 rustc/Clippy 版本和配置下，一段最小 Rust 程序是否会触发指定 lint，诊断是否符合约定。每个 lint 都有独立 PoC、检测声明和自动断言；失败时保留可读的编译器输出。

仓库是 lint 行为的验证集，不是 lint 实现本身，也不宣称一个触发样例就证明了某条自然语言规则的完整覆盖。每个 case 应标明它验证的是内建 lint、配置驱动 lint、自研检测器，还是仅验证某条规则的一部分。

## 设计原则

1. **一个 case 对应一个被验证的 lint ID。** 多个 lint 即使共享一个 Rust API，也不能共用无法区分预期结果的 case。
2. **PoC 与检测契约放在一起。** 读者从一个目录就能知道为何触发、如何检测、预期得到什么。
3. **fixture 是刻意不合规的源码。** 它不进入正常 workspace 的默认构建，不能要求整个 fixture 仓库无警告或全量编译通过。
4. **依据结构化诊断断言。** 至少校验 lint ID、级别和主诊断来源；不以进程退出码或日志子串单独作为通过条件。
5. **覆盖结论有边界。** 触发成功只证明该样例命中了该诊断，不证明别名、封装、宏展开等未测试场景也受到保护。
6. **环境与版本显式。** toolchain、组件、目标平台和配置都可追踪；不稳定 lint 要声明 nightly 要求。

## 目录布局

~~~text
bot-gate-lab/
├── Cargo.toml                    # 仅包含 harness，不把故意失败的 case 加入 workspace
├── Cargo.lock
├── rust-toolchain.toml           # 仓库默认验证工具链；CI 可覆盖矩阵
├── clippy.toml                   # 仅放有意共享的 Clippy 配置
├── cases/
│   ├── rustc/
│   │   └── improper-ctypes/
│   │       ├── case.toml
│   │       ├── Cargo.toml
│   │       ├── src/lib.rs
│   │       └── README.md          # 可选：规则背景、已知限制
│   └── clippy/
│       └── macro-metavars-in-unsafe/
│           ├── case.toml
│           ├── Cargo.toml
│           ├── src/main.rs
│           ├── clippy.toml        # 可选：此 case 独有配置
│           └── pass/              # 可选：相邻的非触发对照样例
├── harness/
│   └── lint-poc-runner/           # 发现 case、执行命令、解析 JSON、汇总结果
├── scripts/
│   ├── test-all.sh                # 人类友好的薄封装
│   └── list-cases.sh              # 可选：按 toolchain / lint 查询
├── docs/
│   ├── lint-poc-architecture.md
│   └── adding-a-case.md
└── artifacts/                     # 本地或 CI 输出，不提交原始临时日志
~~~

case 使用稳定 lint 名称作为目录名，按来源分入 rustc/ 或 clippy/。只有当两个 case 的检测来源或运行条件实质不同时，才在 lint 名后增加短场景名，例如 disallowed-methods/direct-call。已有的 G.SAF.FFI.01 等 BotGate 规则编号作为元数据保留，不替代 rustc/Clippy lint ID。

每个 case 是独立 Cargo package。这样单个 case 可以使用自己的 crate 属性、依赖和配置；有意失败或产生预期诊断的源码不会污染 harness，也不会被 cargo test --workspace 意外编译。根 Cargo.toml 的 workspace 明确只列 harness，并排除 cases/。

## Case 契约

case.toml 是 runner 的唯一发现和期望来源。字段先保持精简，避免另建一份 lint 清单：

~~~toml
id = "clippy::macro_metavars_in_unsafe"
rule = "G.MAC.01"
tool = "clippy"
stability = "stable"
fixture = "src/main.rs"
crate_type = "bin"
lint_level = "deny"
required_config = ["warn-unsafe-macro-metavars-in-private-macros = true"]

[[expect]]
code = "clippy::macro_metavars_in_unsafe"
level = "error"
count = 1
primary_file = "src/main.rs"
~~~

实际字段名由 runner schema 决定；上述内容说明信息边界，不要求一次性实现所有可选字段。推荐字段包括：

- id：本 case 主验证的完整 lint ID。
- rule：关联的产品/安全规则编号，可选。
- tool：rustc 或 clippy，决定执行入口和诊断来源。
- stability：stable、nightly 或显式版本范围。
- fixture、crate_type：输入源码和编译目标。
- required_config：生效所必需的 lint level、Clippy 配置或 feature 提示；配置正文放在 package 内的 TOML 文件。
- expect：结构化诊断期望，可声明代码、级别、数量和主 span 文件；默认必须至少命中一次目标 lint。
- status / known_limits：描述规则支持状态与覆盖限制，可选。

每个 case 只对目标 lint 的诊断作强断言。其他伴随 warning 可以记录，但不能让不相关 warning 掩盖目标 lint 未触发。若一个 PoC 同时验证多个 lint，应拆成多个 case，或者明确声明多个独立 expectation，并让报告分别计数。

## 检测与失败语义

Runner 先从 case 元数据和 package 配置生成命令，再执行 case 子进程并收集 stdout、stderr 和 Cargo JSON 消息。rustc case 使用 rustc JSON diagnostics；Clippy case 使用 cargo clippy --message-format=json。实现应解析 Cargo 的 compiler-message 及其嵌套诊断，而不是在整段输出里 grep "code"。

每条目标诊断至少校验：

- code 与 case 声明的 lint ID 完全相等；
- level 与期望级别相等；
- 主 span 指向该 case 的 fixture；
- 命中数符合 count，且默认至少为 1。

对于“必须报错”的 case，运行器对目标 lint 显式传入 deny 等级（例如 -D clippy::some_lint 或 -D some_rustc_lint），并同时断言结构化诊断仍保留原 lint ID。运行器据此区分“检测命中并按预期拒绝”和“编译意外失败”：只有目标诊断满足契约才算 PASS。若某个 lint 预期只是 warning，则使用 warning 契约；不要为了让命令返回非零而把所有 warning 一概升级。

JSON 断言避免依赖人类可读消息全文、绝对路径、临时目录、ANSI 颜色或整份 stderr 快照。行列号可作为可选的定位检查，不作为跨工具链默认契约。每次运行仍保存原始 stdout/stderr，失败摘要显示 case ID、实际命令、期望值和不匹配的诊断。

## Runner 与用户入口

Runner 提供三种入口：

~~~sh
cargo test -p lint-poc-runner
cargo run -p lint-poc-runner -- list
cargo run -p lint-poc-runner -- test clippy::macro_metavars_in_unsafe
cargo run -p lint-poc-runner -- test --toolchain stable
~~~

test 支持按 lint ID、来源、稳定性及工具链过滤，默认运行仓库声明的 stable 集合。单个 case 失败时继续执行其余 case，最终汇总 PASS/FAIL/SKIP 并返回非零退出码。SKIP 必须带具体原因，例如当前工具链缺少 nightly 组件；不能把未执行报告成通过。子进程应有超时，避免单个编译任务卡住整个 CI。

Runner 的核心只负责发现、执行、诊断解析、匹配和汇总。命令构造、JSON 解析、期望匹配应分成小模块，并以脱离 rustc 进程的 JSON 单元测试覆盖解析边界；case 集成测试本身则验证真实工具链行为。

## CI 与工具链策略

CI 分为两层：

1. **Harness 自测**：格式、runner 单元测试和普通测试，不编译 cases。
2. **Lint 集成矩阵**：stable 跑稳定 case；nightly job 只跑显式标记 nightly 的 case；必要时增加最低支持版本或指定版本 job。

初期保持矩阵窄：固定仓库主工具链，定期更新；只有 lint 行为确实依赖版本时才增加额外版本。记录 rustc、cargo、Clippy 版本和目标平台，使报告能复现。Clippy 版本随 rustc toolchain 绑定，不单独声称可自由升级。

配置驱动 lint（例如 clippy::disallowed_methods）必须随 case 一起包含有效配置，并断言实际目标诊断。报告应写明这是名单规则对直接调用的验证，而非间接调用或 wrapper 的通用语义分析。共享配置只用于确属项目全局的默认项；case 私有设置应放在 case 目录，以减少隐式耦合。

## 报告

终端输出适合快速定位，CI 另产出机器可读 JSON（可后续增加 JUnit）：

~~~json
{
  "toolchain": {"rustc": "1.xx.0", "clippy": "0.1.xx"},
  "cases": [
    {
      "id": "clippy::macro_metavars_in_unsafe",
      "status": "passed",
      "expected": [{"code": "clippy::macro_metavars_in_unsafe", "level": "error", "count": 1}],
      "actual": [{"code": "clippy::macro_metavars_in_unsafe", "level": "error", "count": 1}]
    }
  ]
}
~~~

报告保存 case 状态和结构化匹配结果；完整编译器原始输出作为失败时的工件保存，不塞进成功报告。工件名称包含工具链和平台，便于对照版本变化。

## 对参考仓库的取舍

参考项目用多个 binary 隔离 PoC，并检查 Clippy JSON 中的 lint code；这两点适合保留。新架构把隔离提升为独立 package，把期望从 shell 文本搜索提升为显式 case 契约，并让 lint ID 成为主要用例身份。这样可以清晰支持 rustc 与 Clippy 两类入口、case 级配置、工具链状态、准确的失败归因和后续扩展。

## 从现有 fixture 迁移

先把 mac01、ffi01 至 ffi04 拆成上述 case 目录，每个 case 的元数据声明其真实诊断 ID，而不是只声明 G.* 规则编号。对 FFI 样例，若一个源码同时触发 improper_ctypes 与 clippy::repr_packed_without_abi，优先拆成两个 lint case，避免单 lint 回归时被另一个诊断掩盖。disallowed_methods 的两个场景可继续独立，因为它们验证不同名单及规则边界。

完成迁移后依次确认：单 case 可独立运行；目标诊断缺失时 case 必定失败；无关诊断不能让 case 假通过；全量运行能继续越过单个失败并产出汇总；stable/nightly 筛选和 SKIP 原因准确。新增 PoC 的具体操作步骤收录在 docs/adding-a-case.md，本设计文档先定义架构，不要求在此轮实现 runner 或批量迁移源码。
