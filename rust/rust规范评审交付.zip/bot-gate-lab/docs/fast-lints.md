# BotGate Fast 基础 lint PoC

这组 PoC 对齐参考仓库 /Users/vaynnecol/WorkSpace/bot-gate/.botgate 的 Fast 基础检查。参考实现的 Fast Clippy 命令使用 --all-targets，并追加 Minimal 集合：

~~~text
-W clippy::borrow_interior_mutable_const
-W clippy::declare_interior_mutable_const
-W clippy::derived_hash_with_manual_eq
-W clippy::derive_ord_xor_partial_ord
-W clippy::blocks_in_conditions
-W clippy::recursive_format_impl
-W clippy::default_numeric_fallback
-W clippy::repr_packed_without_abi
-W clippy::macro_metavars_in_unsafe
-W clippy::disallowed_methods
~~~

本仓库另外按 Fast clippy 组补充了一条不在上述 Minimal 集合内的 lint：

~~~text
-W clippy::approx_constant
~~~

Fast cargo check 还要求 rustc 支持以下 warning lint：

~~~text
missing-abi
improper-ctypes
improper-ctypes-definitions
~~~

仓库目前为每个 lint 提供一个独立 case，共 14 个 case。case 目录中的 case.toml 保存 lint ID、工具来源、稳定性和 fixture；源码只保留触发目标诊断所需的最小内容。disallowed-methods case 固化了参考 .botgate/managed/clippy/.../clippy.toml 中的代表性配置（memcpy、getenv、strcpy、strtok），并期望命中 4 次。approx-constant case 的 fixture 中只有 `3.14_f64` 命中，同一函数内的 `1_f64 / x` 因 x 是变量而非字面量，实测不触发该 lint，因此期望命中数为 1。

运行全部 PoC：

~~~sh
./scripts/validate-fast.sh
~~~

脚本执行真实 cargo check --message-format=json 或 cargo clippy --message-format=json，解析 compiler-message，并检查：

- 目标 lint code 完全匹配；
- 诊断级别为 warning；
- 主 span 或宏展开来源回到当前 lib.rs；
- 命中数量符合 case 期望。

Fast 的策略是“warning 诊断阻断 step”，因此这些 case 不把 lint 全部提升为 -D，也不把 Cargo 进程退出码作为唯一依据。cargo check/cargo clippy 可能成功退出，但只要结构化输出包含目标 warning，BotGate fast step 就应判定失败；验证脚本因此允许这类预期 warning 并以结构化诊断作为 PASS 条件。

当前 case 覆盖的是直接触发样例。尤其是 clippy::disallowed_methods，它证明配置名单能阻止这些直接 C 函数调用，不等价于对 wrapper、函数指针或间接调用进行完整语义分析。

