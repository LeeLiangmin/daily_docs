// 验证 G.FUD.01：按值传递 / 移动是否产生实际 memcpy。
// 运行：rustc --crate-type lib -C opt-level=0 --emit asm move_copy_asm.rs  （再换 opt-level=3 对比），在 .s 中查找 memcpy

pub struct Big { pub buf: [u8; 4096] }

#[inline(never)] pub fn take_big(b: Big) -> u8 { b.buf[0] ^ b.buf[4095] }
#[inline(never)] pub fn take_ref(b: &Big) -> u8 { b.buf[0] ^ b.buf[4095] }
#[inline(never)] pub fn take_vec(v: Vec<u8>) -> usize { v.len() }

// 1. 转发一个按值收到的大参数（纯移动）
#[inline(never)] pub fn forward_move(b: Big) -> u8 { take_big(b) }
// 2. 传引用
#[inline(never)] pub fn forward_ref(b: &Big) -> u8 { take_ref(b) }
// 3. 移动一个局部变量后传入
#[inline(never)] pub fn local_move(x: u8) -> u8 { let mut b = Big { buf: [0; 4096] }; b.buf[1] = x; std::hint::black_box(&mut b); take_big(b) }
// 4. 移动 Vec：只搬 24 字节的头
#[inline(never)] pub fn forward_vec(v: Vec<u8>) -> usize { take_vec(v) }

// 5. 从引用解引用后按值传入（Copy 语义的显式拷贝）
#[derive(Clone, Copy)] pub struct BigCopy { pub buf: [u8; 4096] }
#[inline(never)] pub fn take_copy(b: BigCopy) -> u8 { b.buf[0] ^ b.buf[4095] }
#[inline(never)] pub fn deref_copy(b: &BigCopy) -> u8 { take_copy(*b) }
// 6. 移动进结构体字段（存储）
pub struct Holder { pub big: Big }
#[inline(never)] pub fn store(b: Big) -> Box<Holder> { Box::new(Holder { big: b }) }
